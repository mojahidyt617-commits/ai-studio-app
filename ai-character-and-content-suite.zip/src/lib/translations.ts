/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export const TRANSLATIONS = {
  en: {
    appTitle: "AI Creator Suite",
    appSubtitle: "Generate characters, custom thumbnails, and prompt recipes",
    credits: "Credits",
    login: "Log In",
    logout: "Log Out",
    username: "Username",
    usernamePlaceholder: "Enter username...",
    welcomeBack: "Welcome back",
    startTitle: "Create Account to Start",
    startSubtitle: "Sign up is free. Instantly receive 🪙 100 credits!",
    registerBtn: "Activate Workspace",
    invalidUser: "Please enter a valid username.",
    
    // Tools
    charTab: "Character Gen",
    thumbTab: "Thumbnail Maker",
    promptTab: "Prompt Architect",
    historyTab: "Activity Logs",

    // Credit Messages
    insufficientCredits: "Insufficient credits! 🪙 Please recharge from the sidebar.",
    deductedCredits: "Credits deducted! balance updated.",
    rechargeBtn: "Instant 🪙 +50 Free Credits",
    
    // Character Tool
    charTitle: "AI Character Architect",
    charSubtitle: "Generate high-fidelity lore, dynamic skills, and visual designs.",
    charName: "Character Name",
    charNamePlaceholder: "e.g., Kaelen Silverblade, Nova-09...",
    charClass: "Class & Universe",
    charClassPlaceholder: "e.g., Cyberpunk Ninja, Astral Priest...",
    charGender: "Gender Identity",
    charDesc: "Backstory / Aesthetic prompt",
    charDescPlaceholder: "Describe his mission, elemental focus, visual cybernetic details...",
    generateCharBtn: "Evolve Character (Cost: 15 Credits)",
    charGenerating: "Evolving DNA & Synapses...",
    charIntro: "Evolved Lore & Stats",
    charAbilities: "Special Abilities",
    charAttributes: "RPG Attributes",

    // Thumbnail Tool
    thumbTitle: "Vlog & Video Thumbnail Layout",
    thumbSubtitle: "Design high CTR thumbnails with color combinations and visual descriptions.",
    thumbText: "Primary Text Accent",
    thumbTextPlaceholder: "e.g., Code in 10 Mins, Secret UI Hacks...",
    thumbSub: "Secondary Subtext",
    thumbSubPlaceholder: "e.g., 100% Free Guide, Advanced Tips...",
    thumbStyle: "Art Theme Style",
    thumbSubject: "Core Hero Subject",
    thumbSubjectPlaceholder: "e.g., Floating golden CPU, cyberpunk kitty with headphones...",
    generateThumbBtn: "Design Thumbnail Specs (Cost: 10 Credits)",
    thumbGenerating: "Rendering Visual Layout Specs...",
    thumbPreview: "Dynamic Layout Canvas Preview",
    thumbProperties: "Layout Specifications",
    thumbArtPrompt: "Visual Prompts (Midjourney/DALL-E)",

    // Prompt Tool
    promptTitle: "AI Prompt Architect",
    promptSubtitle: "Transform simple ideas into beautifully structured and weighted generation recipes.",
    promptIdea: "Your Core Concept / Sketch",
    promptIdeaPlaceholder: "e.g., Cat drinking tea in space...",
    promptMedium: "Primary Art Medium",
    promptTone: "Atmospheric Tone & Lighting",
    generatePromptBtn: "Structure Prompt Recipe (Cost: 5 Credits)",
    promptGenerating: "Constructing Prompt Vectors...",
    fullPromptRecipe: "Engineered Generation Recipes",
    clickToCopy: "Click to Copy Prompt",
    copied: "Copied!",

    // General
    recentCreations: "Recent Creations History",
    noHistory: "No generations recorded yet in this session.",
    freeCharge: "Claim Free Credits",
    creditsRefreshed: "Claimed 🪙 50 complimentary credits! Keep designing.",
    aiGeneratedTag: "AI Synthesized",
    fallbackTag: "Local Fast Engine",
  },
  bn: {
    appTitle: "এআই ক্রিয়েটিভস স্টুডিও",
    appSubtitle: "এআই ক্যারেক্টার, কাস্টম থাম্বনেইল এবং প্রম্পট রেসিপি তৈরি করুন",
    credits: "ক্রেডিট",
    login: "লগইন",
    logout: "লগ আউট",
    username: "ইউজারনেম",
    usernamePlaceholder: "ইউজারনেম লিখুন...",
    welcomeBack: "স্বাগতম",
    startTitle: "শুরু করতে অ্যাকাউন্ট তৈরি করুন",
    startSubtitle: "সাইন আপ সম্পূর্ণ ফ্রি। সাথে সাথে পাবেন 🪙 ১০০ ক্রেডিট!",
    registerBtn: "ওয়ার্কস্পেস অ্যাক্টিভ করুন",
    invalidUser: "দয়া করে একটি সঠিক ইউজারনেম দিন।",
    
    // Tools
    charTab: "ক্যারেক্টার জেনারেটর",
    thumbTab: "থাম্বনেইল মেকার",
    promptTab: "প্রম্পট আর্কিটেক্ট",
    historyTab: "অ্যাক্টিভিটি লগস",

    // Credit Messages
    insufficientCredits: "পর্যাপ্ত ক্রেডিট নেই! 🪙 অনুগ্রহ করে সাইডবার থেকে রিচার্জ করুন।",
    deductedCredits: "ক্রেডিট কাটা হয়েছে! ব্যালেন্স আপডেট হয়েছে।",
    rechargeBtn: "ফ্রি 🪙 +৫০ ক্রেডিট নিন",
    
    // Character Tool
    charTitle: "এআই ক্যারেক্টার আর্কিটেক্ট",
    charSubtitle: "উচ্চমানের রিয়েল ইভলভড ব্যাকস্টোরি, ডায়নামিক স্কিলস এবং ভিজ্যুয়াল ডিজাইন তৈরি করুন।",
    charName: "ক্যারেক্টারের নাম",
    charNamePlaceholder: "যেমন: কালেন সিলভারব্লেড, নোভা-০৯...",
    charClass: "ক্লাস এবং ইউনিভার্স",
    charClassPlaceholder: "যেমন: সাইবারপাঙ্ক নিনজা, অ্যাস্ট্রাল প্রিস্ট...",
    charGender: "লিঙ্গ",
    charDesc: "ব্যাকস্টোরি / ভিজ্যুয়াল প্রম্পট",
    charDescPlaceholder: "তার মিশন, উপাদানগত ফোকাস, ভিজ্যুয়াল সাইবারনেটিক বিশদ বর্ণনা করুন...",
    generateCharBtn: "ক্যারেক্টার তৈরি করুন (খরচ: ১৫ ক্রেডিট)",
    charGenerating: "ডিএনএ এবং সিন্যাপস ডেভেলপ হচ্ছে...",
    charIntro: "তৈরিকৃত ক্যারেক্টার এবং স্ট্যাটস",
    charAbilities: "বিশেষ ক্ষমতা (Abilities)",
    charAttributes: "আরপিজি অ্যাট্রিবিউটস (Stats)",

    // Thumbnail Tool
    thumbTitle: "ভ্লগ ও ভিডিও থাম্বনেইল লেআউট",
    thumbSubtitle: "রঙের কম্বিনেশন এবং ভিজ্যুয়াল ডেসক্রিপশন সহ উচ্চ সিটিআর থাম্বনেইল ডিজাইন করুন।",
    thumbText: "প্রধান টেক্সট অ্যাকসেন্ট",
    thumbTextPlaceholder: "যেমন: ১০ মিনিটে কোডিং, সিক্রেট ইউআই হ্যাকস...",
    thumbSub: "সহায়ক সাবটেক্সট",
    thumbSubPlaceholder: "যেমন: ১০০% ফ্রি গাইড, অ্যাডভান্সড টিপস...",
    thumbStyle: "আর্ট থিম স্টাইল",
    thumbSubject: "মূল হিরো সাবজেক্ট",
    thumbSubjectPlaceholder: "যেমন: শূন্যে ভাসমান গোল্ডেন সিপিইউ, হেডফোনসহ বিড়াল...",
    generateThumbBtn: "থাম্বনেইল লেআউট ডিজাইন করুন (খরচ: ১০ ক্রেডিট)",
    thumbGenerating: "ভিজ্যুয়াল লেআউট রেন্ডার হচ্ছে...",
    thumbPreview: "ডায়নামিক লেআউট ক্যানভাস প্রিভিউ",
    thumbProperties: "লেআউট স্পেসিফিকেশন",
    thumbArtPrompt: "ভিজ্যুয়াল প্রম্পটস (Midjourney/DALL-E)",

    // Prompt Tool
    promptTitle: "এআই প্রম্পট আর্কিটেক্ট",
    promptSubtitle: "সাধারণ আইডিয়াকে সুন্দর সুবিন্যস্ত এবং ওয়েটেড ইমেজ তৈরির প্রম্পটে রূপান্তর করুন।",
    promptIdea: "আপনার মূল কনসেপ্ট / স্কেচ",
    promptIdeaPlaceholder: "যেমন: মহাশূন্যে চা পান করা একটি বিড়াল...",
    promptMedium: "আর্ট মিডিয়াম",
    promptTone: "বায়ুমণ্ডলীয় টোন ও লাইটিং",
    generatePromptBtn: "প্রম্পট রেসিপি তৈরি করুন (খরচ: ৫ ক্রেডিট)",
    promptGenerating: "প্রম্পট ভেক্টর তৈরি হচ্ছে...",
    fullPromptRecipe: "তৈরিকৃত জেনারেশন রেসিপি",
    clickToCopy: "কপি করতে ক্লিক করুন",
    copied: "কপি হয়েছে!",

    // General
    recentCreations: "সাম্প্রতিক সৃষ্টির ইতিহাস",
    noHistory: "এই সেশনে এখনও কোনো জেনারেশন রেকর্ড করা হয়নি।",
    freeCharge: "ফ্রি ক্রেডিট নিন",
    creditsRefreshed: "🪙 ৫০ সৌজন্যমূলক ক্রেডিট যুক্ত করা হয়েছে!",
    aiGeneratedTag: "এআই সিন্থেসাইজড",
    fallbackTag: "লোকাল ফাস্ট ইঞ্জিন",
  }
};
export type LanguageCode = "en" | "bn";
