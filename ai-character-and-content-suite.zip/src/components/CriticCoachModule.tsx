import React, { useState } from "react";
import { LanguageCode } from "../lib/translations";
import { 
  Sparkles, Award, ShieldAlert, Eye, Trophy, BookOpen, 
  RefreshCw, CheckCircle, HelpCircle, FileText, Upload,
  Gauge, Star, MessageSquareCode, ArrowRight, TrendingUp
} from "lucide-react";

interface CriticCoachProps {
  lang: LanguageCode;
  credits: number;
  deductCredits: (qty: number, actionTitle: string) => boolean;
}

export default function CriticCoachModule({
  lang,
  credits,
  deductCredits,
}: CriticCoachProps) {
  const isEn = lang === "en";

  // Sub Navigation
  const [activeTab, setActiveTab] = useState<"thumbnail" | "coach" | "detector" | "revision">("thumbnail");

  // State Management
  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState("");

  /* ==========================================
     1. THUMBNAIL ANALYZER STATE
     ========================================== */
  const [thumbTitle, setThumbTitle] = useState("");
  const [thumbPresetName, setThumbPresetName] = useState("Finance Explainer Layout");
  const [analyzerResult, setAnalyzerResult] = useState<{
    ctrScore: number;
    readabilityScore: number;
    attentionScore: number;
    visualHierarchyBreakdown: string;
    pointsOfFix: string[];
    glowingSectors: string[];
  } | null>(() => {
    return {
      ctrScore: 82,
      readabilityScore: 90,
      attentionScore: 78,
      visualHierarchyBreakdown: "Contrast ratio between text and background is high. The face icon occupies 35% of the visual space which guarantees solid human engagement.",
      pointsOfFix: [
        "Increase font size of secondary subtitle by 10% to prevent mobile shrinkage.",
        "Add a subtle high-contrast drop shadow or glowing bezel around the primary face vector to detach from the background canvas.",
        "Ensure visual elements direct viewing attention toward the right-side text column."
      ],
      glowingSectors: ["Right-hand center heading tags", "Bottom-left warning icon"]
    };
  });

  const handleAnalyzeThumbnail = async () => {
    setErrorMsg("");
    const cost = 10;
    if (credits < cost) {
      setErrorMsg(isEn ? "No credits!" : "পর্যাপ্ত ক্রেডিট নেই!");
      return;
    }
    setLoading(true);

    const promptText = `Analyze Thumbnail Spec: Title: "${thumbTitle || "How I Built My SaaS"}". Primary Graphic: "${thumbPresetName}"`;
    const systemInstruction = 
      "You are a master click-through optimization engineer for YouTube. Return EXACTLY a single JSON object analyzing CTR and interest: { ctrScore: number (0-100), readabilityScore: number (0-100), attentionScore: number (0-100), visualHierarchyBreakdown: string, pointsOfFix: [string, string, string], glowingSectors: [string, string] }";

    try {
      const resp = await fetch("/api/studio/general-generate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          prompt: promptText,
          systemInstruction,
          fallbackJson: {
            ctrScore: Math.floor(Math.random() * 25) + 65,
            readabilityScore: 85,
            attentionScore: 75,
            visualHierarchyBreakdown: "Good bold heading layout with strong focal weight.",
            pointsOfFix: ["Optimize text contrast further.", "Increase sizing of key badge icons."],
            glowingSectors: ["Left face artwork", "Main bold heading keywords"]
          }
        })
      });

      const resData = await resp.json();
      if (resData.success && resData.data) {
        setAnalyzerResult(resData.data);
        deductCredits(cost, `Thumbnail Analysed: ${thumbTitle || "Custom Thumbnail"}`);
      }
    } catch {
      setErrorMsg("Failed to analyze.");
    } finally {
      setLoading(false);
    }
  };

  /* ==========================================
     2. DESIGN COACH STATE
     ========================================== */
  const [designerWorkDesc, setDesignerWorkDesc] = useState("");
  const [coachResult, setCoachResult] = useState<{
    keyStrengths: string[];
    majorWeaknesses: string[];
    remedyPlan: { phase: string; step: string }[];
    designLevelRating: string;
  } | null>(() => {
    return {
      keyStrengths: [
        "Consistent brand colors used accurately across visual headers.",
        "Ample white space prevents interface sensory overload."
      ],
      majorWeaknesses: [
        "Inconsistent margin spacing between cards (differs by 12px in multiple blocks).",
        "No dynamic focus point; the visual graphics and header have matching layout weights."
      ],
      remedyPlan: [
        { phase: "Refactoring Spacing", step: "Implement a strict global Tailwind spacing rule (e.g., space-y-6 inside all central cards) and enforce it rigidly." },
        { phase: "Aesthetic Domination", step: "Scale your hero primary graphic by 1.3x and tint with accent drop shadows so it naturally is decoded first on entrance." }
      ],
      designLevelRating: "B- (Intermediate Stylist)"
    };
  });

  const handleConsultCoach = async () => {
    setErrorMsg("");
    const cost = 12;
    if (credits < cost) {
      setErrorMsg(isEn ? "No credits!" : "পর্যাপ্ত ক্রেডিট নেই!");
      return;
    }
    setLoading(true);

    const systemInstruction = 
      "You are a strict, top-tier Design Coach. Critically analyze the user's describes interface and return EXACTLY a single JSON object: { keyStrengths: [string, string], majorWeaknesses: [string, string], remedyPlan: [{phase, step}], designLevelRating: string }";

    try {
      const resp = await fetch("/api/studio/general-generate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          prompt: `Coach feedback for layout description: "${designerWorkDesc || "A modern landing page for an organic juice bar with full-width images and yellow headings"}"`,
          systemInstruction,
          fallbackJson: {
            keyStrengths: ["High color vibrant contrast", "Clean horizontal flex grids"],
            majorWeaknesses: ["Yellow headers on white/soft cream background can be difficult to read.", "Lack of explicit brand logomarks."],
            remedyPlan: [
              { phase: "Color safety", step: "Darken yellow headings to amber-gold, or introduce deep charcoal background frames for optimal legibility." }
            ],
            designLevelRating: "B+ Professional Stylist"
          }
        })
      });

      const resData = await resp.json();
      if (resData.success && resData.data) {
        setCoachResult(resData.data);
        deductCredits(cost, "Consulted Design Coach");
        setDesignerWorkDesc("");
      }
    } catch {
      setErrorMsg("Error generating coaching plan.");
    } finally {
      setLoading(false);
    }
  };

  /* ==========================================
     3. STYLE DETECTOR STATE
     ========================================== */
  const [stylePresetDesc, setStylePresetDesc] = useState("");
  const [styleResult, setStyleResult] = useState<{
    detectedStyle: string;
    eraInfluenceBigIdeas: string;
    criticalProportions: string;
    modernApplicationTips: string;
  } | null>(() => {
    return {
      detectedStyle: "Neo-Brutalist Punk",
      eraInfluenceBigIdeas: "Heavily influenced by old 90s zine layouts mixed with high-visibility web interfaces featuring aggressive borders, raw primary colors, and high text densities.",
      criticalProportions: "Borders 2px active black, shadows set with zero blurs and offset 4px, absolute block grids.",
      modernApplicationTips: "Balance brutalism with soft modern pastel background colors so it is accessible."
    };
  });

  const handleDetectStyle = async () => {
    setErrorMsg("");
    const cost = 5;
    if (credits < cost) {
      setErrorMsg(isEn ? "No credits!" : "পর্যাপ্ত ক্রেডিট নেই!");
      return;
    }
    setLoading(true);

    const systemInstruction = 
      "You are an art historian and digital design critic. Identify and analyze visual styles based on descriptor prompts. Return EXACTLY a single JSON object: { detectedStyle, eraInfluenceBigIdeas, criticalProportions, modernApplicationTips }";

    try {
      const resp = await fetch("/api/studio/general-generate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          prompt: `Detect style metrics for elements: "${stylePresetDesc || "hard flat shadows, bright lime colors, heavy black borders"}"`,
          systemInstruction,
          fallbackJson: {
            detectedStyle: "Retro Web 1.0",
            eraInfluenceBigIdeas: "Late 1990s early database listings.",
            criticalProportions: "Dotted borders, grey backgrounds, high-contrast flat shapes.",
            modernApplicationTips: "Use modern clean sans-serif typefaces to prevent genuine ancient feel."
          }
        })
      });

      const resData = await resp.json();
      if (resData.success && resData.data) {
        setStyleResult(resData.data);
        deductCredits(cost, `Style Detected: ${resData.data.detectedStyle}`);
        setStylePresetDesc("");
      }
    } catch {
      setErrorMsg("Error matching style systems.");
    } finally {
      setLoading(false);
    }
  };

  /* ==========================================
     4. REVISION ASSISTANT STATE
     ========================================== */
  const [feedbackRaw, setFeedbackRaw] = useState("");
  const [revisionResult, setRevisionResult] = useState<{
    clientStatedEmotion: string;
    decodedTechnicalAction: { issue: string; resolution: string; priority: string }[];
    designFriendlyReplyText: string;
  } | null>(() => {
    return {
      clientStatedEmotion: "Anxious / Seeking high energy branding (Frustrated with simplicity)",
      decodedTechnicalAction: [
        { issue: "Wants design to 'pop' out more", resolution: "Increase color saturation of core CTAs by 15% and introduce subtle glowing drop-shadows on active buttons.", priority: "High" },
        { issue: "Stated 'not modern enough'", resolution: "Replace Inter sans-serif typeface on headers with Outfit ExtraBold and decrease line spacing for a cohesive vanguard feel.", priority: "Medium" }
      ],
      designFriendlyReplyText: "Hi! Thanks for the insightful direction. I've engineered the visual hierarchy further—introducing key saturated highlight accents to direct user gaze and upgrading the typography block to a bold ExtraBold structure. This guarantees high visual authority on first sight."
    };
  });

  const handleTranslateRevision = async () => {
    setErrorMsg("");
    const cost = 10;
    if (credits < cost) {
      setErrorMsg(isEn ? "No credits!" : "পর্যাপ্ত ক্রেডিট নেই!");
      return;
    }
    setLoading(true);

    const systemInstruction = 
      "You are a business consultant and design project manager. Decode messy client design suggestions and reconstruct into premium professional design blueprints and supportive replies. Return EXACTLY a single JSON object: { clientStatedEmotion, decodedTechnicalAction: [{issue, resolution, priority}], designFriendlyReplyText }";

    try {
      const resp = await fetch("/api/studio/general-generate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          prompt: `Decode client complain: "${feedbackRaw || "I don't know but it looks boring, make it pop and look rich!"}"`,
          systemInstruction,
          fallbackJson: {
            clientStatedEmotion: "Vague confusion, seeking high premium value indicators",
            decodedTechnicalAction: [
              { issue: "Boring", resolution: "Introduce subtle ambient lighting background glows and metallic accents on decorative lines.", priority: "High" }
            ],
            designFriendlyReplyText: "Hi! I have enhanced the layout systems to reflect a more exclusive brand tier, updating the visual gradients and spacing."
          }
        })
      });

      const resData = await resp.json();
      if (resData.success && resData.data) {
        setRevisionResult(resData.data);
        deductCredits(cost, "Revision Assistant Decoded Feedback");
        setFeedbackRaw("");
      }
    } catch {
      setErrorMsg("Error translating feedback.");
    } finally {
      setLoading(false);
    }
  };


  return (
    <div className="bg-[#111115] border border-white/5 rounded-3xl p-4 sm:p-8 space-y-8 text-white relative">
      {/* Glow styling */}
      <div className="absolute top-0 right-0 w-64 h-64 bg-emerald-500/5 blur-[90px] pointer-events-none rounded-full" />

      {/* Header Panel */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 border-b border-white/5 pb-6">
        <div>
          <h2 className="text-xl sm:text-2xl font-display font-medium text-white flex items-center gap-2">
            <Gauge className="w-6 h-6 text-emerald-400" />
            <span>{isEn ? "AI Design Critic & Coaching cockpit" : "এআই ডিজাইন ক্রিটিক ও কোচ"}</span>
            <span className="text-[10px] bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 px-2 py-0.5 rounded-full uppercase font-mono">
              Diagnostic Mode
            </span>
          </h2>
          <p className="text-xs text-gray-400 mt-1">
            {isEn ? "Diagnostic engines that grade, debug, and coach your project's alignment and Click-Through-Rates." : "আপনার ডিজাইনের ত্রুটি সংশোধন, রেটিং এবং সিটিআর বৃদ্ধির এআই মেকানিজম।"}
          </p>
        </div>

        {/* Tab Selector */}
        <div className="flex flex-wrap gap-1.5 p-1 bg-white/5 border border-white/5 rounded-2xl">
          {[
            { id: "thumbnail", label: isEn ? "CTR Analyser" : "থাম্বনেইল স্কোর", icon: TrendingUp },
            { id: "coach", label: isEn ? "Critic Coach" : "এআই কোচ", icon: Star },
            { id: "detector", label: isEn ? "Style Detector" : "স্টাইল ডিটেক্টর", icon: Eye },
            { id: "revision", label: isEn ? "Revision Help" : "ক্লায়েন্ট ফিডব্যাক", icon: MessageSquareCode },
          ].map((item) => {
            const Icon = item.icon;
            return (
              <button
                key={item.id}
                onClick={() => {
                  setActiveTab(item.id as any);
                  setErrorMsg("");
                }}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold cursor-pointer transition-all ${
                  activeTab === item.id
                    ? "bg-emerald-600 text-white shadow-md shadow-emerald-950/40"
                    : "text-gray-400 hover:text-white hover:bg-white/5"
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                <span>{item.label}</span>
              </button>
            );
          })}
        </div>
      </div>

      {errorMsg && (
        <div className="p-4 bg-red-900/10 border border-red-500/20 rounded-2xl text-xs text-red-400">
          {errorMsg}
        </div>
      )}

      {/* Main Core Area */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* INPUT PANEL COLUMN */}
        <div className="lg:col-span-5 space-y-6 bg-white/5 border border-white/5 p-6 rounded-2xl">
          
          {/* 1. THUMBNAIL ANALYZER INTERFACE */}
          {activeTab === "thumbnail" && (
            <div className="space-y-4">
              <h3 className="text-sm font-semibold tracking-wider text-gray-300 uppercase flex items-center gap-2">
                <TrendingUp className="w-4 h-4 text-emerald-400" />
                <span>{isEn ? "Thumbnail Optimizer" : "থাম্বনেইল এনালাইজার"}</span>
              </h3>
              <p className="text-xs text-gray-400">
                {isEn ? "Forecast CTR, attention scores, visual hotspots, and acquire actionable steps to boost video clicks." : "ভিডিওর টাইটেল ও আর্ট প্যারামিটার বিশ্লেষণ করে সম্ভাব্য সিটিআর রেটিং নির্ণয় করুন।"}
              </p>

              <div className="space-y-1.5">
                <label className="text-xs font-medium text-gray-300">{isEn ? "Thumbnail Text / Title Text" : "থাম্বনেইলে লেখা টেক্সট"}</label>
                <input
                  type="text"
                  placeholder="e.g., Earn $100/Hr Using AI Secrets"
                  value={thumbTitle}
                  onChange={(e) => setThumbTitle(e.target.value)}
                  className="w-full bg-black/40 border border-white/15 rounded-xl p-3 text-xs text-white focus:outline-none focus:border-emerald-500 transition-all font-sans font-semibold"
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-medium text-gray-300">{isEn ? "Primary Graphic Layout Vibe" : "প্রধান গ্রাফিক্স কনসেপ্ট"}</label>
                <select
                  value={thumbPresetName}
                  onChange={(e) => setThumbPresetName(e.target.value)}
                  className="w-full bg-black/40 border border-white/15 rounded-xl p-3 text-xs text-white focus:outline-none focus:border-emerald-500 transition-all"
                >
                  <option value="Finance Dark Red Explainer">📈 Finance Explainer / ফাইন্যান্স এক্সপ্লেইনার</option>
                  <option value="Gaming neon overlay fast-paced">🎮 High-octane Gaming FPS / গেমিং লোগো এন্ড স্পার্কস</option>
                  <option value="Vlog lifestyle bokeh frame">📸 Lifestyle Vlog Outdoor / ট্রাভেল ভ্লগ</option>
                  <option value="Tech Minimalist product shine">💻 Tech Review Matte Gradient / প্রোডাক্ট শোকেস</option>
                </select>
              </div>

              <div className="border-2 border-dashed border-white/10 rounded-xl p-4 text-center cursor-pointer hover:border-emerald-500/30 transition-all">
                <Upload className="w-5 h-5 mx-auto text-gray-500 mb-1" />
                <span className="text-[10px] text-gray-400 block">{isEn ? "Drop custom image draft to simulate scan" : "ড্রাফট ইমেজ ড্রপ করুন (সিমুলেশন)"}</span>
              </div>

              <button
                onClick={handleAnalyzeThumbnail}
                disabled={loading}
                className="w-full bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white font-semibold py-3 px-4 rounded-xl text-xs flex items-center justify-center gap-2 cursor-pointer transition-all shadow-md shadow-emerald-950/40"
              >
                <Gauge className="w-3.5 h-3.5" />
                <span>{loading ? "Optimizing CTR..." : (isEn ? "Calculate CTR & Attention (10 Credits)" : "সিটিআর স্ক্যান শুরু করুন (১০ ক্রেডিট)")}</span>
              </button>
            </div>
          )}

          {/* 2. DESIGN COACH INTERFACE */}
          {activeTab === "coach" && (
            <div className="space-y-4">
              <h3 className="text-sm font-semibold tracking-wider text-gray-300 uppercase flex items-center gap-2">
                <Trophy className="w-4 h-4 text-emerald-400" />
                <span>{isEn ? "Design Consultation Engine" : "ডিজাইন কোচ সিসটেম"}</span>
              </h3>
              <p className="text-xs text-gray-400">
                {isEn ? "Describe your exact visual arrangement (or mock layout) to obtain rigid elite grading, advice and strengths." : "আপনার তৈরি করা কোনো ডিজাইনের বর্ণনা দিন; এআই তাৎক্ষণিকভাবে সেটার এলাইনমেন্ট ও গ্রেডিং সংশোধন বুক দেবে।"}
              </p>

              <div className="space-y-1.5">
                <label className="text-xs font-medium text-gray-300">{isEn ? "Explain Your Work / Grid" : "ডিজাইনের এলিমেন্টগুলির বিন্যাস বর্ণনা করুন"}</label>
                <textarea
                  rows={4}
                  placeholder="e.g., 'i made a landing page banner. it has a red circle on the right side, white bold title on the left, but somehow it feels very crowded in the center...'"
                  value={designerWorkDesc}
                  onChange={(e) => setDesignerWorkDesc(e.target.value)}
                  className="w-full bg-black/40 border border-white/15 rounded-xl p-3 text-xs text-white placeholder-gray-500 focus:outline-none focus:border-emerald-500 transition-all font-mono"
                />
              </div>

              <button
                onClick={handleConsultCoach}
                disabled={loading || !designerWorkDesc.trim()}
                className="w-full bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white font-semibold py-3 px-4 rounded-xl text-xs flex items-center justify-center gap-2 cursor-pointer transition-all"
              >
                <Star className="w-3.5 h-3.5" />
                <span>{loading ? "Evaluating Hierarchy..." : (isEn ? "Get Elite Coach Feedback (12 Credits)" : "গ্রেডিং রিপোর্ট বের করুন (১২ ক্রেডিট)")}</span>
              </button>
            </div>
          )}

          {/* 3. STYLE DETECTOR INTERFACE */}
          {activeTab === "detector" && (
            <div className="space-y-4">
              <h3 className="text-sm font-semibold tracking-wider text-gray-300 uppercase flex items-center gap-2">
                <Eye className="w-4 h-4 text-emerald-400" />
                <span>{isEn ? "Design Style Metric Detector" : "ডিজাইন স্টাইল ডিটেক্টর"}</span>
              </h3>
              <p className="text-xs text-gray-400">
                {isEn ? "Deconstruct any prompt or asset configuration into historical art classes, proportions and application tricks." : "যেকোনো আর্ট বা ইন্টারফেস ডিসক্রিপশন লিখে সেটির আসল ডিজাইন ক্যাটাগরি ডিটেক্ট করুন।"}
              </p>

              <div className="space-y-1.5">
                <label className="text-xs font-medium text-gray-300">{isEn ? "Describe colors, shadows, border styles" : "ডিজাইন ভিজ্যুয়াল অ্যাট্রিবিউটস দিন"}</label>
                <input
                  type="text"
                  placeholder="e.g., absolute neon purple grids, matte dark cards, space typography"
                  value={stylePresetDesc}
                  onChange={(e) => setStylePresetDesc(e.target.value)}
                  className="w-full bg-black/40 border border-white/15 rounded-xl p-3 text-xs text-white focus:outline-none focus:border-emerald-500 transition-all"
                />
              </div>

              <button
                onClick={handleDetectStyle}
                disabled={loading || !stylePresetDesc.trim()}
                className="w-full bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white font-semibold py-3 px-4 rounded-xl text-xs flex items-center justify-center gap-2 cursor-pointer transition-all"
              >
                <Eye className="w-3.5 h-3.5" />
                <span>{loading ? "Scanning Era Aesthetics..." : (isEn ? "Analyze Visual Style (5 Credits)" : "স্টাইল ডিরেক্টরি খুঁজুন (৫ ক্রেডিট)")}</span>
              </button>
            </div>
          )}

          {/* 4. REVISION ASSISTANT INTERFACE */}
          {activeTab === "revision" && (
            <div className="space-y-4">
              <h3 className="text-sm font-semibold tracking-wider text-gray-300 uppercase flex items-center gap-2">
                <MessageSquareCode className="w-4 h-4 text-emerald-400" />
                <span>{isEn ? "Design Revision Decoder" : "রিভিশন এসিস্ট্যান্ট"}</span>
              </h3>
              <p className="text-xs text-gray-400">
                {isEn ? "Translate passive-aggressive or vague feedback like 'make it look pop and energetic' into rigid step-by-step styling adjustments." : "ক্লায়েন্টের অদ্ভুত ফিডব্যাক (যেমন: এটাকে একটু ফুটিয়ে তুলুন) দিলে এআই সেটিকে প্রফেশনাল স্পেসিফিকেশনে রুপ দেবে।"}
              </p>

              <div className="space-y-1.5">
                <label className="text-xs font-medium text-gray-300">{isEn ? "Raw Client Feedback" : "ক্লায়েন্টের মন্তব্য পেস্ট করুন"}</label>
                <textarea
                  rows={4}
                  placeholder="e.g., 'the screen is too dull, it needs real premium vibe and make the buttons dynamic! why is it so empty?'"
                  value={feedbackRaw}
                  onChange={(e) => setFeedbackRaw(e.target.value)}
                  className="w-full bg-black/40 border border-white/15 rounded-xl p-3 text-xs text-white focus:outline-none focus:border-emerald-500 transition-all font-mono"
                />
              </div>

              <button
                onClick={handleTranslateRevision}
                disabled={loading || !feedbackRaw.trim()}
                className="w-full bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white font-semibold py-3 px-4 rounded-xl text-xs flex items-center justify-center gap-2 cursor-pointer transition-all"
              >
                <MessageSquareCode className="w-3.5 h-3.5" />
                <span>{loading ? "Translating Client Mind..." : (isEn ? "Decode Revision Blueprint (10 Credits)" : "ফিডব্যাক ডিকোড করুন (১০ ক্রেডিট)")}</span>
              </button>
            </div>
          )}

        </div>

        {/* DIAGNOISTIC OUTPUT PANEL COCKPIT */}
        <div className="lg:col-span-7 bg-black/50 border border-white/5 p-6 rounded-2xl flex flex-col justify-between min-h-[460px] relative">
          
          {loading && (
            <div className="absolute inset-0 bg-black/85 backdrop-blur-sm z-20 flex flex-col items-center justify-center space-y-4 rounded-2xl">
              <div className="w-10 h-10 border-4 border-emerald-500 border-t-transparent rounded-full animate-spin" />
              <p className="text-xs font-mono text-emerald-300 uppercase animate-pulse tracking-wide">
                Executing Professional Aesthetic Diagnostic Scans...
              </p>
            </div>
          )}

          <div className="space-y-6">
            <div className="flex items-center justify-between border-b border-white/5 pb-3">
              <span className="text-[10px] font-mono tracking-wider text-gray-500 uppercase flex items-center gap-1.5">
                <span className="w-1.5 h-1.5 bg-emerald-500 rounded-full animate-pulse" />
                <span>Aesthetic Diagnostic Result</span>
              </span>
              <span className="text-[9px] bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 px-2 py-0.5 rounded uppercase font-bold font-mono">
                {activeTab} evaluation
              </span>
            </div>

            {/* OPTION 1: THUMBNAIL ANALYZER OUTPUT */}
            {activeTab === "thumbnail" && analyzerResult && (
              <div className="space-y-6">
                
                {/* 3 Grid Scores widgets */}
                <div className="grid grid-cols-3 gap-3">
                  <div className="bg-[#121215] border border-white/5 p-3.5 rounded-xl text-center relative overflow-hidden">
                    <div className="absolute top-0 inset-x-0 h-1 bg-emerald-500" />
                    <span className="text-[9px] font-mono uppercase text-gray-400">CTR Rank</span>
                    <h5 className="text-2xl font-black text-white mt-1 text-emerald-400">{analyzerResult.ctrScore}%</h5>
                    <span className="text-[8px] text-gray-500 font-mono">High Potency</span>
                  </div>

                  <div className="bg-[#121215] border border-white/5 p-3.5 rounded-xl text-center relative overflow-hidden">
                    <div className="absolute top-0 inset-x-0 h-1 bg-blue-500" />
                    <span className="text-[9px] font-mono uppercase text-gray-400">Readability</span>
                    <h5 className="text-2xl font-black text-white mt-1 text-blue-400">{analyzerResult.readabilityScore}/100</h5>
                    <span className="text-[8px] text-gray-500 font-mono">Clear Contrast</span>
                  </div>

                  <div className="bg-[#121215] border border-white/5 p-3.5 rounded-xl text-center relative overflow-hidden">
                    <div className="absolute top-0 inset-x-0 h-1 bg-indigo-500" />
                    <span className="text-[9px] font-mono uppercase text-gray-400">Attention</span>
                    <h5 className="text-2xl font-black text-white mt-1 text-indigo-400">{analyzerResult.attentionScore}%</h5>
                    <span className="text-[8px] text-gray-500 font-mono">Gaze Focus</span>
                  </div>
                </div>

                {/* Hotspot sector tags */}
                <div className="p-3 bg-white/5 border border-white/5 rounded-xl space-y-1">
                  <span className="text-[9px] text-gray-400 font-mono uppercase block">Identified High Gaze Areas:</span>
                  <div className="flex flex-wrap gap-1.5 mt-1">
                    {analyzerResult.glowingSectors.map((sec, idx) => (
                      <span key={idx} className="text-[10px] bg-emerald-500/10 text-emerald-300 border border-emerald-500/20 px-2 py-0.5 rounded-md font-mono">
                        🔥 Sector: {sec}
                      </span>
                    ))}
                  </div>
                </div>

                {/* Analysis breakdown */}
                <div className="space-y-2">
                  <span className="text-xs font-bold text-gray-300 block">🔬 Structural Diagnostic Feedback:</span>
                  <p className="text-xs text-gray-400 leading-relaxed font-mono">{analyzerResult.visualHierarchyBreakdown}</p>
                </div>

                {/* Checklist optimization recommendations */}
                <div className="space-y-2 pt-1 border-t border-white/5">
                  <span className="text-xs font-semibold text-emerald-400 block">📝 Immediate Click Optimization Tasklist:</span>
                  <div className="space-y-1.5">
                    {analyzerResult.pointsOfFix.map((fix, idx) => (
                      <div key={idx} className="flex items-start gap-2 text-xs text-gray-300 bg-black/40 p-2 border border-white/5 rounded-lg">
                        <CheckCircle className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                        <span>{fix}</span>
                      </div>
                    ))}
                  </div>
                </div>

              </div>
            )}

            {/* OPTION 2: DESIGN COACH OUTPUT */}
            {activeTab === "coach" && coachResult && (
              <div className="space-y-5">
                <div className="flex justify-between items-center bg-[#131316] border border-white/5 px-4 py-3 rounded-xl">
                  <span className="text-xs font-bold text-gray-300">Grade Evaluated by Critic Engine:</span>
                  <span className="text-xs font-bold font-mono text-emerald-400 bg-emerald-500/15 border border-emerald-500/20 px-3 py-1 rounded-lg">
                    {coachResult.designLevelRating}
                  </span>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="bg-emerald-950/10 border border-emerald-900/30 p-4 rounded-xl space-y-2">
                    <span className="text-xs font-bold text-emerald-400 uppercase tracking-wide block">🏆 Symmetrical Strengths:</span>
                    <ul className="list-disc pl-4 text-xs text-gray-300 space-y-1.5">
                      {coachResult.keyStrengths.map((str, idx) => (
                        <li key={idx}>{str}</li>
                      ))}
                    </ul>
                  </div>

                  <div className="bg-red-950/10 border border-red-900/30 p-4 rounded-xl space-y-2">
                    <span className="text-xs font-bold text-red-400 uppercase tracking-wide block">🚨 structural Pitfalls:</span>
                    <ul className="list-disc pl-4 text-xs text-gray-300 space-y-1.5">
                      {coachResult.majorWeaknesses.map((weak, idx) => (
                        <li key={idx} className="text-gray-300">{weak}</li>
                      ))}
                    </ul>
                  </div>
                </div>

                {/* Custom remedy step list */}
                <div className="space-y-2.5">
                  <span className="text-xs font-semibold text-gray-300 block">🛠️ Actionable Styling Remedy Roadmap:</span>
                  <div className="space-y-2">
                    {coachResult.remedyPlan.map((plan, idx) => (
                      <div key={idx} className="bg-[#121215] border border-white/5 p-3 rounded-xl text-xs space-y-1 font-mono">
                        <span className="text-[10px] uppercase font-bold text-emerald-400 block">Phase {idx + 1}: {plan.phase}</span>
                        <p className="text-gray-300 leading-normal">{plan.step}</p>
                      </div>
                    ))}
                  </div>
                </div>

              </div>
            )}

            {/* OPTION 3: STYLE DETECTOR OUTPUT */}
            {activeTab === "detector" && styleResult && (
              <div className="space-y-5">
                <div className="bg-white/5 border border-white/5 p-5 rounded-2xl space-y-3">
                  <span className="text-[10px] font-mono text-gray-500 uppercase tracking-widest block">Aesthetic Blueprint Detected</span>
                  <h4 className="text-xl font-bold font-display text-white text-emerald-400">{styleResult.detectedStyle}</h4>
                  <p className="text-xs text-gray-300 leading-relaxed font-sans">{styleResult.eraInfluenceBigIdeas}</p>
                </div>

                <div className="space-y-1.5 p-4 bg-[#121215] border border-white/5 rounded-xl">
                  <span className="text-[10px] font-mono text-emerald-400 block uppercase font-bold">Standard Spatial Rules of the style:</span>
                  <p className="text-xs text-gray-400 font-mono leading-relaxed">{styleResult.criticalProportions}</p>
                </div>

                <div className="space-y-1.5 p-4 bg-emerald-950/20 border border-emerald-900/30 rounded-xl">
                  <span className="text-[10px] font-mono text-emerald-400 block uppercase font-bold">How to make it feel modern:</span>
                  <p className="text-xs text-gray-300 leading-normal font-sans">{styleResult.modernApplicationTips}</p>
                </div>
              </div>
            )}

            {/* OPTION 4: REVISION ASSISTANT OUTPUT */}
            {activeTab === "revision" && revisionResult && (
              <div className="space-y-5 font-mono">
                
                <div className="p-3.5 bg-[#121215] border border-white/5 rounded-xl text-xs">
                  <span className="text-[10px] font-bold text-red-400 block uppercase mb-1">Decoded Client Hidden Sentiment/Emotion:</span>
                  <p className="text-gray-300 italic">"{revisionResult.clientStatedEmotion}"</p>
                </div>

                <div className="space-y-3">
                  <span className="text-xs font-bold text-gray-300 block">📋 Actionable Engineering Tasks:</span>
                  <div className="space-y-2">
                    {revisionResult.decodedTechnicalAction.map((act, idx) => (
                      <div key={idx} className="bg-white/5 p-3 border border-white/5 rounded-xl text-xs flex justify-between items-start gap-4">
                        <div>
                          <strong className="text-indigo-400 text-[10px] uppercase block mb-1">Feedback Point: "{act.issue}"</strong>
                          <p className="text-gray-300 font-sans leading-normal">{act.resolution}</p>
                        </div>
                        <span className={`text-[9px] uppercase font-bold px-2 py-0.5 rounded shrink-0 ${
                          act.priority === "High" ? "bg-red-500/20 text-red-400" : "bg-yellow-500/20 text-yellow-500"
                        }`}>
                          {act.priority} priority
                        </span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Copy Friendly Copy button */}
                <div className="space-y-2 border-t border-white/5 pt-3.5">
                  <div className="flex justify-between items-center text-[10px] font-mono text-gray-400">
                    <span>Generated Gentle Client Response Letter:</span>
                    <button 
                      onClick={() => navigator.clipboard.writeText(revisionResult.designFriendlyReplyText)}
                      className="text-emerald-400 hover:text-emerald-300 font-bold uppercase cursor-pointer"
                    >
                      Copy Letter
                    </button>
                  </div>
                  <div className="p-3 bg-emerald-950/10 border border-emerald-900/20 rounded-xl text-xs text-gray-300 leading-relaxed font-sans italic">
                    "{revisionResult.designFriendlyReplyText}"
                  </div>
                </div>

              </div>
            )}

          </div>

          <div className="border-t border-white/5 pt-4 text-center text-[10px] text-gray-500">
            {isEn ? "Diagnostic engine results may vary. Apply strict geometric grids for safety." : "আই আর্কিটেকচার রিপোর্টে কোনো মতামত সংশোধনে এআই মডিউল সাহায্য করুন।"}
          </div>

        </div>

      </div>
    </div>
  );
}
