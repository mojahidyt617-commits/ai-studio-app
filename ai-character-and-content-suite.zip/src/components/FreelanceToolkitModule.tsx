import React, { useState, useEffect } from "react";
import { LanguageCode } from "../lib/translations";
import { 
  Sparkles, FileText, Send, Award, ShoppingBag, 
  HelpCircle, Printer, Calculator, Copy, Check, DollarSign,
  PlusCircle, Trash2, Settings, Download, Briefcase
} from "lucide-react";

interface FreelanceToolkitProps {
  lang: LanguageCode;
  credits: number;
  deductCredits: (qty: number, actionTitle: string) => boolean;
}

export default function FreelanceToolkitModule({
  lang,
  credits,
  deductCredits,
}: FreelanceToolkitProps) {
  const isEn = lang === "en";

  // Navigation
  const [activeTab, setActiveTab] = useState<"proposal" | "fiverr" | "upwork" | "questions" | "invoice" | "price">("proposal");

  // State
  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState("");
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const handleCopyText = (text: string, refId: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(refId);
    setTimeout(() => setCopiedId(null), 2000);
  };

  /* ==========================================
     1. PROPOSAL GENERATOR STATE
     ========================================== */
  const [propClient, setPropClient] = useState("");
  const [propNiche, setPropNiche] = useState("Web App Layout Refactoring");
  const [propBudget, setPropBudget] = useState("$1,500");
  const [proposalResult, setProposalResult] = useState<{
    proposalTitle: string;
    executiveSummary: string;
    phases: { title: string; timeline: string; priceAllocated: string }[];
    visualSystemApproach: string;
  } | null>(() => {
    return {
      proposalTitle: "Interactive Interface Transformation System",
      executiveSummary: "We propose to overhaul your digital presence, introducing unified layouts, higher text legibility, and high-CTR interfaces to acquire maximum user trust and double registrations.",
      phases: [
        { title: "Diagnostics & Asset Auditing", timeline: "Days 1-4", priceAllocated: "$300" },
        { title: "Symmetrical Grid Layout Engineering", timeline: "Days 5-12", priceAllocated: "$800" },
        { title: "Final Asset Package Delivery & Signoff", timeline: "Days 13-15", priceAllocated: "$400" }
      ],
      visualSystemApproach: "Utilizing modern matte glassmorphism styling paired with high-contrast emerald details to highlight security."
    };
  });

  const handleGenerateProposal = async () => {
    setErrorMsg("");
    const cost = 12;
    if (credits < cost) {
      setErrorMsg(isEn ? "No credits!" : "পর্যাপ্ত ক্রেডিট নেই!");
      return;
    }
    setLoading(true);

    const promptObj = {
      client: propClient || "Starling Enterprises",
      project: propNiche,
      budget: propBudget
    };

    const systemInstruction = 
      "You are a top sales director for design agencies. Return EXACTLY a single JSON object with high-agency custom proposals containing executiveSummary and phase metrics: { proposalTitle, executiveSummary, phases: [{title, timeline, priceAllocated}], visualSystemApproach }";

    try {
      const resp = await fetch("/api/studio/general-generate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          prompt: `Create custom client proposal: ${JSON.stringify(promptObj)}`,
          systemInstruction,
          fallbackJson: {
            proposalTitle: `Strategic Brand Redesign for ${promptObj.client}`,
            executiveSummary: `Rebuilding your core brand architecture to convert customer curiosity into high emotional loyalty.`,
            phases: [
              { title: "Phase 1: Discovery", timeline: "3 Days", priceAllocated: "$250" },
              { title: "Phase 2: Visual Forging", timeline: "7 Days", priceAllocated: "$750" }
            ],
            visualSystemApproach: "Implementing strict luxury minimalism paired with generous negative space."
          }
        })
      });

      const resData = await resp.json();
      if (resData.success && resData.data) {
        setProposalResult(resData.data);
        deductCredits(cost, `Proposal Formulated: ${resData.data.proposalTitle}`);
        setPropClient("");
      }
    } catch {
      setErrorMsg("Error creating proposal.");
    } finally {
      setLoading(false);
    }
  };

  /* ==========================================
     2. FIVERR GIG GENERATOR STATE
     ========================================== */
  const [fiverrNiche, setFiverrNiche] = useState("Custom YouTube Thumbnails");
  const [fiverrResult, setFiverrResult] = useState<{
    gigTitle: string;
    gigDescription: string;
    searchTags: string[];
    tierSilver: string;
    tierGold: string;
    fiverrSEOKeywordsTip: string;
  } | null>(() => {
    return {
      gigTitle: "I will design outstanding premium high CTR thumbnails for videos in 12 hours",
      gigDescription: "Stand out in crowded feeds and increase your CTR by up to 14%! What is included: Symmetrical text hierarchies optimized for mobile devices, tailored element layouts, and high-contrast color choices.",
      searchTags: ["youtube thumbnail", "viral thumbnail", "high CTR thumbnail", "gaming banner", "video thumbnail"],
      tierSilver: "Basic Package ($15): 1x Custom Thumbnail, PNG + PSD Sources, 1 Day delivery.",
      tierGold: "Ultimate Boost Package ($45): 3x Unique Thumbnail variations, VIP Support, Unlimited revisions.",
      fiverrSEOKeywordsTip: "Place the raw term 'high CTR thumbnail' both in the start of description and search tag slots."
    };
  });

  const handleGenerateFiverr = async () => {
    setErrorMsg("");
    const cost = 10;
    if (credits < cost) {
      setErrorMsg(isEn ? "No credits!" : "পর্যাপ্ত ক্রেডিট নেই!");
      return;
    }
    setLoading(true);

    const systemInstruction = 
      "You are an SEO optimization strategist for Fiverr freelancers. Return EXACTLY a single JSON object with high conversion stats: { gigTitle, gigDescription, searchTags: [string, string], tierSilver, tierGold, fiverrSEOKeywordsTip }";

    try {
      const resp = await fetch("/api/studio/general-generate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          prompt: `Create highly optimized Fiverr gig description system for: "${fiverrNiche}"`,
          systemInstruction,
          fallbackJson: {
            gigTitle: `I will do premium branding vectors for ${fiverrNiche}`,
            gigDescription: `Accelerate brand authenticity with highly customized vectors created specifically for your target customer.`,
            searchTags: ["custom design", "brand mark", "minimalist branding"],
            tierSilver: "Standard Star ($25): 1x Vector concept, source delivery.",
            tierGold: "Exclusive ($75): Full standard identity bundle with custom brand assets.",
            fiverrSEOKeywordsTip: "Include keyword terms directly into pricing tier outlines."
          }
        })
      });

      const resData = await resp.json();
      if (resData.success && resData.data) {
        setFiverrResult(resData.data);
        deductCredits(cost, "Fiverr Gig Optimized");
      }
    } catch {
      setErrorMsg("Error matching Fiverr gigs.");
    } finally {
      setLoading(false);
    }
  };

  /* ==========================================
     3. UPWORK COVER LETTER STATE
     ========================================== */
  const [jobPosting, setJobPosting] = useState("");
  const [upworkResult, setUpworkResult] = useState<{
    attentionHook: string;
    coreValuePitch: string;
    callToAction: string;
    fullLetterCopiable: string;
  } | null>(() => {
    return {
      attentionHook: "Hi! I noticed PayShield Global is struggling with mobile registration bounce rates. I recently completed a similar overhaul for a SaaS firm that drove registrations up by 44% in just 30 days.",
      coreValuePitch: "I focus strongly on implementing clean responsive grid systems, enforcing optimal margin balances (so elements never feel compressed), and testing high-gaze typography rules.",
      callToAction: "Let's align for a quick 10-minute briefing call so I can lay out a wireframe blueprint live for GreenCart.",
      fullLetterCopiable: "Dear Client,\n\nI noticed your job posting detailing mobile registration issues. By applying strict visual symmetry, mobile-first font sizes, and custom-saturated CTA highlights, I can overhaul PayShield Global to transform cold clicks into high trust.\n\nI recently delivered a SaaS interface update that grew completed registrations by 44% in 30 days. Let me schedule a quick 10-minute briefing to demonstrate some blueprint structures.\n\nBest regards,\nProfessional Creative"
    };
  });

  const handleGenerateUpwork = async () => {
    setErrorMsg("");
    const cost = 10;
    if (credits < cost) {
      setErrorMsg(isEn ? "No credits!" : "পর্যাপ্ত ক্রেডিট নেই!");
      return;
    }
    setLoading(true);

    const systemInstruction = 
      "You are a top-rated Upwork consultant. Convert job postings into winning personalized cover letters. Return EXACTLY a single JSON object: { attentionHook, coreValuePitch, callToAction, fullLetterCopiable }";

    try {
      const resp = await fetch("/api/studio/general-generate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          prompt: `Upwork application tailored for Job Listing: "${jobPosting || "Need a brand designer for online store logo"}"`,
          systemInstruction,
          fallbackJson: {
            attentionHook: "Greeting. I noticed your requirement for premium brand logos.",
            coreValuePitch: "I treat branding symbols as high-value intellectual assets.",
            callToAction: "Let's review past case studies directly on a short discussion.",
            fullLetterCopiable: "Hi there!\n\nI reviewed your design requirements. I build custom, high-gaze symbols with detailed guidelines."
          }
        })
      });

      const resData = await resp.json();
      if (resData.success && resData.data) {
        setUpworkResult(resData.data);
        deductCredits(cost, "Tailored Upwork Proposal Letter");
        setJobPosting("");
      }
    } catch {
      setErrorMsg("Error preparing Upwork letters.");
    } finally {
      setLoading(false);
    }
  };

  /* ==========================================
     4. CLIENT QUESTIONNAIRE ONBOARDING STATE
     ========================================== */
  const [onboardCategory, setOnboardCategory] = useState("Corporate Brand Identity");
  const [questionsResult, setQuestionsResult] = useState<{
    questionsList: { question: string; purpose: string }[];
  } | null>(() => {
    return {
      questionsList: [
        { question: "What are the three most critical feelings you want a customer to experience within 2 seconds of looking at your brand?", purpose: "Establishes baseline color and visual energy guidelines." },
        { question: "Who are your top three most direct competitors, and what specific design attribute (if any) do you dislike about their portals?", purpose: "Ensures visual separation and prevents matching common layouts." },
        { question: "Do you have any absolute negative constraints? (e.g., 'Never use yellow color', 'No corporate geometric grids?')", purpose: "Prevents wasted design phases and alignment errors." }
      ]
    };
  });

  const handleGenerateQuestions = async () => {
    setErrorMsg("");
    const cost = 5;
    if (credits < cost) {
      setErrorMsg(isEn ? "No credits!" : "পর্যাপ্ত ক্রেডিট নেই!");
      return;
    }
    setLoading(true);

    const systemInstruction = 
      "You are an onboarding specialist for design clients. Return EXACTLY a single JSON object with high-agency questions: { questionsList: [{question, purpose}] }";

    try {
      const resp = await fetch("/api/studio/general-generate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          prompt: `Create design onboarding questionnaire for: "${onboardCategory}"`,
          systemInstruction,
          fallbackJson: {
            questionsList: [
              { question: "What is the primary product of your firm?", purpose: "Base knowledge." }
            ]
          }
        })
      });

      const resData = await resp.json();
      if (resData.success && resData.data) {
        setQuestionsResult(resData.data);
        deductCredits(cost, `Onboarding Kit: ${onboardCategory}`);
      }
    } catch {
      setErrorMsg("Error compiling questions.");
    } finally {
      setLoading(false);
    }
  };

  /* ==========================================
     5. INVOICE GENERATOR STATE (INTERACTIVE REACT CALCULATOR)
     ========================================== */
  const [invClientName, setInvClientName] = useState("Acme Labs Inc");
  const [invItems, setInvItems] = useState([
    { desc: "High-CTR Landing Page Wireframe Layout", qty: 1, unitPrice: 850 },
    { desc: "Social Media Campaign Visual Suite", qty: 4, unitPrice: 150 }
  ]);
  const [invTaxPct, setInvTaxPct] = useState(5);
  const [invDiscount, setInvDiscount] = useState(50);

  const addNewInvoiceItem = () => {
    setInvItems([...invItems, { desc: "Custom Graphic Deliverable", qty: 1, unitPrice: 100 }]);
  };

  const deleteInvoiceItem = (idx: number) => {
    const updated = invItems.filter((_, i) => i !== idx);
    setInvItems(updated);
  };

  const updateItemField = (idx: number, field: "desc" | "qty" | "unitPrice", value: any) => {
    const updated = [...invItems];
    updated[idx] = { ...updated[idx], [field]: value };
    setInvItems(updated);
  };

  // Compute values
  const subtotal = invItems.reduce((sum, item) => sum + (item.qty * item.unitPrice), 0);
  const discountAmount = invDiscount;
  const taxableAmount = Math.max(0, subtotal - discountAmount);
  const taxAmount = (taxableAmount * invTaxPct) / 100;
  const totalDue = taxableAmount + taxAmount;

  /* ==========================================
     6. DESIGN PRICING CALCULATOR STATE
     ========================================== */
  const [estHours, setEstHours] = useState(25);
  const [hourlyTarget, setHourlyTarget] = useState(50);
  const [projectComplexity, setProjectComplexity] = useState("High (Custom Graphics & Blueprints)");
  const [overheadExpenses, setOverheadExpenses] = useState(150);

  // Math calculated dynamically
  const baseCostPrice = (estHours * hourlyTarget) + Number(overheadExpenses);
  const markupMultiplier = projectComplexity.includes("High") ? 1.45 : projectComplexity.includes("Medium") ? 1.25 : 1.10;
  const targetProjectPrice = Math.round(baseCostPrice * markupMultiplier);
  const clientNetProfit = Math.round(targetProjectPrice - baseCostPrice);
  const marginPercentage = Math.round((clientNetProfit / targetProjectPrice) * 100) || 0;
  const suggestedDeposit50 = Math.round(targetProjectPrice * 0.5);


  return (
    <div className="bg-[#111115] border border-white/5 rounded-3xl p-4 sm:p-8 space-y-8 text-white relative">
      {/* Light highlights */}
      <div className="absolute top-0 left-0 w-64 h-64 bg-amber-500/5 blur-[90px] pointer-events-none rounded-full" />

      {/* Header Panel */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 border-b border-white/5 pb-6">
        <div>
          <h2 className="text-xl sm:text-2xl font-display font-medium text-white flex items-center gap-2">
            <DollarSign className="w-6 h-6 text-amber-500" />
            <span>{isEn ? "Freelancer Space Toolkit" : "ফ্রিল্যান্সার স্পেস টুলকিট"}</span>
            <span className="text-[10px] bg-amber-500/20 text-amber-400 border border-amber-500/30 px-2 py-0.5 rounded-full uppercase font-mono">
              Business Suite
            </span>
          </h2>
          <p className="text-xs text-gray-400 mt-1">
            {isEn ? "Accelerate gig creation, write persuasive client proposals, invoice seamlessly, and calculate margins." : "ক্লায়েন্ট ডিল শেষ করা, ইনভয়েস তৈরি এবং গিগ ডেভেলপমেন্ট মডিউল।"}
          </p>
        </div>

        {/* Tab Selection */}
        <div className="flex flex-wrap gap-1.5 p-1 bg-white/5 border border-white/5 rounded-2xl">
          {[
            { id: "proposal", label: isEn ? "Proposal Maker" : "প্রপোজাল", icon: FileText },
            { id: "fiverr", label: isEn ? "Fiverr Gigs" : "ফাইভার গিগ", icon: ShoppingBag },
            { id: "upwork", label: isEn ? "Upwork Letter" : "আপওয়ার্ক কভার", icon: Send },
            { id: "questions", label: isEn ? "Client Onboard" : "ক্লায়েন্ট প্রশ্ন", icon: HelpCircle },
            { id: "invoice", label: isEn ? "Smart Invoice" : "ইনভয়েস মেকার", icon: Printer },
            { id: "price", label: isEn ? "Pricing Calc" : "প্রাইসিং ক্যালক", icon: Calculator },
          ].map((item) => {
            const Icon = item.icon;
            return (
              <button
                key={item.id}
                onClick={() => {
                  setActiveTab(item.id as any);
                  setErrorMsg("");
                }}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold cursor-pointer transition-all ${
                  activeTab === item.id
                    ? "bg-amber-600 text-white shadow-md shadow-amber-950/40"
                    : "text-gray-400 hover:text-white hover:bg-white/5"
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                <span>{item.label}</span>
              </button>
            );
          })}
        </div>
      </div>

      {errorMsg && (
        <div className="p-4 bg-red-900/10 border border-red-500/20 rounded-2xl text-xs text-red-100">
          {errorMsg}
        </div>
      )}

      {/* CORE SPLIT WORK AREA */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* LEFT COLUMN PANEL INPUT */}
        <div className="lg:col-span-5 space-y-6 bg-white/5 border border-white/5 p-6 rounded-2xl">
          
          {/* 1. PROPOSAL GENERATOR INPUT */}
          {activeTab === "proposal" && (
            <div className="space-y-4">
              <h3 className="text-sm font-semibold tracking-wider text-gray-300 uppercase flex items-center gap-2">
                <FileText className="w-4 h-4 text-amber-400" />
                <span>{isEn ? "Generate Project Proposal" : "প্রপোজাল মেকার"}</span>
              </h3>
              <p className="text-xs text-gray-400">
                {isEn ? "Instantly compile a tailored proposal with milestones and visual strategy breakdowns." : "ক্লায়েন্ট নাম প্রজেক্ট বাজেট দিলে এআই সুন্দর ফরমাল প্রপোজাল শীট লিখে দেবে।"}
              </p>

              <div className="space-y-1.5">
                <label className="text-xs font-medium text-gray-300">{isEn ? "Client Brand Name" : "ক্লায়েন্ট ফার্ম নাম"}</label>
                <input
                  type="text"
                  placeholder="e.g., Horizon Travel Club"
                  value={propClient}
                  onChange={(e) => setPropClient(e.target.value)}
                  className="w-full bg-black/40 border border-white/15 rounded-xl p-3 text-xs text-white focus:outline-none focus:border-amber-500 transition-all font-sans"
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-medium text-gray-300">{isEn ? "Project Task & Deliverables" : "সার্ভিস নিশ"}</label>
                <input
                  type="text"
                  placeholder="e.g., Vector Branding overhaul & mobile banners"
                  value={propNiche}
                  onChange={(e) => setPropNiche(e.target.value)}
                  className="w-full bg-black/40 border border-white/15 rounded-xl p-3 text-xs text-white focus:outline-none focus:border-amber-500 transition-all"
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-medium text-gray-300">{isEn ? "Budget Limit (Target)" : "ডিজাইন বাজেট"}</label>
                <input
                  type="text"
                  placeholder="e.g., $1,200"
                  value={propBudget}
                  onChange={(e) => setPropBudget(e.target.value)}
                  className="w-full bg-black/40 border border-white/15 rounded-xl p-2.5 text-xs text-white focus:outline-none focus:border-amber-500 transition-all font-mono"
                />
              </div>

              <button
                onClick={handleGenerateProposal}
                disabled={loading}
                className="w-full bg-amber-600 hover:bg-amber-500 disabled:opacity-50 text-white font-semibold py-3 px-4 rounded-xl text-xs flex items-center justify-center gap-2 cursor-pointer transition-all shadow-md shadow-amber-950/40"
              >
                <Sparkles className="w-3.5 h-3.5" />
                <span>{loading ? "Aligning Scope..." : (isEn ? "Generate Proposal (12 Credits)" : "প্রপোজাল বানান (১২ ক্রেডিট)")}</span>
              </button>
            </div>
          )}

          {/* 2. FIVERR GIG GENERATOR INPUT */}
          {activeTab === "fiverr" && (
            <div className="space-y-4">
              <h3 className="text-sm font-semibold tracking-wider text-gray-300 uppercase flex items-center gap-2">
                <ShoppingBag className="w-4 h-4 text-amber-400" />
                <span>{isEn ? "Fiverr Gig Optimization" : "ফাইভার গিগ অপ্টিমাইজেশন"}</span>
              </h3>
              <p className="text-xs text-gray-400">
                {isEn ? "Draft highly searchable titles, clear tier options, and SEO descriptions containing your key phrases." : "আপনার সার্ভিস নিশ নির্বাচন করে উচ্চমানের এসইও ফ্রেন্ডলি গিগ তৈরি করুন।"}
              </p>

              <div className="space-y-1.5">
                <label className="text-xs font-medium text-gray-300">{isEn ? "Gig Service Category" : "গিগ ক্যাটাগরি"}</label>
                <input
                  type="text"
                  placeholder="e.g., UI Web wireframes, Gaming logo design"
                  value={fiverrNiche}
                  onChange={(e) => setFiverrNiche(e.target.value)}
                  className="w-full bg-black/40 border border-white/15 rounded-xl p-3 text-xs text-white focus:outline-none focus:border-amber-500 transition-all font-semibold"
                />
              </div>

              <button
                onClick={handleGenerateFiverr}
                disabled={loading || !fiverrNiche.trim()}
                className="w-full bg-amber-600 hover:bg-amber-500 disabled:opacity-50 text-white font-semibold py-3 px-4 rounded-xl text-xs flex items-center justify-center gap-2 cursor-pointer transition-all"
              >
                <ShoppingBag className="w-3.5 h-3.5" />
                <span>{loading ? "Structuring Gig SEO..." : (isEn ? "Draft Fiverr Gigs (10 Credits)" : "ফাইভার গিগ লিখুন (১০ ক্রেডিট)")}</span>
              </button>
            </div>
          )}

          {/* 3. UPWORK LETTER INPUT */}
          {activeTab === "upwork" && (
            <div className="space-y-4">
              <h3 className="text-sm font-semibold tracking-wider text-gray-300 uppercase flex items-center gap-2">
                <Send className="w-4 h-4 text-amber-400" />
                <span>{isEn ? "Winning Upwork Letter" : "আপওয়ার্ক প্রপোজাল"}</span>
              </h3>
              <p className="text-xs text-gray-400">
                {isEn ? "Paste raw job post description; AI drafts a stunning cover letter framing your strategic value." : "ক্লায়েন্টের জব ডেসক্রিপশন পেস্ট করলে এক ক্লিকে সেরা কভার লেটার তৈরি করে দেবে।"}
              </p>

              <div className="space-y-1.5">
                <label className="text-xs font-medium text-gray-300">{isEn ? "Job Description Posting" : "জব ডেসক্রিপশন পেস্ট করুন"}</label>
                <textarea
                  rows={4}
                  placeholder="Paste actual Upwork job criteria details here..."
                  value={jobPosting}
                  onChange={(e) => setJobPosting(e.target.value)}
                  className="w-full bg-black/40 border border-white/15 rounded-xl p-3 text-xs text-white focus:outline-none focus:border-amber-500 transition-all font-mono"
                />
              </div>

              <button
                onClick={handleGenerateUpwork}
                disabled={loading || !jobPosting.trim()}
                className="w-full bg-amber-600 hover:bg-amber-500 disabled:opacity-50 text-white font-semibold py-3 px-4 rounded-xl text-xs flex items-center justify-center gap-2 cursor-pointer transition-all font-semibold uppercase"
              >
                <Send className="w-3.5 h-3.5" />
                <span>{loading ? "Matching Credential Pitch..." : (isEn ? "Write Custom Proposal Letter (10 Credits)" : "কভার লেটার বানান (১০ ক্রেডিট)")}</span>
              </button>
            </div>
          )}

          {/* 4. CLIENT QUESTIONS INPUT */}
          {activeTab === "questions" && (
            <div className="space-y-4">
              <h3 className="text-sm font-semibold tracking-wider text-gray-300 uppercase flex items-center gap-2">
                <HelpCircle className="w-4 h-4 text-amber-400" />
                <span>{isEn ? "Client Onboarding Onboard" : "ক্লায়েন্ট অনবোর্ডিং ফর্ম"}</span>
              </h3>
              <p className="text-xs text-gray-400">
                {isEn ? "Acquire highly analytical questionnaires that eliminate project delays or messy endless feedback loops." : "ক্লায়েন্টকে অনবোর্ডিং করানোর সময় কি কি প্রফেশনাল প্রশ্ন জিজ্ঞেস করবেন তার তালিকা বের করুন।"}
              </p>

              <div className="space-y-1.5">
                <label className="text-xs font-medium text-gray-300">{isEn ? "Project Category Focus" : "ডিজাইন প্রোজেক্ট ক্যাটাগরি"}</label>
                <input
                  type="text"
                  placeholder="e.g., Luxury Cosmetics Rebranding"
                  value={onboardCategory}
                  onChange={(e) => setOnboardCategory(e.target.value)}
                  className="w-full bg-black/40 border border-white/15 rounded-xl p-3 text-xs text-white focus:outline-none focus:border-amber-500 transition-all"
                />
              </div>

              <button
                onClick={handleGenerateQuestions}
                disabled={loading || !onboardCategory.trim()}
                className="w-full bg-amber-600 hover:bg-amber-500 disabled:opacity-50 text-white font-semibold py-3 px-4 rounded-xl text-xs flex items-center justify-center gap-2 cursor-pointer transition-all"
              >
                <HelpCircle className="w-3.5 h-3.5" />
                <span>{loading ? "Drafting Questions..." : (isEn ? "Build Client Questionnaire (5 Credits)" : "প্রশ্নমালা তালিকা তৈরি (৫ ক্রেডিট)")}</span>
              </button>
            </div>
          )}

          {/* 5. INVOICE GENERATOR INPUTS */}
          {activeTab === "invoice" && (
            <div className="space-y-4">
              <h3 className="text-sm font-semibold tracking-wider text-gray-300 uppercase flex items-center gap-2">
                <Printer className="w-4 h-4 text-amber-450" />
                <span>{isEn ? "Designer Smart Invoicing" : "ইনভয়েস প্যারামিটারস"}</span>
              </h3>
              <p className="text-xs text-gray-400">
                {isEn ? "Compile beautiful invoices live. Add items, compute Taxes, discounts, and copy with single click." : "আপনার কাজের বিবরণী দিয়ে কাস্টম ইনভয়েস শিট তৈরি করুন।"}
              </p>

              <div className="space-y-1.5">
                <label className="text-xs font-medium text-gray-300">{isEn ? "Client Identity Name" : "বিলিং ক্লায়েন্ট নাম"}</label>
                <input
                  type="text"
                  value={invClientName}
                  onChange={(e) => setInvClientName(e.target.value)}
                  className="w-full bg-black/40 border border-white/15 rounded-xl p-2.5 text-xs text-white focus:outline-none focus:border-amber-500 font-bold"
                />
              </div>

              <div className="space-y-2">
                <span className="text-[10px] font-mono text-gray-400 block uppercase">Line Items list:</span>
                <div className="space-y-2 max-h-[160px] overflow-y-auto pr-1">
                  {invItems.map((item, idx) => (
                    <div key={idx} className="bg-black/30 border border-white/5 p-2 rounded-xl text-xs space-y-1.5 relative group">
                      <input
                        type="text"
                        value={item.desc}
                        onChange={(e) => updateItemField(idx, "desc", e.target.value)}
                        className="w-full bg-transparent border-b border-white/10 text-xs text-indigo-200 focus:outline-none"
                      />
                      <div className="flex gap-2 justify-between items-center">
                        <div className="flex items-center gap-1.5">
                          <span className="text-[9px] text-gray-500">Qty:</span>
                          <input
                            type="number"
                            value={item.qty}
                            onChange={(e) => updateItemField(idx, "qty", Number(e.target.value))}
                            className="bg-black/40 w-12 text-center rounded border border-white/10 p-0.5 text-xs text-white"
                          />
                        </div>
                        <div className="flex items-center gap-1.5 font-mono">
                          <span className="text-[9px] text-gray-500">Price:</span>
                          <input
                            type="number"
                            value={item.unitPrice}
                            onChange={(e) => updateItemField(idx, "unitPrice", Number(e.target.value))}
                            className="bg-black/40 w-16 text-center rounded border border-white/10 p-0.5 text-xs text-white"
                          />
                        </div>
                        <button 
                          onClick={() => deleteInvoiceItem(idx)}
                          className="p-1 hover:bg-white/5 text-red-400 rounded-md cursor-pointer transition-colors"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
                <button
                  onClick={addNewInvoiceItem}
                  className="w-full py-1.5 border border-dashed border-white/15 text-[10px] font-bold text-gray-400 hover:text-white rounded-xl transition-all cursor-pointer flex justify-center items-center gap-1"
                >
                  <PlusCircle className="w-3 h-3" />
                  <span>{isEn ? "Add Invoice Line Item" : "নতুন কাজ যোগ করুন"}</span>
                </button>
              </div>

              <div className="grid grid-cols-2 gap-2 font-mono">
                <div>
                  <label className="text-[10px] text-gray-400 block mb-0.5">Tax Percentage (%)</label>
                  <input
                    type="number"
                    value={invTaxPct}
                    onChange={(e) => setInvTaxPct(Number(e.target.value))}
                    className="w-full bg-black/40 border border-white/15 rounded-lg p-2 text-xs text-white"
                  />
                </div>
                <div>
                  <label className="text-[10px] text-gray-400 block mb-0.5">Discount Amount ($)</label>
                  <input
                    type="number"
                    value={invDiscount}
                    onChange={(e) => setInvDiscount(Number(e.target.value))}
                    className="w-full bg-black/40 border border-white/15 rounded-lg p-2 text-xs text-white"
                  />
                </div>
              </div>
            </div>
          )}

          {/* 6. DESIGN PRICING CALCULATOR INPUTS */}
          {activeTab === "price" && (
            <div className="space-y-4">
              <h3 className="text-sm font-semibold tracking-wider text-gray-300 uppercase flex items-center gap-2">
                <Calculator className="w-4 h-4 text-amber-400" />
                <span>{isEn ? "Suggested Design Pricing" : "ডিজাইন প্রাইসিং পরিমাপ"}</span>
              </h3>
              <p className="text-xs text-gray-400">
                {isEn ? "Align hours, targets, and project complexity to estimate target pricing, profit parameters, and deposit systems." : "আপনার কাজের সময়, রেট এবং ক্লায়েন্ট জটিলতা বিবেচনা করে চূড়ান্ত বাজেট নির্ধারণ করুন।"}
              </p>

              <div className="space-y-1.5 font-mono">
                <label className="text-xs font-medium text-gray-300">{isEn ? "Estimated Hours of Work" : "সম্ভাব্য কাজের ঘণ্টা"}</label>
                <input
                  type="range"
                  min={5}
                  max={120}
                  step={1}
                  value={estHours}
                  onChange={(e) => setEstHours(Number(e.target.value))}
                  className="w-full h-1.5 bg-white/10 rounded-lg appearance-none cursor-pointer"
                />
                <div className="flex justify-between text-[11px] text-gray-400 mt-1">
                  <span>5 Hours</span>
                  <span className="text-amber-400 font-bold">{estHours} Hours Estimated</span>
                  <span>120 Hours</span>
                </div>
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-medium text-gray-300">{isEn ? "Your Raw Target Hourly Rate ($)" : "আপনার ঘণ্টা প্রতি রেট"}</label>
                <input
                  type="number"
                  value={hourlyTarget}
                  onChange={(e) => setHourlyTarget(Number(e.target.value))}
                  className="w-full bg-black/40 border border-white/15 rounded-xl p-3 text-xs text-white focus:outline-none focus:border-amber-500 font-mono"
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-medium text-gray-300">{isEn ? "Project Complexity multiplier" : "প্রজেক্ট জটিলতা লেভেল"}</label>
                <select
                  value={projectComplexity}
                  onChange={(e) => setProjectComplexity(e.target.value)}
                  className="w-full bg-black/40 border border-white/15 rounded-xl p-3 text-xs text-white"
                >
                  <option value="Basic Layout template">☕ Basic Template (1.10x Multiplier)</option>
                  <option value="Medium Custom adjustments">🛠️ Medium Corporate (1.25x Multiplier)</option>
                  <option value="High (Custom Graphics & Blueprints)">⚡ Ultra custom complex requirements (1.45x Multiplier)</option>
                </select>
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-medium text-gray-300">{isEn ? "Software/Stock over head expenses ($)" : "সফটওয়্যার/অনুষঙ্গিক খরচ"}</label>
                <input
                  type="number"
                  value={overheadExpenses}
                  onChange={(e) => setOverheadExpenses(Number(e.target.value))}
                  className="w-full bg-black/40 border border-white/15 rounded-xl p-3 text-xs text-white focus:outline-none focus:border-amber-500 font-mono"
                />
              </div>
            </div>
          )}

        </div>

        {/* RIGHT COLUMN OUTPUT GORGEOUS BLUEPRINT DISPLAY */}
        <div className="lg:col-span-7 bg-black/55 border border-white/5 p-6 rounded-2xl flex flex-col justify-between min-h-[460px] relative">
          
          {loading && (
            <div className="absolute inset-0 bg-black/85 backdrop-blur-sm z-20 flex flex-col items-center justify-center space-y-4 rounded-2xl">
              <div className="w-10 h-10 border-4 border-amber-500 border-t-transparent rounded-full animate-spin" />
              <p className="text-xs font-mono text-amber-300 uppercase animate-pulse tracking-wide">
                Refining freelance business strategies from Gemini...
              </p>
            </div>
          )}

          <div className="space-y-6">
            <div className="flex items-center justify-between border-b border-white/5 pb-3">
              <span className="text-[10px] font-mono tracking-wider text-gray-500 uppercase flex items-center gap-1.5">
                <span className="w-1.5 h-1.5 bg-amber-500 rounded-full animate-pulse" />
                <span>Freelance Production Outcome</span>
              </span>
              <span className="text-[9px] bg-amber-500/10 text-amber-400 border border-amber-500/20 px-2 py-0.5 rounded font-mono uppercase">
                {activeTab} preview
              </span>
            </div>

            {/* RENDER 1: PROPOSAL OUTPUT */}
            {activeTab === "proposal" && proposalResult && (
              <div className="space-y-5">
                <div className="flex justify-between items-center">
                  <h4 className="text-md font-semibold text-white">{proposalResult.proposalTitle}</h4>
                  <button 
                    onClick={() => handleCopyText(JSON.stringify(proposalResult, null, 2), "p_json")}
                    className="text-xs text-amber-400 hover:text-amber-300 flex items-center gap-1 cursor-pointer"
                  >
                    <Copy className="w-3.5 h-3.5" />
                    <span>{copiedId === "p_json" ? "Copied" : "Copy Blueprint"}</span>
                  </button>
                </div>

                <div className="p-4 bg-white/5 border border-white/5 rounded-xl space-y-1">
                  <span className="text-[10px] text-amber-400 uppercase font-mono block font-bold">Executive Summary Objective:</span>
                  <p className="text-xs text-gray-300 leading-relaxed font-sans">{proposalResult.executiveSummary}</p>
                </div>

                {/* Scope list */}
                <div className="space-y-2.5">
                  <span className="text-xs font-bold text-gray-300 block">⭐ Project Phases and Funding Allocations:</span>
                  <div className="space-y-2">
                    {proposalResult.phases.map((ph, i) => (
                      <div key={i} className="bg-black/40 border border-white/5 p-3 rounded-xl flex justify-between items-center gap-4">
                        <div>
                          <h5 className="text-xs font-bold text-white mb-0.5">{ph.title}</h5>
                          <span className="text-[10px] text-gray-400">{ph.timeline}</span>
                        </div>
                        <span className="text-xs font-mono font-bold text-amber-400 bg-amber-500/10 border border-amber-500/20 px-2.5 py-1 rounded-lg">
                          {ph.priceAllocated}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="flex items-center gap-2 text-xs text-gray-400">
                  <span className="text-amber-400 font-bold font-mono">Visual Target Path:</span>
                  <span>{proposalResult.visualSystemApproach}</span>
                </div>
              </div>
            )}

            {/* RENDER 2: FIVERR GIG OUTPUT */}
            {activeTab === "fiverr" && fiverrResult && (
              <div className="space-y-5">
                <div className="space-y-2">
                  <span className="text-[10px] font-mono uppercase text-amber-400 font-semibold block">Optimized SEO Gig Title:</span>
                  <div className="bg-[#121215] border border-white/5 p-3.5 rounded-xl font-sans text-xs text-bold tracking-tight">
                    {fiverrResult.gigTitle}
                  </div>
                </div>

                <div className="space-y-2">
                  <span className="text-[10px] font-mono uppercase text-amber-400 font-semibold block">Persuasive Gig Description:</span>
                  <p className="text-xs text-gray-300 leading-relaxed font-sans block bg-white/5 p-4 border border-white/5 rounded-xl">
                    {fiverrResult.gigDescription}
                  </p>
                </div>

                {/* Tiers outline */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs">
                  <div className="bg-black/30 border border-white/5 p-3 rounded-lg">
                    <span className="text-[9px] font-mono uppercase text-gray-500 block mb-1">Standard Option tier:</span>
                    <p className="text-gray-300 leading-relaxed">{fiverrResult.tierSilver}</p>
                  </div>
                  <div className="bg-amber-950/10 border border-amber-900/30 p-3 rounded-lg">
                    <span className="text-[9px] font-mono uppercase text-amber-400 block mb-1">Premium Option tier:</span>
                    <p className="text-gray-300 leading-relaxed">{fiverrResult.tierGold}</p>
                  </div>
                </div>

                {/* SEO tips */}
                <div className="p-3 bg-amber-500/10 border border-amber-500/20 rounded-xl text-xs flex justify-between items-center gap-4">
                  <span className="text-[11px] text-amber-300">💡 <strong>SEO Strategy:</strong> {fiverrResult.fiverrSEOKeywordsTip}</span>
                  <button 
                    onClick={() => handleCopyText(fiverrResult.gigDescription, "f_desc")}
                    className="text-xs text-amber-450 hover:text-amber-300 font-bold cursor-pointer underline shrink-0"
                  >
                    {copiedId === "f_desc" ? "Copied" : "Copy Description"}
                  </button>
                </div>
              </div>
            )}

            {/* RENDER 3: UPWORK LETTER */}
            {activeTab === "upwork" && upworkResult && (
              <div className="space-y-5">
                <div className="space-y-3 font-sans">
                  <div>
                    <span className="text-[10px] font-mono text-amber-400 block mb-1">🔥 THE HOOK (First 2 sentences are crucial):</span>
                    <p className="text-xs bg-emerald-500/10 border border-emerald-500/15 p-3 rounded-xl text-emerald-300">
                      {upworkResult.attentionHook}
                    </p>
                  </div>

                  <div>
                    <span className="text-[10px] font-mono text-amber-400 block mb-1">🎨 CUSTOM CASE CREDENTIALS:</span>
                    <p className="text-xs bg-white/5 border border-white/5 p-3 rounded-xl text-gray-300">
                      {upworkResult.coreValuePitch}
                    </p>
                  </div>
                </div>

                <div className="space-y-2">
                  <div className="flex justify-between items-center text-[10px] font-mono text-gray-400">
                    <span>COMPLETE PROPOSAL LETTER:</span>
                    <button 
                      onClick={() => handleCopyText(upworkResult.fullLetterCopiable, "u_letter")}
                      className="text-amber-400 hover:text-amber-300 font-bold uppercase cursor-pointer"
                    >
                      {copiedId === "u_letter" ? "Copied Letter!" : "Copy Letter"}
                    </button>
                  </div>
                  <pre className="p-4 bg-[#0a0a0c] border border-white/5 rounded-xl text-xs text-gray-300 overflow-y-auto max-h-[160px] font-sans leading-normal whitespace-pre-wrap">
                    {upworkResult.fullLetterCopiable}
                  </pre>
                </div>
              </div>
            )}

            {/* RENDER 4: CLIENT QUESTIONS */}
            {activeTab === "questions" && questionsResult && (
              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <span className="text-xs font-bold text-gray-300">Custom Onboarding Question List:</span>
                  <button 
                    onClick={() => handleCopyText(questionsResult.questionsList.map((q, i) => `${i+1}. ${q.question}`).join("\n\n"), "q_list")}
                    className="text-xs text-amber-400 hover:text-amber-300 uppercase font-bold cursor-pointer"
                  >
                    {copiedId === "q_list" ? "Copied Questions" : "Copy Questions"}
                  </button>
                </div>

                <div className="space-y-3">
                  {questionsResult.questionsList.map((q, index) => (
                    <div key={index} className="bg-[#121215] border border-white/5 p-3.5 rounded-xl space-y-1.5">
                      <p className="text-xs font-bold text-white">{index + 1}. {q.question}</p>
                      <p className="text-[11px] text-gray-400">
                        <strong className="text-amber-400/90 font-medium font-mono text-[10px] uppercase">Purpose of this query:</strong> {q.purpose}
                      </p>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* RENDER 5: INVOICE GENERATOR DISPLAY (INTERACTIVE) */}
            {activeTab === "invoice" && (
              <div className="space-y-5 bg-white/5 border border-white/5 rounded-2xl p-6 font-sans">
                <div className="flex justify-between border-b border-white/10 pb-4">
                  <div>
                    <h5 className="text-[10px] font-mono text-gray-500 uppercase tracking-widest">Billing Invoice</h5>
                    <h4 className="text-xs font-bold text-white mt-1">CLIENT: {invClientName}</h4>
                  </div>
                  <div className="text-right">
                    <span className="text-[9px] bg-amber-500/10 text-amber-400 border border-amber-500/20 px-2 py-0.5 rounded uppercase font-bold">
                      INVOICE PROMPT MODEL
                    </span>
                    <p className="text-[10px] text-gray-500 font-mono mt-1">Date: {new Date().toLocaleDateString()}</p>
                  </div>
                </div>

                {/* Table list */}
                <div className="space-y-2.5">
                  <div className="grid grid-cols-12 text-[10px] font-mono text-gray-500 uppercase border-b border-white/5 pb-1">
                    <span className="col-span-8">Description of service</span>
                    <span className="col-span-2 text-center">Qty / Rate</span>
                    <span className="col-span-2 text-right">Sum</span>
                  </div>

                  <div className="space-y-2 max-h-[140px] overflow-y-auto pr-1">
                    {invItems.map((item, i) => (
                      <div key={i} className="grid grid-cols-12 text-xs text-gray-300">
                        <span className="col-span-8 truncate italic">"{item.desc}"</span>
                        <span className="col-span-2 text-center text-gray-500 font-mono">
                          {item.qty}x / ${item.unitPrice}
                        </span>
                        <span className="col-span-2 text-right font-mono text-indigo-300">
                          ${item.qty * item.unitPrice}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Computations list */}
                <div className="border-t border-white/10 pt-4 space-y-1.5 text-xs">
                  <div className="flex justify-between text-gray-400">
                    <span>Subtotal Services Amount:</span>
                    <span className="font-mono text-white">${subtotal}</span>
                  </div>
                  
                  {invDiscount > 0 && (
                    <div className="flex justify-between text-red-400">
                      <span>Refining Discount Limit:</span>
                      <span className="font-mono">-${invDiscount}</span>
                    </div>
                  )}

                  <div className="flex justify-between text-gray-400">
                    <span>Applied Tax Volume ({invTaxPct}%):</span>
                    <span className="font-mono text-white">${taxAmount.toFixed(1)}</span>
                  </div>

                  <div className="flex justify-between border-t border-white/5 pt-2 text-sm font-bold text-white bg-white/5 p-2 rounded-lg">
                    <span className="flex items-center gap-1.5 uppercase tracking-wide text-xs">
                      🏆 Total Billing Due:
                    </span>
                    <span className="font-mono text-amber-400 text-md">${totalDue.toFixed(1)}</span>
                  </div>
                </div>

                {/* Actions */}
                <div className="flex gap-2">
                  <button 
                    onClick={() => handleCopyText(`Invoice to: ${invClientName}\nItems:\n${invItems.map(itm => `- ${itm.desc} x${itm.qty}: $${itm.unitPrice * itm.qty}`).join("\n")}\nDiscount: -$${invDiscount}\nTax: %${invTaxPct}\nTotal Due: $${totalDue}`, "inv_copy")}
                    className="flex-1 py-2 bg-amber-600 hover:bg-amber-500 text-white font-bold text-[11px] rounded-xl cursor-pointer transition-all uppercase flex justify-center items-center gap-1.5"
                  >
                    <Printer className="w-3.5 h-3.5" />
                    <span>{copiedId === "inv_copy" ? "Copied" : "Copy Live Invoice Sheet"}</span>
                  </button>
                </div>
              </div>
            )}

            {/* RENDER 6: PRICING DESIGN CALCULATOR DISPLAY */}
            {activeTab === "price" && (
              <div className="space-y-6">
                
                {/* Huge Pricing suggestion output circular box */}
                <div className="bg-gradient-to-br from-amber-950/20 to-neutral-900 border border-amber-500/20 p-6 rounded-2xl text-center relative overflow-hidden">
                  <div className="absolute top-2.5 right-2.5 text-[8px] font-mono text-amber-400 bg-amber-500/10 border border-amber-500/20 px-2 py-0.5 rounded uppercase">Target System pricing</div>
                  <span className="text-[10px] font-mono text-gray-500 uppercase tracking-widest block mb-1">Suggested Premium Quote</span>
                  <h3 className="text-3xl font-black font-mono text-amber-400">${targetProjectPrice}</h3>
                  <p className="text-xs text-gray-300 mt-2">
                    Hourly budget: {estHours} Hours at ${hourlyTarget}/Hr base + stock supplies markup ({Math.round(markupMultiplier * 100)}% rating complexity).
                  </p>
                </div>

                {/* Sub margins block */}
                <div className="grid grid-cols-2 gap-3 text-xs leading-normal">
                  <div className="bg-white/5 border border-white/5 p-3 rounded-xl">
                    <span className="text-[9px] font-mono text-gray-400 block uppercase mb-1">Estimated Deposit Requirement:</span>
                    <span className="text-sm font-bold text-white font-mono block">${suggestedDeposit50} (50% booking fee)</span>
                    <p className="text-[10px] text-gray-500 mt-0.5">Retainer required to start asset forging.</p>
                  </div>

                  <div className="bg-emerald-950/10 border border-emerald-900/30 p-3 rounded-xl">
                    <span className="text-[9px] font-mono text-emerald-400 block uppercase mb-1">Your Net Business Profit:</span>
                    <span className="text-sm font-bold text-emerald-300 font-mono block">${clientNetProfit} ({marginPercentage}% profit margin)</span>
                    <p className="text-[10px] text-gray-500 mt-0.5">Calculated buffer profit margin after overheads.</p>
                  </div>
                </div>

                <div className="p-3 bg-[#111114] border border-white/5 rounded-xl">
                  <span className="text-[10px] font-mono text-gray-500 uppercase block mb-1">Pricing Negotiation Script Tip:</span>
                  <p className="text-xs text-gray-300 leading-normal italic">
                    "Based on the ultra custom variables and the specialized visual grids required for {estHours} hours of delivery, the quote is ${targetProjectPrice}. This includes our complete raw sources delivery and full design blueprint ownership."
                  </p>
                </div>

              </div>
            )}

          </div>

          <div className="border-t border-white/5 pt-4 text-center text-[10px] text-gray-500">
            {isEn ? "Suggested prices are calculated using standard visual agency multipliers." : "উদ্যোক্তাকেন্দ্রিক মুনাফা ও লাভ্যাংশ পরিমাপক সূত্র দ্বারা প্রণীত।"}
          </div>

        </div>

      </div>
    </div>
  );
}
