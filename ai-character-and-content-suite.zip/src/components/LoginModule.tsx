/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import { TRANSLATIONS, LanguageCode } from "../lib/translations";
import { Shield, Sparkles, User, Coins, CheckCircle, Globe } from "lucide-react";
import { motion } from "motion/react";

interface LoginModuleProps {
  lang: LanguageCode;
  onLoginSuccess: (username: string) => void;
  toggleLang: () => void;
}

export default function LoginModule({ lang, onLoginSuccess, toggleLang }: LoginModuleProps) {
  const [inputName, setInputName] = useState("");
  const [errorText, setErrorText] = useState("");
  const t = TRANSLATIONS[lang];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputName.trim()) {
      setErrorText(t.invalidUser);
      return;
    }
    const cleanUser = inputName.trim();
    onLoginSuccess(cleanUser);
  };

  return (
    <div className="min-h-screen bg-[#0A0A0A] flex flex-col justify-between items-center px-4 py-8 select-none font-sans relative overflow-hidden">
      {/* Absolute Ambient Background Lights */}
      <div className="absolute top-10 left-1/4 w-96 h-96 bg-purple-900/5 blur-[120px] rounded-full pointer-events-none" />
      <div className="absolute bottom-10 right-1/4 w-96 h-96 bg-blue-900/10 blur-[120px] rounded-full pointer-events-none" />

      {/* Top Bar with Language Toggle & Metadata Indicators */}
      <div className="w-full max-w-xl flex justify-between items-center z-10">
        <div className="flex items-center gap-1.5 px-3 py-1 bg-white/5 border border-white/5 rounded-full text-xs text-gray-400 backdrop-blur-sm">
          <Shield className="w-3.5 h-3.5 text-blue-400" />
          <span>SECURE DESKTOP SANDBOX</span>
        </div>
        
        <button
          onClick={toggleLang}
          id="btn-login-lang-toggle"
          className="flex items-center gap-2 px-3.5 py-1.5 bg-white/5 hover:bg-white/10 border border-white/5 active:scale-95 transition-all rounded-full text-xs text-blue-400 font-medium cursor-pointer"
        >
          <Globe className="w-3.5 h-3.5" />
          <span>{lang === "en" ? "বাংলা" : "English"}</span>
        </button>
      </div>

      {/* Main Login Card */}
      <motion.div 
        initial={{ opacity: 0, y: 15 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, ease: "easeOut" }}
        className="w-full max-w-md bg-[#121212] border border-white/5 p-8 rounded-3xl shadow-2xl backdrop-blur-md z-10"
      >
        <div className="text-center mb-8">
          {/* Logo Badge */}
          <div className="inline-flex items-center justify-center p-3 bg-blue-600/10 border border-blue-500/20 rounded-2xl mb-4">
            <Sparkles className="w-8 h-8 text-blue-400" />
          </div>
          
          <h1 className="text-2xl md:text-3xl font-display font-medium text-white tracking-tight leading-tight">
            <span>AI</span>
            <span className="text-blue-500 italic font-medium">Studio.bn</span>
          </h1>
          <p className="text-xs text-gray-400 mt-2 font-normal">
            {t.appSubtitle}
          </p>
        </div>

        {/* Info points */}
        <div className="space-y-3 mb-8 bg-[#151515] p-4 border border-white/5 rounded-2xl">
          <div className="flex gap-3 text-left">
            <Coins className="w-5 h-5 text-blue-400 shrink-0 mt-0.5" />
            <div>
              <h4 className="text-xs font-semibold text-white">
                {lang === "en" ? "Interactive Credit Economy" : "ইন্টারেক্টিভ ক্রেডিট ইকোনমি"}
              </h4>
              <p className="text-[11px] text-gray-400">
                {lang === "en" ? "Start with 100 free tokens. Generation tasks consume credits." : "১০০ ফ্রি টোকেন দিয়ে শুরু করুন। কাজ সম্পন্ন করতে ক্রেডিট খরচ হবে।"}
              </p>
            </div>
          </div>
          <div className="flex gap-3 text-left">
            <CheckCircle className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
            <div>
              <h4 className="text-xs font-semibold text-white">
                {lang === "en" ? "No API Setup Required" : "এপিআই সেটআপ ছাড়াই ব্যবহার করুন"}
              </h4>
              <p className="text-[11px] text-gray-400">
                {lang === "en" ? "Uses deep-integration Gemini engine with immediate high-fidelity local fallback." : "জেমিনি ইঞ্জিনের ডিরেক্ট ও হাই-ফিডেলিটি ব্যাকআপ সাপোর্ট রয়েছে।"}
              </p>
            </div>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="text-left">
            <label className="block text-xs font-medium text-gray-400 mb-1.5 ml-1">
              {t.username}
            </label>
            <div className="relative">
              <User className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
              <input
                type="text"
                value={inputName}
                onChange={(e) => {
                  setInputName(e.target.value);
                  setErrorText("");
                }}
                id="login-username-input"
                maxLength={20}
                placeholder={t.usernamePlaceholder}
                className="w-full bg-[#0A0A0A] border border-white/5 focus:border-blue-500 rounded-2xl py-3 pl-10 pr-4 text-sm text-white placeholder-gray-500 outline-none focus:ring-1 focus:ring-blue-500/30 transition-all"
              />
            </div>
            {errorText && (
              <p className="text-xs text-rose-400 mt-1.5 ml-1">
                {errorText}
              </p>
            )}
          </div>

          <button
            type="submit"
            id="login-submit-btn"
            className="w-full bg-blue-600 hover:bg-blue-500 active:scale-[0.98] transition-all py-3.5 rounded-2xl text-xs font-semibold text-white shadow-xl shadow-blue-900/20 font-display tracking-wide cursor-pointer flex justify-center items-center gap-2 mt-2"
          >
            <span>{t.registerBtn}</span>
            <Sparkles className="w-3.5 h-3.5" />
          </button>
        </form>

        <p className="text-[10px] text-gray-400 text-center mt-6">
          {lang === "en" ? "Offline-first mock storage. No passwords required." : "অফলাইন-ফার্স্ট সিমুলেশন। কোনো পাসওয়ার্ডের দরকার নেই।"}
        </p>
      </motion.div>

      {/* Footer Design Credits */}
      <div className="text-center z-10 text-[11px] text-gray-500 font-mono tracking-wider">
        <span>© 2026 AI CODING AGENT • BANGLA INTEGRATED SUITE</span>
      </div>
    </div>
  );
}
