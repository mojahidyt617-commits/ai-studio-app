/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import { TRANSLATIONS, LanguageCode } from "../lib/translations";
import { BrandSpec } from "../types";
import { 
  Sparkles, RefreshCcw, Award, Shield, Smile, Globe, 
  Copy, CheckSquare, Layers, HelpCircle, Star, PenTool
} from "lucide-react";

interface BrandGeneratorModuleProps {
  lang: LanguageCode;
  credits: number;
  deductCredits: (qty: number, actionTitle: string) => boolean;
  onBrandGenerated: (brand: BrandSpec) => void;
  recentBrands: BrandSpec[];
}

export default function BrandGeneratorModule({
  lang,
  credits,
  deductCredits,
  onBrandGenerated,
  recentBrands
}: BrandGeneratorModuleProps) {
  const [brandNameInput, setBrandNameInput] = useState("");
  const [industry, setIndustry] = useState("Technology");
  const [personality, setPersonality] = useState("Bold Minimalist Modern");
  const [values, setValues] = useState("");

  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState("");
  const [activeTab, setActiveTab] = useState<"create" | "brands">("create");
  const [selectedBrand, setSelectedBrand] = useState<BrandSpec | null>(null);
  const [copiedLabel, setCopiedLabel] = useState<string | null>(null);

  // Pre-configured curated brands
  const mockBrands: BrandSpec[] = [
    {
      id: "cur_b1",
      brandName: "VoltStride",
      industry: "Electric Mobility Vehicles",
      personality: "Adventurous High-Tech",
      tagline: "Unleash kinetic freedom across city streets.",
      brandStory: "Founded by energy architects and custom race mechanics, VoltStride engineers ultra-compact electric cargo-cycles built to beat heavy inner-city choke points. Driven by modular spatial design, we deliver massive carrying quotas with zero environmental debt, powering independent visual delivery squads and micro-couriers worldwide.",
      logoCreativeConcept: "A lightning bolt styled inside a fast-sloping parallelogram, rendered in brilliant safety neon green and satin carbon black.",
      idealColorPalette: ["#10B981", "#111827", "#1E293B", "#34D399", "#FAF5FF"],
      marketingPitch: "Elevate your logistics. VoltStride provides cargo fleets optimized with hot-swappable batteries. Evolve your operations, claim urban avenues, and make emissions history.",
      brandToneGuidelines: [
        "Use active verbs, high-momentum nouns, and kinetic descriptions.",
        "Emphasize raw power, payload metrics, and absolute carbon avoidance rates.",
        "Address the courier as a high-performing professional rather than a consumer."
      ],
      createdAt: new Date().toISOString()
    }
  ];

  const handleGenerate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!brandNameInput.trim()) return;
    setErrorMsg("");

    const cost = 15;
    if (credits < cost) {
      setErrorMsg(lang === "en" ? "Insufficient credits! Recharge to design brand blueprints." : "পর্যাপ্ত ক্রেডিট নেই! নতুন ব্র্যান্ডিং থিম তৈরি করতে ক্রেডিট রিচার্জ করুন।");
      return;
    }

    setLoading(true);

    try {
      const response = await fetch("/api/brand/generate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          brandName: brandNameInput.trim(),
          industry: industry,
          personality: personality,
          values: values.trim()
        }),
      });

      if (!response.ok) {
        throw new Error("Failed to consult brand architect. Check your connection.");
      }

      const data: BrandSpec = await response.json();

      const deducted = deductCredits(cost, `Brand Concept: ${data.brandName}`);
      if (!deducted) {
        setErrorMsg(lang === "en" ? "Insufficient credits!" : "পর্যাপ্ত ক্রেডিট নেই!");
        setLoading(false);
        return;
      }

      onBrandGenerated(data);
      setSelectedBrand(data);
      setActiveTab("create");
      
      // Reset input fields
      setBrandNameInput("");
      setValues("");
    } catch (err: any) {
      setErrorMsg(err.message || "Failed to establish brand metrics. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  const handleCopyText = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    setCopiedLabel(label);
    setTimeout(() => setCopiedLabel(null), 1500);
  };

  const allBrands = [...recentBrands, ...mockBrands];
  const activeBrand = selectedBrand || allBrands[0];

  // Helper to generate a live dynamic SVG monogram styled on brand name and colors
  const renderDynamicSvgLogo = (brand: BrandSpec) => {
    const primaryColor = brand.idealColorPalette[0] || "#3b82f6";
    const secondaryColor = brand.idealColorPalette[2] || "#10b981";
    const char = brand.brandName ? brand.brandName.charAt(0).toUpperCase() : "A";
    const subText = brand.brandName || "Nexus";

    return (
      <svg viewBox="0 0 400 150" className="w-full h-auto bg-black/40 border border-white/5 rounded-2xl p-6 shadow-xl relative overflow-hidden">
        {/* Subtle grid backdrop inside SVG */}
        <defs>
          <pattern id="logoGrid" width="20" height="20" patternUnits="userSpaceOnUse">
            <path d="M 20 0 L 0 0 0 20" fill="none" stroke="rgba(255,255,255,0.03)" strokeWidth="1"/>
          </pattern>
        </defs>
        <rect width="100%" height="100%" fill="url(#logoGrid)" />

        {/* Isometric glowing geometric symbol */}
        <g transform="translate(60, 75)">
          <circle r="40" fill="none" stroke={`url(#logoGrad_${brand.id})`} strokeWidth="2" strokeDasharray="5, 3" />
          <circle r="30" fill="none" stroke={primaryColor} strokeWidth="4" />
          <polyline points="-12,-15 12,0 -12,15" fill="none" stroke={secondaryColor} strokeWidth="3" />
          
          <linearGradient id={`logoGrad_${brand.id}`} x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor={primaryColor} />
            <stop offset="100%" stopColor={secondaryColor} />
          </linearGradient>
        </g>

        {/* Corporate Typography */}
        <g transform="translate(135, 85)">
          {/* Logo Name */}
          <text 
            className="font-display font-medium tracking-wide uppercase" 
            fontSize="26" 
            fill="#FFFFFF"
            style={{ fontFamily: "'Inter', sans-serif" }}
          >
            {brand.brandName}
          </text>
          
          {/* Industry segment details */}
          <text 
            className="font-mono uppercase tracking-[0.3em]" 
            fontSize="8" 
            fill={primaryColor}
            y="22"
            style={{ fontFamily: "'JetBrains Mono', monospace" }}
          >
            {brand.industry}
          </text>
        </g>
      </svg>
    );
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="text-left border-b border-white/5 pb-4">
        <h2 className="text-xl font-display font-medium text-white flex items-center gap-2">
          <Award className="w-5 h-5 text-emerald-400 rotate-6" />
          {lang === "en" ? "Brand Strategy & Identity Generator" : "এআই ব্র্যান্ড স্ট্র্যাটেজি ও লোগো মেকার"}
        </h2>
        <p className="text-xs text-slate-400 mt-1">
          {lang === "en"
            ? "Configure a premium identity index, creative storylines, marketing taglines, and live stylized vector branding."
            : "নতুন শুরু করা কোম্পানির নাম, নিশ, ব্যক্তিত্ব এবং ব্র্যান্ড টোন সিলেক্ট করে এআই ব্র্যান্ডিং ও লোগো মেক করুন।"}
        </p>
      </div>

      {/* Tabs list */}
      <div className="flex bg-[#121212] border border-white/5 p-1 rounded-xl w-fit">
        <button
          onClick={() => setActiveTab("create")}
          className={`px-4 py-1.5 rounded-lg text-xs font-semibold cursor-pointer transition-all ${
            activeTab === "create"
              ? "bg-emerald-600 text-white shadow-md shadow-emerald-900/30"
              : "text-slate-400 hover:text-white"
          }`}
        >
          {lang === "en" ? "✏️ Brand Architect" : "✏️ নতুন ব্র্যান্ড তৈরি"}
        </button>
        <button
          onClick={() => setActiveTab("brands")}
          className={`px-4 py-1.5 rounded-lg text-xs font-semibold cursor-pointer transition-all ${
            activeTab === "brands"
              ? "bg-emerald-600 text-white shadow-md shadow-emerald-900/30"
              : "text-slate-400 hover:text-white"
          }`}
        >
          {lang === "en" ? "📁 Saved Identities" : "📁 ব্র্যান্ড আর্কাইভ"}
        </button>
      </div>

      {activeTab === "create" && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 text-left">
          {/* Interactive Input card */}
          <div className="lg:col-span-4 bg-[#121212] border border-white/5 p-6 rounded-2xl h-fit space-y-4">
            <h3 className="text-sm font-semibold tracking-wide text-white uppercase flex items-center gap-1.5">
              <PenTool className="w-4 h-4 text-emerald-400" />
              {lang === "en" ? "Branded Inputs" : "কোম্পানির তথ্য ও প্যারামিটার"}
            </h3>

            <form onSubmit={handleGenerate} className="space-y-4 font-sans">
              <div className="space-y-1">
                <label className="text-[10px] font-mono font-bold text-slate-400 uppercase">{lang === "en" ? "Brand/Startup Name" : "ব্র্যান্ড অথবা কোম্পানির নাম"}</label>
                <input
                  type="text"
                  required
                  placeholder="e.g., NovaPay, EcoFlow, AeroGrid..."
                  value={brandNameInput}
                  onChange={(e) => setBrandNameInput(e.target.value)}
                  className="w-full text-xs px-3.5 py-2.5 bg-[#1a1a1a] border border-white/5 rounded-xl text-white placeholder-slate-600 focus:outline-none focus:border-emerald-500/50"
                />
              </div>

              <div className="space-y-1">
                <label className="text-[10px] font-mono font-bold text-slate-400 uppercase">{lang === "en" ? "Industry Segment" : "ইন্ডাস্ট্রি বা ব্যবসার ধরণ"}</label>
                <select
                  value={industry}
                  onChange={(e) => setIndustry(e.target.value)}
                  className="w-full text-xs px-3.5 py-2.5 bg-[#1a1a1a] border border-white/5 rounded-xl text-white focus:outline-none focus:border-emerald-500/50 cursor-pointer"
                >
                  {["Technology & Cloud SaaS", "Eco-Friendly Cleantech", "Skin Wellness & Cosmetics", "Financial Tech & Blockchain", "E-Commerce & Smart Retail", "Food & Health Wellness"].map((ind) => (
                    <option key={ind} value={ind}>{ind}</option>
                  ))}
                </select>
              </div>

              <div className="space-y-1">
                <label className="text-[10px] font-mono font-bold text-slate-400 uppercase">{lang === "en" ? "Core Visual Personality" : "ব্র্যান্ডের প্রধান ভিজ্যুয়াল আচরণ"}</label>
                <select
                  value={personality}
                  onChange={(e) => setPersonality(e.target.value)}
                  className="w-full text-xs px-3.5 py-2.5 bg-[#1a1a1a] border border-white/5 rounded-xl text-white focus:outline-none focus:border-emerald-500/50 cursor-pointer"
                >
                  {["Bold Minimalist Modern", "Cozy Organic Friendly", "Elegant Luxury Heritage", "Cyber Futuristic Technical", "Playful Retro Pop"].map((p) => (
                    <option key={p} value={p}>{p}</option>
                  ))}
                </select>
              </div>

              <div className="space-y-1">
                <label className="text-[10px] font-mono font-bold text-slate-400 uppercase">{lang === "en" ? "Core Values (Optional)" : "ব্র্যান্ডের মূল চালিকাশক্তি (ঐচ্ছিক)"}</label>
                <input
                  type="text"
                  placeholder="e.g., Decentration, safety, speed..."
                  value={values}
                  onChange={(e) => setValues(e.target.value)}
                  className="w-full text-xs px-3.5 py-2.5 bg-[#1a1a1a] border border-white/5 rounded-xl text-white placeholder-slate-600 focus:outline-none focus:border-emerald-500/50"
                />
              </div>

              <button
                type="submit"
                disabled={loading}
                className="w-full py-2.5 bg-emerald-600 hover:bg-emerald-500 disabled:bg-emerald-950/40 text-white rounded-xl text-xs font-bold font-mono tracking-wider cursor-pointer active:scale-95 transition-all flex items-center justify-center gap-1.5"
              >
                {loading ? (
                  <>
                    <RefreshCcw className="w-3.5 h-3.5 animate-spin" />
                    <span>{lang === "en" ? "Engineering Identity..." : "ব্র্যান্ডিং মেক হচ্ছে..."}</span>
                  </>
                ) : (
                  <>
                    <Sparkles className="w-3.5 h-3.5" />
                    <span>{lang === "en" ? "Generate Brand (15 Credits)" : "ব্র্যান্ড আইডেন্টিটি (১৫ ক্রেডিট)"}</span>
                  </>
                )}
              </button>
            </form>

            {errorMsg && (
              <p className="text-xs bg-red-950/20 border border-red-900/40 text-red-400 p-3 rounded-xl">
                {errorMsg}
              </p>
            )}

            {/* Quick Suggestions list */}
            <div className="pt-2 border-t border-white/5 space-y-2">
              <span className="text-[10px] font-mono text-slate-500 uppercase block">{lang === "en" ? "Quick Industry Presets" : "আইডিয়া প্রেসেন্টস"}</span>
              <div className="flex flex-wrap gap-1">
                {["GreenGrocer", "AeroTrack Log", "PrimeCrypt", "MedVitals", "AuraGlam"].map((cur) => (
                  <button
                    key={cur}
                    onClick={() => setBrandNameInput(cur)}
                    className="px-2 py-1 bg-white/5 hover:bg-white/10 text-[10px] rounded-md text-slate-300 transition-all cursor-pointer"
                  >
                    + {cur}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Core branding deliverables grid */}
          <div className="lg:col-span-8 space-y-6">
            {activeBrand ? (
              <div className="space-y-6">
                {/* Visual Identity Logo Emblem container */}
                <div className="space-y-3">
                  <span className="text-[10px] tracking-widest font-mono text-slate-400 uppercase font-bold">
                    {lang === "en" ? "INTERACTIVE CORPORATE LOGO EMBLEM" : "ইন্টারেক্টিভ লোগো সিগনেচার"}
                  </span>
                  {renderDynamicSvgLogo(activeBrand)}
                </div>

                {/* Tagline & Elevator pitch display */}
                <div className="p-6 bg-[#121212] border border-white/5 rounded-2xl space-y-4">
                  <div>
                    <span className="text-[9px] font-mono text-emerald-400 uppercase tracking-widest font-bold block mb-1">Catchy Catchphrase</span>
                    <h3 className="text-xl font-display font-medium text-white italic tracking-tight">
                      &ldquo;{activeBrand.tagline}&rdquo;
                    </h3>
                  </div>

                  <div className="pt-3 border-t border-white/5">
                    <span className="text-[9px] font-mono text-indigo-400 uppercase tracking-widest font-bold block mb-1">Corporate Elevator Pitch</span>
                    <p className="text-xs text-slate-300 leading-relaxed">
                      {activeBrand.marketingPitch}
                    </p>
                  </div>

                  <div className="flex items-center gap-2 mt-4">
                    <button
                      onClick={() => handleCopyText(activeBrand.tagline, "tagline")}
                      className="px-3 py-1.5 bg-white/5 hover:bg-white/10 text-[10px] font-mono rounded-lg text-slate-200 transition-all flex items-center gap-1 cursor-pointer active:scale-95"
                    >
                      <Copy className="w-3 h-3 text-slate-400" />
                      <span>{copiedLabel === "tagline" ? "Slogan Copied!" : "Copy Tagline"}</span>
                    </button>
                    <button
                      onClick={() => handleCopyText(activeBrand.marketingPitch, "pitch")}
                      className="px-3 py-1.5 bg-white/5 hover:bg-white/10 text-[10px] font-mono rounded-lg text-slate-200 transition-all flex items-center gap-1 cursor-pointer active:scale-95"
                    >
                      <Copy className="w-3 h-3 text-slate-400" />
                      <span>{copiedLabel === "pitch" ? "Pitch Copied!" : "Copy Pitch"}</span>
                    </button>
                  </div>
                </div>

                {/* Brand story section */}
                <div className="grid grid-cols-1 md:grid-cols-12 gap-5 items-stretch">
                  <div className="md:col-span-7 bg-[#121212] border border-white/5 p-6 rounded-2xl space-y-3">
                    <span className="text-[9px] font-mono text-emerald-400 uppercase tracking-widest font-bold block">Brand Foundation Story</span>
                    <p className="text-xs text-slate-400 leading-relaxed font-sans text-justify">
                      {activeBrand.brandStory}
                    </p>
                  </div>

                  {/* Curated ideal branding color palette */}
                  <div className="md:col-span-5 bg-[#121212] border border-white/5 p-6 rounded-2xl flex flex-col justify-between">
                    <div>
                      <span className="text-[9px] font-mono text-emerald-400 uppercase tracking-widest font-bold block mb-3">Ideal Color Palette</span>
                      <div className="grid grid-cols-5 gap-2">
                        {activeBrand.idealColorPalette.map((col, idx) => (
                          <div 
                            key={col + idx}
                            onClick={() => handleCopyText(col, `col_${idx}`)}
                            className="space-y-1 text-center cursor-pointer group"
                            title={`Click to copy: ${col}`}
                          >
                            <div 
                              className="aspect-square w-full rounded-lg border border-white/10 group-hover:scale-105 duration-200"
                              style={{ backgroundColor: col }}
                            />
                            <span className="text-[9px] font-mono text-slate-500">{col}</span>
                          </div>
                        ))}
                      </div>
                      {copiedLabel?.startsWith("col_") && (
                        <p className="text-[9px] font-mono text-green-400 animate-pulse mt-1">Hex copied to clipboard!</p>
                      )}
                    </div>

                    <div className="border-t border-white/5 pt-3 mt-4 text-[10px] text-slate-500 font-mono flex justify-between items-center">
                      <span>Vibe: {activeBrand.personality}</span>
                      <span className="flex items-center gap-1">
                        <Star className="w-3 h-3 text-amber-400 fill-amber-400" /> Highly Curated
                      </span>
                    </div>
                  </div>
                </div>

                {/* Tone of Voice elements */}
                <div className="bg-[#121212] border border-white/5 p-6 rounded-2xl space-y-4">
                  <h3 className="text-sm font-semibold text-white uppercase tracking-wide flex items-center gap-1.5">
                    <Shield className="w-4 h-4 text-emerald-400" />
                    {lang === "en" ? "Brand Editorial Guidelines & Tone of Voice" : "ব্র্যান্ড সম্পাদকীয় নির্দেশিকা ও টোন গাইড"}
                  </h3>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    {activeBrand.brandToneGuidelines.map((g, i) => (
                      <div key={i} className="p-4 bg-white/5 border border-white/5 rounded-xl text-xs text-slate-300 flex gap-2">
                        <CheckSquare className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                        <p>{g}</p>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            ) : (
              <div className="p-12 border border-dashed border-white/10 rounded-2xl text-center text-slate-500 font-mono">
                <p>{lang === "en" ? "Drafting startup identities..." : "ব্র্যান্ডিং আইডেন্টিটির খসড়া তৈরি করা হচ্ছে..."}</p>
              </div>
            )}
          </div>
        </div>
      )}

      {activeTab === "brands" && (
        <div className="space-y-4 text-left">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {allBrands.map((brand) => (
              <div 
                key={brand.id}
                onClick={() => {
                  setSelectedBrand(brand);
                  setActiveTab("create");
                }}
                className="bg-[#121212] border border-white/5 p-5 rounded-2xl hover:border-emerald-500/30 transition-all cursor-pointer active:scale-98 relative group"
              >
                <div className="flex justify-between items-start gap-2">
                  <div className="p-1.5 bg-emerald-500/10 border border-emerald-500/20 rounded-lg text-emerald-400">
                    <Star className="w-4 h-4" />
                  </div>
                  <span className="text-[9px] font-mono text-slate-500 uppercase tracking-widest">BRAND PACK</span>
                </div>

                <h4 className="text-base font-display font-medium text-white mt-3">{brand.brandName}</h4>
                <p className="text-xs text-slate-500 uppercase font-mono tracking-wider mt-0.5">{brand.industry}</p>
                
                <p className="text-xs text-slate-400 line-clamp-2 mt-2 leading-relaxed">&ldquo;{brand.tagline}&rdquo;</p>
                
                {/* Embedded Mini Color Strip */}
                <div className="flex items-center gap-1 mt-4 pt-3 border-t border-white/5 justify-between">
                  <div className="flex gap-1">
                    {brand.idealColorPalette.slice(0, 4).map((c, i) => (
                      <span key={i} className="w-3 h-3 rounded-full border border-white/10 inline-block" style={{ backgroundColor: c }} />
                    ))}
                  </div>
                  <span className="text-[10px] font-mono text-slate-500 group-hover:text-emerald-400 transition-all">Inspect Brand</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
