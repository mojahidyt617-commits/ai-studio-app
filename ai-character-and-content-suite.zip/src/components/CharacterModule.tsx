/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import { TRANSLATIONS, LanguageCode } from "../lib/translations";
import { AICharacter } from "../types";
import { 
  Sparkles, ShieldAlert, Swords, Zap, Fingerprint, RefreshCcw, Image, 
  User, CheckCircle, Flame, Target, BookOpen, AlertTriangle
} from "lucide-react";

interface CharacterModuleProps {
  lang: LanguageCode;
  credits: number;
  deductCredits: (qty: number, actionTitle: string) => boolean;
  onCharacterGenerated: (char: AICharacter) => void;
  recentCharacters: AICharacter[];
}

export default function CharacterModule({
  lang,
  credits,
  deductCredits,
  onCharacterGenerated,
  recentCharacters
}: CharacterModuleProps) {
  const t = TRANSLATIONS[lang];
  
  // Form states
  const [charName, setCharName] = useState("");
  const [charClass, setCharClass] = useState("");
  const [charGender, setCharGender] = useState("Male");
  const [charDesc, setCharDesc] = useState("");
  
  // UI Loading States
  const [loading, setLoading] = useState(false);
  const [imageGenerating, setImageGenerating] = useState(false);
  const [errorMsg, setErrorMsg] = useState("");
  const [activeTab, setActiveTab] = useState<"create" | "view">("create");
  
  // Active Character selection state
  const [selectedChar, setSelectedChar] = useState<AICharacter | null>(null);

  const handleGenerate = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg("");

    // Step 1: Credit check
    const cost = 15;
    if (credits < cost) {
      setErrorMsg(t.insufficientCredits);
      return;
    }

    setLoading(true);

    try {
      // Step 2: Call full-stack server
      const response = await fetch("/api/character/generate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: charName.trim(),
          classType: charClass.trim(),
          gender: charGender,
          promptDescription: charDesc.trim(),
        }),
      });

      if (!response.ok) {
        throw new Error("Server responded with failure");
      }

      const rawChar: AICharacter & { aiGenerated?: boolean } = await response.json();
      
      // Step 3: Deduct credits on successful generator completion
      const deducted = deductCredits(cost, `AI Character: ${rawChar.name}`);
      if (!deducted) {
        setErrorMsg(t.insufficientCredits);
        setLoading(false);
        return;
      }

      // Format custom fallback SVG illustrations based on themeColor if no portrait exists yet
      const finalChar: AICharacter = {
        ...rawChar,
        avatarSvgFallback: drawProceduralAvatar(rawChar.name, rawChar.themeColor, rawChar.classType)
      };

      onCharacterGenerated(finalChar);
      setSelectedChar(finalChar);
      setActiveTab("view");
      
      // Clear inputs
      setCharName("");
      setCharClass("");
      setCharDesc("");
    } catch (err: any) {
      console.error(err);
      setErrorMsg("Failed to communicate with AI model. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  // Trigger base64 image generation via Gemini 2.5 Image
  const handleGeneratePortrait = async () => {
    if (!selectedChar) return;
    setErrorMsg("");

    const cost = 20;
    if (credits < cost) {
      setErrorMsg(t.insufficientCredits);
      return;
    }

    setImageGenerating(true);

    try {
      const resp = await fetch("/api/generate-image", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ prompt: selectedChar.visualPrompt }),
      });

      const data = await resp.json();

      if (!resp.ok || !data.success) {
        throw new Error(data.message || data.error || "Failed to generate image");
      }

      // Deduct credits for premium image generation
      const deducted = deductCredits(cost, `Imagen Portrait: ${selectedChar.name}`);
      if (!deducted) return;

      const updatedChar = {
        ...selectedChar,
        avatarBase64: data.image
      };

      setSelectedChar(updatedChar);
      onCharacterGenerated(updatedChar); // Update in historical parent storage too
    } catch (err: any) {
      console.error(err);
      setErrorMsg(err.message || "Portrait Generation restricted. Image API requires active Paid API Key.");
    } finally {
      setImageGenerating(false);
    }
  };

  // Helper code to generate beautiful inline customizable procedural vector SVGs
  const drawProceduralAvatar = (seedName: string, color: string, category: string) => {
    const primary = color || "#6366f1";
    // Construct inline SVG markup
    return `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100" class="w-full h-full">
        <defs>
          <linearGradient id="grad-${seedName}" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stop-color="#0f172a" />
            <stop offset="50%" stop-color="#1e293b" />
            <stop offset="100%" stop-color="${primary}" stop-opacity="0.3" />
          </linearGradient>
          <radialGradient id="glow" cx="50%" cy="50%" r="50%">
            <stop offset="0%" stop-color="${primary}" stop-opacity="0.5"/>
            <stop offset="100%" stop-color="${primary}" stop-opacity="0"/>
          </radialGradient>
        </defs>
        <rect width="100" height="100" fill="url(#grad-${seedName})" rx="16"/>
        <circle cx="50" cy="50" r="35" fill="url(#glow)"/>
        <!-- Abstract Tech Rings -->
        <circle cx="50" cy="50" r="28" fill="none" stroke="${primary}" stroke-width="0.75" stroke-dasharray="2, 6" />
        <circle cx="50" cy="50" r="22" fill="none" stroke="${primary}" stroke-width="0.5" stroke-opacity="0.6"/>
        <!-- Core Visual Elements -->
        <polygon points="50,25 65,42 62,58 38,58 35,42" fill="none" stroke="${primary}" stroke-width="1.8" />
        <line x1="50" y1="20" x2="50" y2="80" stroke="${primary}" stroke-width="0.5" stroke-dasharray="1,2" />
        <circle cx="50" cy="42" r="5" fill="#1e293b" stroke="${primary}" stroke-width="1.5" />
        <!-- Digital elements -->
        <path d="M 25 75 L 42 63 L 58 63 L 75 75" fill="none" stroke="${primary}" stroke-width="1.5" stroke-linecap="round"/>
        <circle cx="50" cy="15" r="1.5" fill="${primary}"/>
        <circle cx="15" cy="50" r="1.5" fill="${primary}"/>
        <circle cx="85" cy="50" r="1.5" fill="${primary}"/>
      </svg>
    `;
  };

  return (
    <div className="space-y-6">
      {/* Sub Header tabs */}
      <div className="flex border-b border-white/5">
        <button
          onClick={() => setActiveTab("create")}
          id="tab-char-create"
          className={`px-5 py-3 text-xs font-semibold uppercase tracking-wider cursor-pointer transition-all ${
            activeTab === "create"
              ? "text-blue-400 border-b-2 border-blue-500"
              : "text-gray-400 hover:text-white"
          }`}
        >
          {lang === "en" ? "🛠️ Forge Character" : "🛠️ নতুন ক্যারেক্টার তৈরি"}
        </button>
        <button
          onClick={() => {
            if (recentCharacters.length > 0 && !selectedChar) {
              setSelectedChar(recentCharacters[0]);
            }
            setActiveTab("view");
          }}
          id="tab-char-inspect"
          className={`px-5 py-3 text-xs font-semibold uppercase tracking-wider cursor-pointer transition-all ${
            activeTab === "view"
              ? "text-blue-400 border-b-2 border-blue-500"
              : "text-gray-400 hover:text-white"
          }`}
        >
          {lang === "en" ? `👤 Inspect Lore (${recentCharacters.length})` : `👤 ক্যারেক্টার গ্যালারি (${recentCharacters.length})`}
        </button>
      </div>

      {loading && (
        <div className="bg-blue-900/5 border border-blue-500/20 p-12 rounded-2xl flex flex-col items-center justify-center space-y-4 animate-pulse">
          <div className="w-12 h-12 border-4 border-blue-500 border-t-transparent rounded-full animate-spin"></div>
          <div className="text-center">
            <h4 className="text-sm font-semibold text-blue-300">{t.charGenerating}</h4>
            <p className="text-xs text-gray-500 mt-1">AI runs calculations, plotting stats, origin, and design details...</p>
          </div>
        </div>
      )}

      {!loading && activeTab === "create" && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Settings Left Pane */}
          <div className="lg:col-span-7 bg-[#121212] border border-white/5 p-6 rounded-2xl space-y-5">
            <div>
              <h3 className="text-base font-display font-medium text-white flex items-center gap-2">
                <Flame className="w-4 h-4 text-blue-400" />
                {t.charTitle}
              </h3>
              <p className="text-xs text-gray-400 mt-1">
                {t.charSubtitle}
              </p>
            </div>

            {errorMsg && (
              <div id="char-error-alert" className="p-3.5 bg-rose-950/40 border border-rose-900/50 text-rose-300 rounded-xl flex items-start gap-2 text-xs">
                <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5 " />
                <span>{errorMsg}</span>
              </div>
            )}

            <form onSubmit={handleGenerate} className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-medium text-gray-450 mb-1.5">{t.charName}</label>
                  <input
                    type="text"
                    required
                    value={charName}
                    id="char-input-name"
                    onChange={(e) => setCharName(e.target.value)}
                    placeholder={t.charNamePlaceholder}
                    className="w-full bg-[#0A0A0A] border border-white/5 focus:border-blue-500 rounded-xl py-2.5 px-3 text-xs text-white placeholder-gray-550 outline-none"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-gray-455 mb-1.5">{t.charClass}</label>
                  <input
                    type="text"
                    required
                    value={charClass}
                    id="char-input-class"
                    onChange={(e) => setCharClass(e.target.value)}
                    placeholder={t.charClassPlaceholder}
                    className="w-full bg-[#0A0A0A] border border-white/5 focus:border-blue-500 rounded-xl py-2.5 px-3 text-xs text-white placeholder-gray-550 outline-none"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-medium text-gray-450 mb-1.5">{t.charGender}</label>
                  <select
                    value={charGender}
                    id="char-input-gender"
                    onChange={(e) => setCharGender(e.target.value)}
                    className="w-full bg-[#0A0A0A] border border-white/5 focus:border-blue-500 rounded-xl py-2.5 px-3 text-xs text-white outline-none animate-none"
                  >
                    <option value="Male">{lang === "en" ? "Male" : "পুরুষ"}</option>
                    <option value="Female">{lang === "en" ? "Female" : "মহিলা"}</option>
                    <option value="Non-Binary">{lang === "en" ? "Non-Binary" : "নন-বাইনারি"}</option>
                    <option value="Android">{lang === "en" ? "AI Construct" : "এআই কনস্ট্রাক্ট"}</option>
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-medium text-gray-450 mb-1.5">
                    {lang === "en" ? "Starting Attributes Focus" : "শুরুর ফোকাস এট্রিবিউট"}
                  </label>
                  <div className="px-3 py-2.5 bg-[#0A0A0A] border border-white/5 rounded-xl text-xs text-gray-450 flex items-center justify-between">
                    <span>⚡ Balanced Matrix Allocation</span>
                    <span className="text-[10px] bg-white/5 text-blue-400 px-1.5 py-0.5 rounded-md font-mono">10-100 MAX</span>
                  </div>
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-gray-450 mb-1.5">{t.charDesc}</label>
                <textarea
                  value={charDesc}
                  rows={3}
                  id="char-input-desc"
                  onChange={(e) => setCharDesc(e.target.value)}
                  placeholder={t.charDescPlaceholder}
                  className="w-full bg-[#0A0A0A] border border-white/5 focus:border-blue-500 rounded-xl py-2.5 px-3 text-xs text-white placeholder-gray-550 outline-none resize-none"
                />
              </div>

              <button
                type="submit"
                id="char-btn-generate"
                className="w-full bg-blue-600 hover:bg-blue-500 active:scale-95 transition-all py-3 rounded-xl text-xs font-semibold text-white font-display flex items-center justify-center gap-2 cursor-pointer shadow-lg shadow-blue-900/10"
              >
                <Sparkles className="w-3.5 h-3.5" />
                <span>{t.generateCharBtn}</span>
              </button>
            </form>
          </div>

          {/* Quick Guide Right Pane */}
          <div className="lg:col-span-5 bg-[#151515] border border-white/5 p-6 rounded-2xl flex flex-col justify-between">
            <div className="space-y-4 text-left">
              <h4 className="text-xs font-bold uppercase text-gray-400 tracking-wider">
                {lang === "en" ? "Design Ecosystem" : "ডিজাইন নির্দেশাবলী"}
              </h4>
              
              <ul className="space-y-3 text-xs text-gray-300">
                <li className="flex items-start gap-2">
                  <span className="text-blue-400 font-bold shrink-0">1.</span>
                  <span><strong>{lang === "en" ? "Personality synthesis" : "ব্যক্তিত্ব সিন্থেসিস"}:</strong> Backstories tailored perfectly to your dynamic choices.</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-blue-400 font-bold shrink-0">2.</span>
                  <span><strong>{lang === "en" ? "RPG mechanics" : "আরপিজি মেকানিক্স"}:</strong> Balanced distribution of 10-100 core attributes.</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-blue-400 font-bold shrink-0">3.</span>
                  <span><strong>{lang === "en" ? "Combat action pack" : "অ্যাকশন প্যাক"}:</strong> Generation of 3 special moves with customized cost ratings.</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-blue-400 font-bold shrink-0">4.</span>
                  <span><strong>{lang === "en" ? "Portrait Synthesizer" : "পোর্ট্রেট সিন্থেসাইজার"}:</strong> High quality prompt written for immediate design renderings.</span>
                </li>
              </ul>
            </div>

            <div className="pt-6 border-t border-white/5 flex items-center gap-3 mt-6">
              <div className="p-2 bg-blue-600/10 rounded-lg text-blue-400 font-mono text-xs border border-blue-500/20">
                🪙 15¢
              </div>
              <div className="text-left">
                <p className="text-xs font-semibold text-gray-300">
                  {lang === "en" ? "Deducted upon forge" : "ফোর্জ সম্পূর্ণ হলে ক্রেডিট কাটা হবে"}
                </p>
                <p className="text-[10px] text-gray-500">
                  {lang === "en" ? "Refunded if core model times out." : "মডেল টাইম-আউট হলে ক্রেডিট ফেরত দেওয়া হবে।"}
                </p>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* View Gallery Tab */}
      {!loading && activeTab === "view" && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* History Sidebar */}
          <div className="lg:col-span-4 bg-[#121212] border border-white/5 p-4 rounded-2xl space-y-3 max-h-[550px] overflow-y-auto">
            <h4 className="text-xs font-bold text-gray-400 uppercase tracking-widest px-2 mb-2">
              {lang === "en" ? "Chamber of Heroes" : "মহাবীরদের তালিকা"}
            </h4>
            {recentCharacters.length === 0 ? (
              <p className="text-xs text-gray-500 text-center py-6">{t.noHistory}</p>
            ) : (
              recentCharacters.map((c) => (
                <button
                  key={c.id}
                  onClick={() => setSelectedChar(c)}
                  className={`w-full text-left p-3 rounded-xl border transition-all flex items-center justify-between cursor-pointer ${
                    selectedChar?.id === c.id
                      ? "bg-[#151515] border-blue-500"
                      : "bg-[#0A0A0A] border-white/5 hover:bg-white/5"
                  }`}
                >
                  <div className="flex items-center gap-2.5 min-w-0">
                    {/* Visual box */}
                    <div className="w-8 h-8 rounded-lg overflow-hidden shrink-0 bg-[#0A0A0A] border border-white/5 flex items-center justify-center">
                      {c.avatarBase64 ? (
                        <img src={c.avatarBase64} alt={c.name} className="w-full h-full object-cover" />
                      ) : (
                        <div dangerouslySetInnerHTML={{ __html: c.avatarSvgFallback || "" }} className="w-6 h-6" />
                      )}
                    </div>
                    <div className="truncate text-left">
                      <h4 className="text-xs font-bold text-white truncate">{c.name}</h4>
                      <p className="text-[10px] text-gray-500 truncate">{c.classType}</p>
                    </div>
                  </div>
                  <User className="w-3.5 h-3.5 text-gray-600 shrink-0" />
                </button>
              ))
            )}
          </div>

          {/* Core Inspector Panel */}
          <div className="lg:col-span-8">
            {selectedChar ? (
              <div 
                className="bg-[#121212] border border-white/5 rounded-2xl overflow-hidden shadow-xl"
                style={{ borderTop: `4px solid ${selectedChar.themeColor || '#3b82f6'}` }}
              >
                {/* Header Profile Info */}
                <div className="p-6 border-b border-white/5 flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
                  <div className="flex items-center gap-4 text-left">
                    {/* Character Avatar Panel */}
                    <div className="w-16 h-16 rounded-xl overflow-hidden bg-[#0A0A0A] border-2 border-white/5 shrink-0 relative flex items-center justify-center">
                      {selectedChar.avatarBase64 ? (
                        <img src={selectedChar.avatarBase64} alt={selectedChar.name} className="w-full h-full object-cover" />
                      ) : (
                        <div dangerouslySetInnerHTML={{ __html: selectedChar.avatarSvgFallback || "" }} className="w-10 h-10" />
                      )}
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <h2 className="text-lg font-display font-medium text-white">{selectedChar.name}</h2>
                        <span 
                          className="text-[9px] font-mono px-2 py-0.5 rounded-full border"
                          style={{ borderColor: `${selectedChar.themeColor}50`, color: selectedChar.themeColor, backgroundColor: `${selectedChar.themeColor}15` }}
                        >
                          {selectedChar.gender}
                        </span>
                      </div>
                      <p className="text-xs font-mono text-blue-400 mt-0.5">{selectedChar.classType}</p>
                    </div>
                  </div>

                  {/* Actions Bar */}
                  <div className="flex items-center gap-2 w-full md:w-auto">
                    <button
                      onClick={handleGeneratePortrait}
                      id="char-btn-imagen"
                      disabled={imageGenerating}
                      className="flex-1 md:flex-initial bg-white/5 hover:bg-[#151515] border border-white/10 text-white rounded-xl py-2 px-3 text-[10px] font-semibold tracking-wide uppercase transition-all flex items-center justify-center gap-1.5 cursor-pointer disabled:opacity-50"
                    >
                      {imageGenerating ? (
                        <>
                          <RefreshCcw className="w-3.5 h-3.5 animate-spin" />
                          <span>Painting...</span>
                        </>
                      ) : (
                        <>
                          <Image className="w-3.5 h-3.5 text-blue-400" />
                          <span>Generate Imagen Portrait (🪙 20)</span>
                        </>
                      )}
                    </button>
                  </div>
                </div>

                {/* Subtitle slogan */}
                <div className="bg-white/5 px-6 py-3 border-b border-white/5 text-left">
                  <p className="text-xs italic text-blue-400 font-normal leading-relaxed">
                    &ldquo;{selectedChar.tagline}&rdquo;
                  </p>
                </div>

                {/* Main Lore Grid */}
                <div className="p-6 grid grid-cols-1 md:grid-cols-2 gap-6">
                  {/* Backstory & details */}
                  <div className="space-y-4 text-left">
                    <div className="flex items-center gap-2 border-b border-white/5 pb-1.5">
                      <BookOpen className="w-4 h-4 text-blue-405" />
                      <h4 className="text-xs uppercase font-bold text-gray-400 tracking-wider">
                        {lang === "en" ? "Archival Backstory" : "মহাকাব্যিক ব্যাকস্টোরি"}
                      </h4>
                    </div>
                    <p className="text-xs text-gray-300 leading-relaxed text-justify">
                      {selectedChar.backstory}
                    </p>

                    {/* Meta information */}
                    <div className="pt-3 space-y-2 text-[11px] text-gray-450 font-mono">
                      <div>
                        <span className="text-gray-500">AFFINITY STAMP: </span>
                        <span className="text-blue-450">SEC_LEVEL_6</span>
                      </div>
                      <div className="truncate">
                        <span className="text-gray-500">VISUAL PROMPT: </span>
                        <span className="text-gray-400 hover:text-white cursor-help" title={selectedChar.visualPrompt}>
                          {selectedChar.visualPrompt}
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Attributes and stats panel */}
                  <div className="space-y-4">
                    <div className="flex items-center gap-2 border-b border-white/5 pb-1.5 justify-between">
                      <div className="flex items-center gap-2">
                        <Target className="w-4 h-4 text-blue-450" />
                        <h4 className="text-xs uppercase font-bold text-gray-400 tracking-wider">
                          {t.charAttributes}
                        </h4>
                      </div>
                      <span className="text-[10px] font-mono text-gray-500">MAX 100</span>
                    </div>

                    <div className="space-y-3 pt-1">
                      {Object.entries(selectedChar.stats).map(([key, val]) => (
                        <div key={key} className="space-y-1">
                          <div className="flex justify-between text-xs font-mono">
                            <span className="capitalize text-gray-400">{key}</span>
                            <span className="font-bold text-white">{val} / 100</span>
                          </div>
                          {/* Progress bar container */}
                          <div className="w-full bg-[#0A0A0A] rounded-full h-1.5 border border-white/5 overflow-hidden">
                            <div 
                              className="h-full rounded-full transition-all duration-1000"
                              style={{ 
                                width: `${val}%`, 
                                backgroundColor: selectedChar.themeColor || '#3b82f6',
                                opacity: 0.85
                              }}
                            />
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Abilities panel */}
                <div className="p-6 bg-white/5 border-t border-white/5 space-y-4">
                  <div className="flex items-center gap-2 border-b border-white/5 pb-1.5">
                    <Swords className="w-4 h-4 text-blue-450" />
                    <h4 className="text-xs uppercase font-bold text-gray-400 tracking-wider">
                      {t.charAbilities}
                    </h4>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    {selectedChar.abilities.map((ab, i) => (
                      <div 
                        key={i} 
                        className="bg-[#151515] border border-white/5 p-4 rounded-xl text-left space-y-2 relative overflow-hidden flex flex-col justify-between"
                      >
                        {/* Power cost circle tag */}
                        <div className="absolute top-3.5 right-3.5 flex items-center gap-1 px-1.5 py-0.5 bg-[#0A0A0A] border border-white/5 rounded text-[9px] font-mono font-semibold text-amber-400">
                          <Zap className="w-2.5 h-2.5 shrink-0" />
                          <span>{ab.powerCost}</span>
                        </div>

                        <div className="space-y-1">
                          <h5 className="text-xs font-bold text-white tracking-tight pr-6">{ab.name}</h5>
                          <span className="text-[9px] font-mono tracking-wide text-blue-400 uppercase">
                            {ab.abilityType}
                          </span>
                        </div>

                        <p className="text-[11px] text-gray-400 leading-relaxed mt-1">
                          {ab.description}
                        </p>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            ) : (
              <div className="bg-[#121212] border border-white/5 p-16 rounded-2xl text-center space-y-3">
                <User className="w-10 h-10 text-gray-600 mx-auto" />
                <h4 className="text-xs uppercase font-bold text-gray-400 tracking-wide">
                  {lang === "en" ? "No characters loaded" : "কোনোও ক্যারেক্টার সিলেক্ট করা নেই"}
                </h4>
                <p className="text-xs text-gray-500 max-w-sm mx-auto">
                  {lang === "en" ? "Go forge a brand new character or select an active hero template from the sidebar gallery list." : "নতুন ক্যারেক্টার তৈরি করুন অথবা গিল্ড লিস্ট থেকে ক্যারেক্টার সিলেক্ট করুন।"}
                </p>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
