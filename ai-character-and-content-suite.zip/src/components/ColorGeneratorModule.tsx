/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import { TRANSLATIONS, LanguageCode } from "../lib/translations";
import { ColorPaletteSpec } from "../types";
import { 
  Sparkles, RefreshCcw, Palette, Paintbrush, ShieldCheck, 
  Copy, Eye, Shuffle, Monitor, Mail, CreditCard, Layout
} from "lucide-react";

interface ColorGeneratorModuleProps {
  lang: LanguageCode;
  credits: number;
  deductCredits: (qty: number, actionTitle: string) => boolean;
  onColorGenerated: (col: ColorPaletteSpec) => void;
  recentPalettes: ColorPaletteSpec[];
}

export default function ColorGeneratorModule({
  lang,
  credits,
  deductCredits,
  onColorGenerated,
  recentPalettes
}: ColorGeneratorModuleProps) {
  const [moodInput, setMoodInput] = useState("");
  const [harmonyRule, setHarmonyRule] = useState("Complementary High-Contrast");
  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState("");
  const [activeTab, setActiveTab] = useState<"create" | "library">("create");
  const [selectedPalette, setSelectedPalette] = useState<ColorPaletteSpec | null>(null);
  const [copiedHex, setCopiedHex] = useState<string | null>(null);
  
  // Interactive Live Sandbox view toggle
  const [sandboxLayout, setSandboxLayout] = useState<"saas" | "card" | "fintech">("saas");

  // Curated default palette for immediate visualization
  const mockPalettes: ColorPaletteSpec[] = [
    {
      id: "cur_col_1",
      paletteName: "Midnight Forest",
      moodDescription: "A soothing, deep dark theme combining low-strain dark cyan spruce roots with bright mint accents, perfect for ecological monitoring or developer workspaces.",
      colors: [
        { hex: "#060a0d", name: "Spruce Abyss", usage: "Page backdrop, absolute lowest luminance surface." },
        { hex: "#0e1a1e", name: "Deep Spruce", usage: "Main card container surfaces, navigational borders." },
        { hex: "#10b981", name: "Mint Sparkle", usage: "High-contrast visual callouts, toggles, and positive metrics." },
        { hex: "#06b6d4", name: "Cyan Stream", usage: "Hover indicators, link underlines, and secondary graphs." },
        { hex: "#f1f5f9", name: "Aero Frost", usage: "Headers, body descriptions, and primary readable text." }
      ],
      contrastAudit: "Mint Sparkle text on Spruce Abyss holds a WCAG AA contrast ratio of 4.8:1; exceptionally safe for clean developer UI.",
      landingPageDemo: {
        heroText: "Optimizing the Earth's Smart Node Ecosystem",
        ctaText: "Synchronize Solar Cells",
        themeType: "dark"
      },
      createdAt: new Date().toISOString()
    }
  ];

  const handleGenerate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!moodInput.trim()) return;
    setErrorMsg("");

    const cost = 5;
    if (credits < cost) {
      setErrorMsg(lang === "en" ? "Insufficient credits! Recharge from your profile first." : "পর্যাপ্ত ক্রেডিট নেই! নতুন কালার প্যালেট তৈরি করতে ক্রেডিট নিন।");
      return;
    }

    setLoading(true);

    try {
      const response = await fetch("/api/color/generate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          nicheOrMood: moodInput.trim(),
          generationRule: harmonyRule
        }),
      });

      if (!response.ok) {
        throw new Error("Could not contact the color system. Check server logs.");
      }

      const data: ColorPaletteSpec = await response.json();

      const deducted = deductCredits(cost, `Color Palette: ${data.paletteName}`);
      if (!deducted) {
        setErrorMsg(lang === "en" ? "Insufficient credits!" : "পর্যাপ্ত ক্রেডিট নেই!");
        setLoading(false);
        return;
      }

      onColorGenerated(data);
      setSelectedPalette(data);
      setActiveTab("create");
      setMoodInput("");
    } catch (err: any) {
      setErrorMsg(err.message || "Failed to compile color formulas. Please retry.");
    } finally {
      setLoading(false);
    }
  };

  const handleCopyHex = (hex: string) => {
    navigator.clipboard.writeText(hex);
    setCopiedHex(hex);
    setTimeout(() => setCopiedHex(null), 1500);
  };

  const allPalettes = [...recentPalettes, ...mockPalettes];
  const activePalette = selectedPalette || allPalettes[0];

  return (
    <div className="space-y-6">
      {/* Module Title */}
      <div className="text-left border-b border-white/5 pb-4">
        <h2 className="text-xl font-display font-medium text-white flex items-center gap-2">
          <Palette className="w-5 h-5 text-indigo-400 rotate-45" />
          {lang === "en" ? "Interactive Color Palette Generator" : "এআই কালার প্যালেট জেনারেটর"}
        </h2>
        <p className="text-xs text-slate-400 mt-1">
          {lang === "en"
            ? "Synthesize beautifully cohesive color schemes from visual keywords and preview them in a live design sandbox."
            : "যেকোনো ধরণের মুড, কীওয়ার্ড অথবা ব্র্যান্ডের জন্য মানানসই ৫টি রঙের কালার প্যালেট তৈরি করুন।"}
        </p>
      </div>

      {/* Tabs */}
      <div className="flex bg-[#121212] border border-white/5 p-1 rounded-xl w-fit">
        <button
          onClick={() => setActiveTab("create")}
          className={`px-4 py-1.5 rounded-lg text-xs font-semibold cursor-pointer transition-all ${
            activeTab === "create"
              ? "bg-indigo-600 text-white shadow-md shadow-indigo-900/30"
              : "text-slate-400 hover:text-white"
          }`}
        >
          {lang === "en" ? "🎨 Color Synthesizer" : "🎨 কালার ডিজাইনার"}
        </button>
        <button
          onClick={() => setActiveTab("library")}
          className={`px-4 py-1.5 rounded-lg text-xs font-semibold cursor-pointer transition-all ${
            activeTab === "library"
              ? "bg-indigo-600 text-white shadow-md shadow-indigo-900/30"
              : "text-slate-400 hover:text-white"
          }`}
        >
          {lang === "en" ? "📁 Swatch Archive" : "📁 কালার লাইব্রেরি"}
        </button>
      </div>

      {activeTab === "create" && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 text-left">
          {/* Creator panel */}
          <div className="lg:col-span-4 bg-[#121212] border border-white/5 p-6 rounded-2xl h-fit space-y-4">
            <h3 className="text-sm font-semibold tracking-wide text-white uppercase flex items-center gap-1.5">
              <Paintbrush className="w-4 h-4 text-indigo-400" />
              {lang === "en" ? "Palette Parameters" : "রঙের টোন ও প্যারামিটারসমূহ"}
            </h3>

            <form onSubmit={handleGenerate} className="space-y-4 font-sans">
              <div className="space-y-1">
                <label className="text-[10px] font-mono font-bold text-slate-400 uppercase">
                  {lang === "en" ? "Describe Mood / Keywords" : "প্যালেট মুড বর্ণনা করুন"}
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g., Organic Avocado, Cyberpunk Laser..."
                  value={moodInput}
                  onChange={(e) => setMoodInput(e.target.value)}
                  className="w-full text-xs px-3.5 py-2.5 bg-[#1a1a1a] border border-white/5 rounded-xl text-white placeholder-slate-600 focus:outline-none focus:border-indigo-500/50"
                />
              </div>

              <div className="space-y-1">
                <label className="text-[10px] font-mono font-bold text-slate-400 uppercase">
                  {lang === "en" ? "Color Harmony Rule" : "কালার হারমনি রুল"}
                </label>
                <select
                  value={harmonyRule}
                  onChange={(e) => setHarmonyRule(e.target.value)}
                  className="w-full text-xs px-3.5 py-2.5 bg-[#1a1a1a] border border-white/5 rounded-xl text-white focus:outline-none focus:border-indigo-500/50 cursor-pointer"
                >
                  {["Monochromatic Scale", "Analogous Balance", "Complementary High-Contrast", "Triadic Warm-Cool", "Tetradic Dual-Contrast"].map((r) => (
                    <option key={r} value={r}>{r}</option>
                  ))}
                </select>
              </div>

              <button
                type="submit"
                disabled={loading}
                className="w-full py-2.5 bg-indigo-600 hover:bg-indigo-500 disabled:bg-indigo-900/40 text-white rounded-xl text-xs font-bold font-mono tracking-wider cursor-pointer active:scale-95 transition-all flex items-center justify-center gap-1.5"
              >
                {loading ? (
                  <>
                    <RefreshCcw className="w-3.5 h-3.5 animate-spin" />
                    <span>{lang === "en" ? "Compiling Spectrum..." : "বর্ণালী সাজানো হচ্ছে..."}</span>
                  </>
                ) : (
                  <>
                    <Shuffle className="w-3.5 h-3.5 animate-spin-slow" />
                    <span>{lang === "en" ? "Generate Swatches (5 Credits)" : "পালস জেনারেট (৫ ক্রেডিট)"}</span>
                  </>
                )}
              </button>
            </form>

            {errorMsg && (
              <p className="text-xs bg-red-950/20 border border-red-900/30 text-red-400 p-3 rounded-xl">
                {errorMsg}
              </p>
            )}

            {/* Quick Suggestions list */}
            <div className="pt-2 border-t border-white/5 space-y-2">
              <span className="text-[10px] font-mono text-slate-500 uppercase block">{lang === "en" ? "Popular Aesthetics" : "জনপ্রিয় থিমসমূহ"}</span>
              <div className="flex flex-wrap gap-1.5">
                {["Synthwave Retro", "Earthy Sand Dunes", "Nordic Cozy Minimalist", "Vibrant Crypto", "Warm Coffee Cozy"].map((p) => (
                  <button
                    key={p}
                    onClick={() => setMoodInput(p)}
                    className="px-2 py-1 bg-white/5 hover:bg-white/10 text-[10px] text-slate-300 rounded-md transition-all cursor-pointer"
                  >
                    + {p}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Swatches block & Interactive Sandbox visualizer */}
          <div className="lg:col-span-8 space-y-6">
            {activePalette ? (
              <div className="space-y-6">
                
                {/* 5-Color Row blocks */}
                <div className="space-y-2">
                  <span className="text-[10px] tracking-widest font-mono text-slate-400 uppercase font-bold">
                    {lang === "en" ? "CLICK SWATCH TO COPY HEX CODE" : "কালার স্যাম্পল (কনফিগার করার জন্য ক্লিক ও কপি করুন)"}
                  </span>
                  
                  <div className="grid grid-cols-1 sm:grid-cols-5 gap-3">
                    {activePalette.colors.map((item, idx) => (
                      <div 
                        key={item.hex + idx}
                        onClick={() => handleCopyHex(item.hex)}
                        className="bg-[#121212] border border-white/5 hover:border-indigo-500/40 p-3 rounded-2xl cursor-pointer transition-all active:scale-95 text-left group"
                        title={`Click to copy: ${item.hex}`}
                      >
                        <div 
                          className="w-full aspect-video sm:aspect-square rounded-xl border border-white/5 shadow-inner relative"
                          style={{ backgroundColor: item.hex }}
                        >
                          {copiedHex === item.hex && (
                            <div className="absolute inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center rounded-xl">
                              <span className="text-[10px] font-bold text-green-400 font-mono tracking-wider uppercase">Copied!</span>
                            </div>
                          )}
                        </div>
                        <div className="mt-2.5">
                          <h4 className="text-xs font-bold text-white tracking-tight truncate">{item.name}</h4>
                          <p className="text-[10px] font-mono text-indigo-400 font-bold mt-0.5">{item.hex}</p>
                          <p className="text-[9px] text-slate-500 leading-tight mt-1 line-clamp-2 h-6">{item.usage}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Mood Description & Accessibility Check */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                  <div className="bg-[#121212] border border-white/5 p-5 rounded-2xl space-y-2">
                    <span className="text-[9px] font-mono text-indigo-400 uppercase tracking-widest font-bold block">Palette Inspiration Mood</span>
                    <h3 className="text-lg font-display font-medium text-white capitalize">{activePalette.paletteName}</h3>
                    <p className="text-xs text-slate-400 leading-relaxed text-justify">{activePalette.moodDescription}</p>
                  </div>

                  <div className="bg-[#121212] border border-white/5 p-5 rounded-2xl flex flex-col justify-between">
                    <div className="space-y-1">
                      <span className="text-[9px] font-mono text-indigo-400 uppercase tracking-widest font-bold block">Contrast & Accessibility Rating</span>
                      <h3 className="text-xs font-semibold text-white uppercase flex items-center gap-1.5">
                        <ShieldCheck className="w-4 h-4 text-green-400 inline" />
                        WCAG 2.1 Compliant Audit
                      </h3>
                      <p className="text-xs text-slate-400 leading-relaxed mt-2 text-justify">
                        {activePalette.contrastAudit}
                      </p>
                    </div>
                    <div className="border-t border-white/5 mt-3 pt-2 text-[10px] font-mono text-slate-500 text-right">
                      AA standard checks certified
                    </div>
                  </div>
                </div>

                {/* THE AMAZING INTERACTIVE DESIGN SANDBOX DEMO */}
                <div className="bg-[#121212] border border-white/5 p-6 rounded-2xl space-y-4 text-left">
                  <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 border-b border-white/5 pb-3">
                    <div>
                      <h3 className="text-sm font-semibold text-white uppercase tracking-wide flex items-center gap-2">
                        <Layout className="w-4 h-4 text-indigo-400" />
                        {lang === "en" ? "Interactive Live Wireframe Sandbox" : "ইন্টারেক্টিভ লাইভ স্যান্ডবক্স ডিজাইন"}
                      </h3>
                      <p className="text-[11px] text-slate-400 mt-0.5">{lang === "en" ? "See how this palette acts under responsive UI mock components." : "তৈরিকৃত রঙগুলো লাইভ ডিজাইনে কেমন দেখাবে তা পরীক্ষা করুন। "}</p>
                    </div>

                    {/* Switch layout representation */}
                    <div className="flex p-0.5 bg-white/5 border border-white/5 rounded-lg text-[10px]">
                      {(["saas", "card", "fintech"] as const).map((l) => (
                        <button
                          key={l}
                          onClick={() => setSandboxLayout(l)}
                          className={`px-3 py-1 rounded cursor-pointer capitalize ${
                            sandboxLayout === l ? "bg-[#18181b] text-indigo-300 font-bold" : "text-slate-400 hover:text-white"
                          }`}
                        >
                          {l} view
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Canvas driven entirely by the generated colors! */}
                  {(() => {
                    // Extract safe colors to prevent DOM errors
                    const bgCol = activePalette.colors[0]?.hex || "#000000";
                    const containerCol = activePalette.colors[3]?.hex || "#111118";
                    const actionCol = activePalette.colors[1]?.hex || "#3b82f6";
                    const hoverCol = activePalette.colors[2]?.hex || "#4f46e5";
                    const textCol = activePalette.colors[4]?.hex || "#ffffff";

                    return (
                      <div 
                        className="rounded-xl p-6 sm:p-10 border transition-colors duration-500 flex flex-col items-center justify-center min-h-[250px] relative"
                        style={{ 
                          backgroundColor: bgCol,
                          borderColor: `rgba(255,255,255,0.08)`
                        }}
                      >
                        <span className="absolute top-2.5 right-3 text-[9px] font-mono uppercase tracking-widest text-[#888888]/80 select-none">
                          Interactive Live Render Mode
                        </span>

                        {sandboxLayout === "saas" && (
                          <div 
                            className="w-full max-w-md p-6 rounded-2xl text-center space-y-4 border shadow-2xl transition-all duration-300 transform hover:scale-101"
                            style={{ 
                              backgroundColor: containerCol,
                              borderColor: `rgba(255,255,255,0.06)`
                            }}
                          >
                            <div className="mx-auto w-10 h-10 rounded-full flex items-center justify-center border" style={{ borderColor: `${actionCol}20`, backgroundColor: `${actionCol}10` }}>
                              <Monitor className="w-5 h-5" style={{ color: actionCol }} />
                            </div>
                            <div className="space-y-1">
                              <h4 className="text-base font-semibold tracking-tight" style={{ color: textCol }}>
                                {activePalette.landingPageDemo.heroText}
                              </h4>
                              <p className="text-[11px] max-w-xs mx-auto text-slate-400">
                                Evolve your visual deployment pipeline with high contrast color systems and rapid semantic synthesis.
                              </p>
                            </div>
                            <div className="pt-2">
                              <button 
                                className="px-5 py-2 text-xs font-bold font-mono tracking-wider rounded-xl cursor-pointer active:scale-95 transition-all w-full"
                                style={{ 
                                  backgroundColor: actionCol,
                                  color: textCol,
                                  boxShadow: `0 4px 12px ${actionCol}30`
                                }}
                              >
                                {activePalette.landingPageDemo.ctaText}
                              </button>
                            </div>
                          </div>
                        )}

                        {sandboxLayout === "card" && (
                          <div 
                            className="w-full max-w-xs p-5 rounded-2xl border shadow-2xl space-y-4 text-left"
                            style={{ 
                              backgroundColor: containerCol,
                              borderColor: `rgba(255,255,255,0.06)`
                            }}
                          >
                            <div className="flex justify-between items-center">
                              <div className="p-1.5 rounded-lg" style={{ backgroundColor: `${actionCol}15` }}>
                                <Mail className="w-4 h-4" style={{ color: actionCol }} />
                              </div>
                              <span className="text-[9px] font-mono text-slate-500 uppercase">Newsletter</span>
                            </div>

                            <div className="space-y-1">
                              <h4 className="text-sm font-bold" style={{ color: textCol }}>Get UI Hacks Instantly</h4>
                              <p className="text-[10px] text-slate-400">Join 15,280 design curators. We dispatch raw CSS formulas and aesthetic patterns every Wednesday.</p>
                            </div>

                            <div className="flex gap-1.5 pt-1.5">
                              <input 
                                disabled
                                placeholder="name@domain.com"
                                className="bg-[#000000]/30 border border-white/5 text-[9px] px-2.5 py-1.5 rounded-lg flex-grow focus:outline-none"
                              />
                              <button 
                                className="px-3 text-[9px] font-bold rounded-lg cursor-pointer"
                                style={{ backgroundColor: actionCol, color: textCol }}
                              >
                                Join
                              </button>
                            </div>
                          </div>
                        )}

                        {sandboxLayout === "fintech" && (
                          <div 
                            className="w-full max-w-sm p-5 rounded-2xl border shadow-2xl space-y-4"
                            style={{ 
                              backgroundColor: containerCol,
                              borderColor: `rgba(255,255,255,0.06)`
                            }}
                          >
                            <div className="flex justify-between items-center text-xs">
                              <span className="font-mono text-slate-400 flex items-center gap-1">
                                <CreditCard className="w-3.5 h-3.5" style={{ color: actionCol }} /> Savings Wallet Spec
                              </span>
                              <span style={{ color: hoverCol }} className="text-[10px] font-bold font-mono">ACTIVE NODE</span>
                            </div>

                            <div className="grid grid-cols-2 gap-4">
                              <div className="p-3 bg-black/20 rounded-xl">
                                <span className="text-[9px] font-mono text-slate-500 uppercase block mb-0.5">Primary Fund Balance</span>
                                <h5 className="text-lg font-bold font-mono" style={{ color: textCol }}>$92,480.99</h5>
                              </div>
                              <div className="p-3 bg-black/20 rounded-xl">
                                <span className="text-[9px] font-mono text-slate-500 uppercase block mb-0.5">Monthly yield margin</span>
                                <h5 className="text-lg font-bold font-mono" style={{ color: hoverCol }}>+ 12.4%</h5>
                              </div>
                            </div>
                          </div>
                        )}

                      </div>
                    );
                  })()}
                </div>
              </div>
            ) : (
              <div className="p-12 border border-dashed border-white/10 rounded-2xl text-center text-slate-500 font-mono">
                <p>{lang === "en" ? "Synthesizing chromatic streams..." : "প্যালেট লোড করা হচ্ছে..."}</p>
              </div>
            )}
          </div>
        </div>
      )}

      {activeTab === "library" && (
        <div className="space-y-4 text-left">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {allPalettes.map((pal) => (
              <div 
                key={pal.id}
                onClick={() => {
                  setSelectedPalette(pal);
                  setActiveTab("create");
                }}
                className="bg-[#121212] border border-white/5 p-5 rounded-2xl hover:border-indigo-500/30 transition-all cursor-pointer active:scale-98 relative group"
              >
                <div className="flex justify-between items-center mb-3">
                  <h4 className="text-base font-display font-medium text-white tracking-tight capitalize">{pal.paletteName}</h4>
                  <span className="text-[9px] font-mono text-slate-500 uppercase">Palette file</span>
                </div>
                
                {/* Horizontal Swatch strip */}
                <div className="grid grid-cols-5 gap-1.5 mb-3.5">
                  {pal.colors.map((c, i) => (
                    <div 
                      key={c.hex + i} 
                      className="h-8 rounded-lg border border-white/5" 
                      style={{ backgroundColor: c.hex }} 
                      title={`${c.name}: ${c.hex}`}
                    />
                  ))}
                </div>

                <p className="text-xs text-slate-400 line-clamp-2 leading-relaxed">{pal.moodDescription}</p>
                
                <div className="mt-4 pt-3 border-t border-white/5 flex justify-between items-center text-[10px] font-mono text-slate-500">
                  <span>Usage: {pal.colors[2]?.name || "Accent"}</span>
                  <span className="group-hover:text-indigo-400 transition-all flex items-center gap-1">Load Swatch <Eye className="w-3 h-3" /></span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
