/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import { TRANSLATIONS, LanguageCode } from "../lib/translations";
import { InspirationSpec } from "../types";
import { 
  Sparkles, RefreshCcw, Compass, Layers, Highlighter, 
  Palette, Lightbulb, Grid, Copy, Eye, AppWindow, Image
} from "lucide-react";

interface InspirationHubModuleProps {
  lang: LanguageCode;
  credits: number;
  deductCredits: (qty: number, actionTitle: string) => boolean;
  onInspirationGenerated: (insp: InspirationSpec) => void;
  recentInspirations: InspirationSpec[];
}

export default function InspirationHubModule({
  lang,
  credits,
  deductCredits,
  onInspirationGenerated,
  recentInspirations
}: InspirationHubModuleProps) {
  const [nicheInput, setNicheInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [imageGenerating, setImageGenerating] = useState(false);
  const [errorMsg, setErrorMsg] = useState("");
  const [activeTab, setActiveTab] = useState<"create" | "gallery">("create");
  const [selectedInsp, setSelectedInsp] = useState<InspirationSpec | null>(null);
  const [copiedToken, setCopiedToken] = useState<string | null>(null);
  const [paintedScreenshot, setPaintedScreenshot] = useState<string | null>(null);

  // Pre-configured curated inspirations for instant discovery
  const mockCuratedInspirations: InspirationSpec[] = [
    {
      id: "cur_1",
      niche: "Crypto Trading terminal",
      recommendedConcept: "Dark graphite terminal layout with blazing neon cyan tickers and glowing high-fidelity line graphs.",
      wireframeBlueprint: "Three-column modular layout. Left wing manages list-views of active coin nodes. High-contrast centralized graph viewport displays raw candelstick analytics with live hovering crosshairs. Right rail serves absolute price tickers and dynamic order submission forms.",
      typographySystem: {
        displayFont: "Outfit (Extrabold, Tracking-tight display headers)",
        bodyFont: "Inter (Medium-density, crisp labels and descriptions)",
        monoFont: "JetBrains Mono (For rapid numerical ticks and transaction hashes)"
      },
      aestheticTokens: {
        background: "#08090C",
        primaryAccent: "#00F2FE",
        secondaryAccent: "#FF007A",
        surface: "#11141E",
        border: "rgba(0, 242, 254, 0.15)"
      },
      uxHotspots: [
        "Dynamic flickering green-red border states on candlestick graph thresholds.",
        "One-click quick buying shortcuts via double-clicking raw table numbers.",
        "Live network congestion delay displayed in the bottom status indicator."
      ],
      visualPrompts: {
        uiArtwork: "Futuristic crypto terminal interface design, neon cyan and magenta line charts, glassmorphic trading grids, cyber aesthetic, 3D render look, 8k"
      },
      createdAt: new Date().toISOString()
    },
    {
      id: "cur_2",
      niche: "Eco Energy IoT Dashboard",
      recommendedConcept: "Bright warm-minimalist modern layout utilizing generous negative space, soft sand hues, and fresh herbal emerald accents.",
      wireframeBlueprint: "Z-pattern responsive reading layout. Hero top section showcases a massive circular solar battery charging gauge with smooth progress animations. Lower rows list historical grid-returns in a dual-column modular list view.",
      typographySystem: {
        displayFont: "Space Grotesk (Medium weight, eco-modern geometry)",
        bodyFont: "Plus Jakarta Sans (Light weight, breathable block text spacing)",
        monoFont: "Fira Code (For tracking green kilowatt-hour counts)"
      },
      aestheticTokens: {
        background: "#F6F5F2",
        primaryAccent: "#059669",
        secondaryAccent: "#D97706",
        surface: "#FFFFFF",
        border: "rgba(5, 150, 105, 0.1)"
      },
      uxHotspots: [
        "A live floating herb-leaf micro-animation representing daily target goals.",
        "Smooth scroll tracking that maps kilowatt grids dynamically on hover state.",
        "Slide-over configurations panel for active home energy nodes."
      ],
      visualPrompts: {
        uiArtwork: "Eco technology smart home app dashboard design, soothing sand offwhite canvas, dark green forest and bright amber dials, flat modern interface, 3d render"
      },
      createdAt: new Date().toISOString()
    }
  ];

  const handleGenerate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!nicheInput.trim()) return;
    setErrorMsg("");

    const cost = 10;
    if (credits < cost) {
      setErrorMsg(lang === "en" ? "Insufficient credits! Click top-right '+' to recharge free credits." : "পর্যাপ্ত ক্রেডিট নেই! নতুন জেনারেশনের জন্য ক্রেডিট রিচার্জ করুন।");
      return;
    }

    setLoading(true);
    setPaintedScreenshot(null);

    try {
      const response = await fetch("/api/inspiration/generate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ niche: nicheInput.trim() }),
      });

      if (!response.ok) {
        throw new Error("Failed to reach design hub. Check backend connection.");
      }

      const data: InspirationSpec = await response.json();

      const deducted = deductCredits(cost, `Design Spec: ${data.niche}`);
      if (!deducted) {
        setErrorMsg(lang === "en" ? "Insufficient credits!" : "পর্যাপ্ত ক্রেডিট নেই!");
        setLoading(false);
        return;
      }

      onInspirationGenerated(data);
      setSelectedInsp(data);
      setActiveTab("create");
      setNicheInput("");
    } catch (err: any) {
      setErrorMsg(err.message || "Failed to design blueprint. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  const paintConceptArtwork = async () => {
    if (!selectedInsp) return;
    setErrorMsg("");

    const cost = 20;
    if (credits < cost) {
      setErrorMsg(lang === "en" ? "Insufficient credits! Requires 20 credits to call Imagen Artwork painting." : "পর্যাপ্ত ক্রেডিট নেই! ইমেজ পেইন্টিংয়ের জন্য ২০ ক্রেডিট প্রয়োজন।");
      return;
    }

    setImageGenerating(true);

    try {
      const response = await fetch("/api/generate-image", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ prompt: selectedInsp.visualPrompts.uiArtwork }),
      });

      const data = await response.json();
      if (!response.ok || !data.success) {
        throw new Error(data.message || data.error || "Failed to paint canvas screenshot.");
      }

      const deducted = deductCredits(cost, `Concept Art: ${selectedInsp.niche}`);
      if (!deducted) return;

      setPaintedScreenshot(data.image);
    } catch (err: any) {
      setErrorMsg(err.message || "Could not spin Gemini image API. Please verify Gemini API key settings.");
    } finally {
      setImageGenerating(false);
    }
  };

  const handleCopyText = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    setCopiedToken(label);
    setTimeout(() => setCopiedToken(null), 1500);
  };

  const allInspirations = [...recentInspirations, ...mockCuratedInspirations];
  const activeInsp = selectedInsp || allInspirations[0];

  return (
    <div className="space-y-6">
      {/* Module Title */}
      <div className="text-left border-b border-white/5 pb-4">
        <h2 className="text-xl font-display font-medium text-white flex items-center gap-2">
          <Compass className="w-5 h-5 text-indigo-400 animate-spin-slow" />
          {lang === "en" ? "Design Inspiration Hub" : "ডিজাইন ইন্সপিরেশন হাব"}
        </h2>
        <p className="text-xs text-slate-400 mt-1">
          {lang === "en" 
            ? "Architect beautiful layout blueprints, aesthetic tokens, wireframe plans and pair typography instantly." 
            : "যেকোনো ধরণের ডিজাইন নিশের জন্য এআই ওয়্যারফ্রেম ব্লুপ্রিন্ট, আর্টওয়ার্ক প্রম্পট এবং কালার স্কিম তৈরি করুন।"}
        </p>
      </div>

      {/* Mode selectors */}
      <div className="flex bg-[#121212] border border-white/5 p-1 rounded-xl w-fit">
        <button
          onClick={() => setActiveTab("create")}
          className={`px-4 py-1.5 rounded-lg text-xs font-semibold cursor-pointer transition-all ${
            activeTab === "create"
              ? "bg-indigo-600 text-white shadow-md"
              : "text-slate-400 hover:text-white"
          }`}
        >
          {lang === "en" ? "💡 Layout Architect" : "💡 ডিজাইন আর্কিটেক্ট"}
        </button>
        <button
          onClick={() => setActiveTab("gallery")}
          className={`px-4 py-1.5 rounded-lg text-xs font-semibold cursor-pointer transition-all ${
            activeTab === "gallery"
              ? "bg-indigo-600 text-white shadow-md"
              : "text-slate-400 hover:text-white"
          }`}
        >
          {lang === "en" ? "🗂️ Inspiration Gallery" : "🗂️ ডিজাইন লাইব্রেরি"}
        </button>
      </div>

      {activeTab === "create" && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 text-left">
          {/* Creator form */}
          <div className="lg:col-span-4 bg-[#121212] border border-white/5 p-6 rounded-2xl h-fit space-y-4">
            <h3 className="text-sm font-semibold tracking-wide text-white uppercase flex items-center gap-2">
              <Layers className="w-4 h-4 text-indigo-400" />
              {lang === "en" ? "Formulate Niche" : "নিশ সিলেক্ট করুন"}
            </h3>

            <form onSubmit={handleGenerate} className="space-y-4">
              <div className="space-y-1.5">
                <label className="text-[11px] font-mono font-medium text-slate-400 uppercase">
                  {lang === "en" ? "Application Niche / Category" : "অ্যাপ্লিকেশন বা ওয়েবসাইট ক্যাটাগরি"}
                </label>
                <input
                  type="text"
                  required
                  value={nicheInput}
                  onChange={(e) => setNicheInput(e.target.value)}
                  placeholder={lang === "en" ? "e.g., Dental booking portal, Web3 dex..." : "যেমন: ডেন্টাল অ্যাপ বুকিং, রিয়েল এস্টেট ল্যান্ডিং..."}
                  className="w-full text-xs px-3.5 py-2.5 bg-[#1a1a1a] border border-white/5 rounded-xl text-white placeholder-slate-600 focus:outline-none focus:border-indigo-500/50"
                />
              </div>

              <button
                type="submit"
                disabled={loading}
                className="w-full py-2.5 bg-indigo-600 hover:bg-indigo-500 disabled:bg-indigo-900/40 text-white rounded-xl text-xs font-bold font-mono tracking-wider cursor-pointer active:scale-95 transition-all flex items-center justify-center gap-2"
              >
                {loading ? (
                  <>
                    <RefreshCcw className="w-3.5 h-3.5 animate-spin" />
                    <span>{lang === "en" ? "Architecting Grid System..." : "ব্লুপ্রিন্ট রেডি হচ্ছে..."}</span>
                  </>
                ) : (
                  <>
                    <Sparkles className="w-3.5 h-3.5" />
                    <span>{lang === "en" ? "Architect Design (10 Credits)" : "ডিজাইন ব্লুপ্রিন্ট (১০ ক্রেডিট)"}</span>
                  </>
                )}
              </button>
            </form>

            {errorMsg && (
              <p className="text-xs bg-red-950/20 border border-red-900/30 text-red-400 p-3 rounded-xl">
                {errorMsg}
              </p>
            )}

            {/* Quick Suggestions list */}
            <div className="pt-2 border-t border-white/5">
              <span className="text-[10px] font-mono text-slate-500 uppercase block mb-2">{lang === "en" ? "Quick Niche Ideas" : "আইডিয়া সাজেশন"}</span>
              <div className="flex flex-wrap gap-1.5">
                {["SaaS Dashboard", "AI Chat Interface", "Retro Portfolio", "E-Commerce Checkout", "Travel Agency Portal"].map((s) => (
                  <button
                    key={s}
                    type="button"
                    onClick={() => setNicheInput(s)}
                    className="px-2 py-1 bg-white/5 hover:bg-white/10 text-[10px] text-slate-300 rounded-md transition-all cursor-pointer"
                  >
                    + {s}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Result details bento-grid layout */}
          <div className="lg:col-span-8 space-y-5">
            {activeInsp ? (
              <div className="space-y-5">
                {/* Visual Card simulation with custom state colors */}
                <div 
                  className="p-6 rounded-2xl border transition-all duration-500 relative overflow-hidden"
                  style={{
                    backgroundColor: activeInsp.aestheticTokens.background.startsWith("#") ? activeInsp.aestheticTokens.background : "#0c0d12",
                    borderColor: activeInsp.aestheticTokens.border.includes("rgba") ? activeInsp.aestheticTokens.border : "rgba(255,255,255,0.06)"
                  }}
                >
                  <div className="absolute top-0 right-0 w-64 h-64 bg-indigo-500/5 blur-[80px] rounded-full pointer-events-none" />

                  <div className="flex justify-between items-start gap-3 relative z-10">
                    <div>
                      <span className="text-[9px] px-2 py-0.5 bg-indigo-600/20 border border-indigo-500/30 font-bold font-mono text-indigo-300 tracking-wider uppercase rounded-full">
                        {lang === "en" ? "INSPIRATION BLUEPRINT" : "ডিজাইন ইন্সপিরেশন"}
                      </span>
                      <h4 className="text-lg font-display font-medium text-white mt-1.5 capitalized">
                        {activeInsp.niche}
                      </h4>
                    </div>
                    <span className="text-[10px] font-mono text-slate-500">
                      {activeInsp.aiGenerated ? "🤖 AI Generated" : "📁 Design File"}
                    </span>
                  </div>

                  <p className="text-sm font-medium text-slate-200 mt-4 leading-relaxed max-w-2xl">
                    {activeInsp.recommendedConcept}
                  </p>

                  {/* Aesthetic Color circles */}
                  <div className="mt-6 flex flex-wrap items-center gap-4">
                    <span className="text-[10px] font-mono text-slate-400 block uppercase tracking-wide">
                      {lang === "en" ? "Aesthetic Tokens" : "রঙের টোকেনসমূহ"}:
                    </span>
                    <div className="flex flex-wrap gap-2.5">
                      {Object.entries(activeInsp.aestheticTokens).map(([key, value]) => {
                        const valStr = typeof value === "string" ? value : String(value || "");
                        const hex = valStr.split(" ")[0] || "#999999";
                        return (
                          <div 
                            key={key} 
                            onClick={() => handleCopyText(hex, key)}
                            className="flex items-center gap-1.5 bg-black/40 border border-white/5 px-2 py-1 rounded-lg text-[10px] font-mono text-slate-300 cursor-pointer hover:bg-black/60 transition-all active:scale-95"
                            title={`Click to copy: ${hex}`}
                          >
                            <span 
                              className="w-2.5 h-2.5 rounded-full inline-block border border-white/10 shadow-sm"
                              style={{ backgroundColor: hex }} 
                            />
                            <span>{key}: {hex}</span>
                            <Copy className="w-2.5 h-2.5 text-slate-500 hover:text-white shrink-0" />
                          </div>
                        );
                      })}
                    </div>
                  </div>
                  {copiedToken && (
                    <span className="text-[10px] font-mono text-green-400 animate-pulse mt-1 block">
                      Copied token {copiedToken} hex code success!
                    </span>
                  )}
                </div>

                {/* Wireframe skeleton block */}
                <div className="bg-[#121212] border border-white/5 p-6 rounded-2xl space-y-4">
                  <h3 className="text-sm font-semibold text-white uppercase tracking-wide flex items-center gap-2">
                    <Grid className="w-4 h-4 text-indigo-400" />
                    {lang === "en" ? "Visual Skeleton Wireframe" : "ভিজ্যুয়াল স্কেলেটন ওয়্যারফ্রেম"}
                  </h3>

                  <div className="grid grid-cols-1 md:grid-cols-12 gap-5 items-stretch">
                    <div className="md:col-span-5 bg-[#18181b] border border-white/5 p-4 rounded-xl leading-relaxed text-xs text-slate-400 space-y-2.5">
                      <p>{activeInsp.wireframeBlueprint}</p>
                      <div className="pt-2 border-t border-white/5 space-y-1.5">
                        <span className="text-[10px] block font-mono font-bold text-indigo-400 uppercase tracking-widest">{lang === "en" ? "UX Highlights" : "ইউএক্স হাইলাইটস"}</span>
                        <ul className="list-disc pl-4 space-y-1">
                          {activeInsp.uxHotspots.map((h, i) => (
                            <li key={i}>{h}</li>
                          ))}
                        </ul>
                      </div>
                    </div>

                    {/* Interactive mock blueprint layout */}
                    <div className="md:col-span-7 bg-[#0b0c10] border border-white/10 rounded-xl p-4 flex flex-col justify-between min-h-[220px] relative overflow-hidden">
                      {/* Grid representation */}
                      <div className="absolute inset-0 opacity-10 bg-[linear-gradient(to_right,#808080_1px,transparent_1px),linear-gradient(to_bottom,#808080_1px,transparent_1px)] bg-[size:14px_24px]" />
                      
                      <div className="flex items-center justify-between border-b border-white/5 pb-2 relative z-10 text-[10px] font-mono text-slate-500 uppercase">
                        <span>{activeInsp.niche} Layout Wireframe Mock</span>
                        <div className="flex gap-1">
                          <span className="w-1.5 h-1.5 rounded-full bg-red-500 inline-block" />
                          <span className="w-1.5 h-1.5 rounded-full bg-yellow-500 inline-block" />
                          <span className="w-1.5 h-1.5 rounded-full bg-green-500 inline-block" />
                        </div>
                      </div>

                      {/* Display a simulated layout based on wireframe style */}
                      <div className="grid grid-cols-12 gap-2 mt-3 relative z-10 flex-grow">
                        {/* Sidebar */}
                        <div className="col-span-3 bg-white/5 border border-white/5 rounded-lg p-2 space-y-1.5 flex flex-col justify-start">
                          <div className="h-2 w-full bg-indigo-500/20 rounded-sm" />
                          <div className="h-1 text-[8px] scale-90 origin-left text-slate-500">Nav Node</div>
                          <div className="h-1.5 w-10/12 bg-white/5 rounded-sm" />
                          <div className="h-1.5 w-8/12 bg-white/5 rounded-sm" />
                          <div className="h-1.5 w-9/12 bg-white/5 rounded-sm" />
                        </div>
                        
                        {/* Main body */}
                        <div className="col-span-9 space-y-2 flex flex-col justify-between">
                          <div className="grid grid-cols-3 gap-1.5">
                            <div className="bg-[#151722] border border-indigo-500/10 rounded p-1.5 text-center">
                              <div className="h-1 bg-white/10 rounded-sm mb-1" />
                              <div className="text-[10px] font-mono text-indigo-400 font-bold">$49.2K</div>
                              <div className="h-0.5 bg-emerald-500/20 rounded-sm" />
                            </div>
                            <div className="bg-[#151722] border border-indigo-500/10 rounded p-1.5 text-center">
                              <div className="h-1 bg-white/10 rounded-sm mb-1" />
                              <div className="text-[10px] font-mono text-indigo-400 font-bold">1,829</div>
                              <div className="h-0.5 bg-emerald-500/20 rounded-sm" />
                            </div>
                            <div className="bg-[#151722] border border-indigo-500/10 rounded p-1.5 text-center">
                              <div className="h-1 bg-white/10 rounded-sm mb-1" />
                              <div className="text-[10px] font-mono text-red-400 font-bold">51.2%</div>
                              <div className="h-0.5 bg-red-500/20 rounded-sm" />
                            </div>
                          </div>

                          <div className="bg-[#111218] border border-white/5 rounded-lg p-2.5 flex-grow flex flex-col justify-center items-center">
                            <span className="text-[9px] font-mono text-indigo-300 mb-1.5">Central Visualization Node</span>
                            <div className="w-11/12 h-6 bg-gradient-to-r from-indigo-500/5 via-indigo-500/20 to-indigo-500/5 rounded border border-indigo-500/10 relative overflow-hidden flex items-center justify-center">
                              {/* Glowing signal line graph representation */}
                              <svg className="absolute inset-0 w-full h-full" viewBox="0 0 100 20" preserveAspectRatio="none">
                                <path d="M0,10 Q25,3 50,15 T100,2" fill="none" stroke="#6366f1" strokeWidth="1.5" className="animate-pulse" />
                              </svg>
                            </div>
                          </div>
                        </div>
                      </div>

                      <div className="border-t border-white/5 pt-1.5 mt-2 flex justify-between items-center text-[8px] font-mono text-slate-500 relative z-10 uppercase">
                        <span>Metrics Sync Completed</span>
                        <span>Responsive XL view</span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Typography System */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                  <div className="bg-[#121212] border border-white/5 p-6 rounded-2xl space-y-4">
                    <h3 className="text-sm font-semibold text-white uppercase tracking-wide flex items-center gap-2">
                      <Highlighter className="w-4 h-4 text-indigo-400" />
                      {lang === "en" ? "Typography Pairings" : "ফন্ট কম্বিনেশন গাইড"}
                    </h3>

                    <div className="space-y-4">
                      <div className="p-3 bg-white/5 rounded-xl">
                        <span className="text-[10px] font-mono font-bold text-indigo-300 block uppercase mb-1">Display Headings</span>
                        <p className="text-base font-medium tracking-tight text-white">{activeInsp.typographySystem.displayFont}</p>
                      </div>
                      <div className="p-3 bg-white/5 rounded-xl">
                        <span className="text-[10px] font-mono font-bold text-indigo-300 block uppercase mb-1">Body Context font</span>
                        <p className="text-xs text-slate-300">{activeInsp.typographySystem.bodyFont}</p>
                      </div>
                      <div className="p-3 bg-white/5 rounded-xl">
                        <span className="text-[10px] font-mono font-bold text-indigo-300 block uppercase mb-1">Monospace and Numerical font</span>
                        <p className="text-xs font-mono text-slate-400">{activeInsp.typographySystem.monoFont}</p>
                      </div>
                    </div>
                  </div>

                  {/* High Quality UI Mockup Generator using Imagen */}
                  <div className="bg-[#121212] border border-white/5 p-6 rounded-2xl flex flex-col justify-between">
                    <div className="space-y-2">
                      <h3 className="text-sm font-semibold text-white uppercase tracking-wide flex items-center gap-2">
                        <Image className="w-4 h-4 text-indigo-400" />
                        {lang === "en" ? "Interactive Screenshot Painting" : "আর্টওয়ার্ক স্ক্রিনশট রেন্ডারার"}
                      </h3>
                      <p className="text-xs text-slate-400">
                        {lang === "en" 
                          ? "Run our high-fidelity Imagen proxy to paint a realistic pixel artwork from the visual prompt." 
                          : "উচ্চমানের ভিজ্যুয়াল ভেক্টর পেইন্টিং ইমেজ তৈরি করুন।"}
                      </p>
                    </div>

                    {paintedScreenshot ? (
                      <div className="mt-3 relative rounded-xl border border-white/10 overflow-hidden shadow-2xl">
                        <img 
                          src={paintedScreenshot} 
                          alt="Painted Concept UI Screenshot" 
                          referrerPolicy="no-referrer"
                          className="w-full h-auto aspect-video object-cover" 
                        />
                        <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent flex items-end p-3">
                          <span className="text-[10px] font-mono text-emerald-400 font-bold uppercase">🎨 Real-time Imagen Synthesis</span>
                        </div>
                      </div>
                    ) : (
                      <div className="mt-4 border border-dashed border-white/10 p-6 rounded-xl flex flex-col items-center justify-center text-center space-y-3 bg-[#18181b]/30">
                        <div className="p-2.5 bg-indigo-500/10 border border-indigo-500/20 rounded-full text-indigo-400 uppercase text-[10px] font-mono">
                          {lang === "en" ? "IMAGEN READY" : "ইমেজ পেইন্টার"}
                        </div>
                        <p className="text-[10px] font-mono text-slate-500 max-w-xs">{activeInsp.visualPrompts.uiArtwork}</p>
                        <button
                          onClick={paintConceptArtwork}
                          disabled={imageGenerating}
                          className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 disabled:bg-indigo-900/40 text-white rounded-lg text-xs font-semibold cursor-pointer transition-all flex items-center gap-1.5"
                        >
                          {imageGenerating ? (
                            <>
                              <RefreshCcw className="w-3 animate-spin" />
                              <span>{lang === "en" ? "Painting Screenshot..." : "আর্ট পেন্টিং হচ্ছে..."}</span>
                            </>
                          ) : (
                            <>
                              <AppWindow className="w-3.5 h-3.5" />
                              <span>{lang === "en" ? "Paint UI Artwork (20 Credits)" : "আর্টওয়ার্ক ইন্টিগ্রেশন (২০ ক্রেডিট)"}</span>
                            </>
                          )}
                        </button>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            ) : (
              <div className="p-12 border border-dashed border-white/10 rounded-2xl text-center space-y-2 text-slate-500 font-mono">
                <p>{lang === "en" ? "Architecting layout specs..." : "ডিজাইন স্পেস আর্কিটেকচার করা হচ্ছে..."}</p>
              </div>
            )}
          </div>
        </div>
      )}

      {activeTab === "gallery" && (
        <div className="space-y-5 text-left">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {allInspirations.map((insp) => (
              <div 
                key={insp.id}
                onClick={() => {
                  setSelectedInsp(insp);
                  setActiveTab("create");
                  setPaintedScreenshot(null);
                }}
                className="bg-[#121212] border border-white/5 p-5 rounded-2xl hover:border-indigo-500/30 transition-all cursor-pointer active:scale-98 relative overflow-hidden group"
              >
                <div 
                  className="absolute top-0 right-0 w-3 h-full opacity-60 transition-all group-hover:opacity-100" 
                  style={{ backgroundColor: insp.aestheticTokens.primaryAccent.split(" ")[0] }}
                />
                
                <span className="text-[9px] font-mono text-slate-500 uppercase block">Inspiration Library Idea</span>
                <h4 className="text-base font-display font-medium text-white tracking-tight mt-1 capitalize">{insp.niche}</h4>
                <p className="text-xs text-slate-400 mt-2 line-clamp-3">{insp.recommendedConcept}</p>
                
                <div className="mt-4 pt-3 border-t border-white/5 flex items-center justify-between text-[10px] font-mono text-slate-500">
                  <div className="flex items-center gap-1">
                    <span className="w-2 h-2 rounded-full inline-block" style={{ backgroundColor: insp.aestheticTokens.primaryAccent.split(" ")[0] }} />
                    <span className="w-2 h-2 rounded-full inline-block" style={{ backgroundColor: insp.aestheticTokens.secondaryAccent.split(" ")[0] }} />
                    <span className="w-2 h-2 rounded-full inline-block" style={{ backgroundColor: insp.aestheticTokens.surface.split(" ")[0] }} />
                  </div>
                  <span className="flex items-center gap-1 group-hover:text-indigo-400 transition-all">
                    {lang === "en" ? "View Specs" : "ডিজাইন দেখুন"} <Eye className="w-3 h-3" />
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
