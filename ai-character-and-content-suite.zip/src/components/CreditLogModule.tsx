/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from "react";
import { TRANSLATIONS, LanguageCode } from "../lib/translations";
import { GenerationHistoryItem } from "../types";
import { 
  Coins, History, PlusCircle, Layout, Sparkles, User, 
  Terminal, ShieldCheck, ArrowUpRight, BarChart2, Palette, Compass, Award
} from "lucide-react";

interface CreditLogModuleProps {
  lang: LanguageCode;
  username: string;
  credits: number;
  historyList: GenerationHistoryItem[];
  rechargeCredits: () => void;
}

export default function CreditLogModule({
  lang,
  username,
  credits,
  historyList,
  rechargeCredits
}: CreditLogModuleProps) {
  const t = TRANSLATIONS[lang];

  // Derive some helpful stats for the dashboard layout
  const totalGenerations = historyList.length;
  const totalCost = historyList.reduce((acc, h) => acc + h.creditsUsed, 0);

  const getIconForType = (type: string) => {
    switch (type) {
      case 'character':
        return <User className="w-4 h-4 text-purple-400" />;
      case 'thumbnail':
        return <Layout className="w-4 h-4 text-amber-400" />;
      case 'prompt':
        return <Terminal className="w-4 h-4 text-emerald-400" />;
      case 'color':
        return <Palette className="w-4 h-4 text-cyan-400" />;
      case 'inspiration':
        return <Compass className="w-4 h-4 text-indigo-400" />;
      case 'brand':
        return <Award className="w-4 h-4 text-emerald-450" />;
      default:
        return <Sparkles className="w-4 h-4 text-indigo-455" />;
    }
  };

  const getLabelForType = (type: string) => {
    if (lang === "en") {
      switch (type) {
        case 'character': return 'Character';
        case 'thumbnail': return 'Thumbnail Spec';
        case 'prompt': return 'Prompt Architect';
        case 'color': return 'Color Palette';
        case 'inspiration': return 'Inspiration';
        case 'brand': return 'Brand Strategy';
        default: return 'Studio Asset';
      }
    } else {
      switch (type) {
        case 'character': return 'ক্যারেক্টার';
        case 'thumbnail': return 'থাম্বনেইল লেআউট';
        case 'prompt': return 'প্রম্পট রেসিপি';
        case 'color': return 'রং প্যালেট';
        case 'inspiration': return 'ডিজাইন আইডিয়া';
        case 'brand': return 'ব্র্যান্ড স্ট্র্যাটেজি';
        default: return 'ডিজাইন অ্যাসেট';
      }
    }
  };

  return (
    <div className="space-y-6 text-left">
      {/* Bento Grid Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* Credit Balance Bento */}
        <div className="bg-slate-900 border border-slate-800 p-5 rounded-2xl flex flex-col justify-between relative overflow-hidden">
          <div className="absolute -top-10 -right-10 w-32 h-32 bg-indigo-505/10 rounded-full blur-2xl pointer-events-none" />
          
          <div className="flex justify-between items-start">
            <div className="space-y-1">
              <span className="text-[10px] uppercase font-bold text-slate-500 tracking-wider">
                {lang === "en" ? "Available Balance" : "বর্তমান ব্যালেন্স"}
              </span>
              <h1 className="text-3xl font-display font-bold text-indigo-400">
                🪙 {credits} <span className="text-xs text-slate-400 font-normal">Credits</span>
              </h1>
            </div>
            <div className="p-2.5 bg-indigo-950/50 border border-indigo-900/40 rounded-xl">
              <Coins className="w-5 h-5 text-indigo-400" />
            </div>
          </div>

          <button
            onClick={rechargeCredits}
            id="credit-btn-recharge"
            className="w-full bg-indigo-600 hover:bg-indigo-500 font-semibold text-xs py-2 rounded-xl text-slate-100 transition-all active:scale-95 flex items-center justify-center gap-1.5 mt-4 cursor-pointer"
          >
            <PlusCircle className="w-4 h-4" />
            <span>{t.rechargeBtn}</span>
          </button>
        </div>

        {/* Configurations Bento */}
        <div className="bg-slate-900 border border-slate-800 p-5 rounded-2xl flex flex-col justify-between">
          <div className="flex justify-between items-start">
            <div className="space-y-1">
              <span className="text-[10px] uppercase font-bold text-slate-500 tracking-wider">
                {lang === "en" ? "Total Creations Built" : "মোট ডিজাইন সংখ্যা"}
              </span>
              <h1 className="text-3xl font-display font-medium text-slate-100">
                {totalGenerations} <span className="text-xs text-slate-400 font-normal">assets</span>
              </h1>
            </div>
            <div className="p-2.5 bg-slate-950 border border-slate-850 rounded-xl">
              <BarChart2 className="w-5 h-5 text-emerald-400" />
            </div>
          </div>

          <div className="pt-2 text-[11px] text-slate-400 flex justify-between border-t border-slate-850 mt-4 leading-relaxed">
            <span>Session design index:</span>
            <span className="font-mono text-emerald-400 font-bold">100% active</span>
          </div>
        </div>

        {/* User profile details Bento */}
        <div className="bg-slate-900 border border-slate-800 p-5 rounded-2xl flex flex-col justify-between">
          <div className="flex justify-between items-start">
            <div className="space-y-1">
              <span className="text-[10px] uppercase font-bold text-slate-500 tracking-wider">
                {lang === "en" ? "Workspace License" : "লাইসেন্স স্ট্যাটাস"}
              </span>
              <h2 className="text-sm font-semibold text-slate-200 mt-1 uppercase flex items-center gap-1.5">
                <ShieldCheck className="w-4 h-4 text-blue-400 shrink-0" />
                <span>PRO SANDBOX TIER</span>
              </h2>
              <p className="text-[10px] text-slate-500">Node client authenticated locally as: {username}</p>
            </div>
          </div>

          <div className="pt-2 text-[11px] text-slate-400 flex justify-between border-t border-slate-850 mt-4 leading-relaxed">
            <span>Server Proxy Status:</span>
            <span className="font-mono text-purple-400 font-semibold shrink-0">GEMINI CLOUD LIVE</span>
          </div>
        </div>
      </div>

      {/* History Ledger List */}
      <div className="bg-slate-900/50 border border-slate-800 rounded-2xl p-6">
        <h3 className="text-xs uppercase font-bold text-slate-400 tracking-widest flex items-center gap-2 mb-4 border-b border-slate-850 pb-2.5">
          <History className="w-4 h-4 text-indigo-400" />
          <span>{t.recentCreations}</span>
        </h3>

        {historyList.length === 0 ? (
          <div className="text-center py-12 space-y-2">
            <Coins className="w-8 h-8 text-slate-650 mx-auto opacity-40" />
            <p className="text-xs text-slate-500">{t.noHistory}</p>
          </div>
        ) : (
          <div className="divide-y divide-slate-850">
            {historyList.map((item) => (
              <div 
                key={item.id} 
                className="py-3.5 flex flex-col md:flex-row justify-between items-start md:items-center gap-2 text-xs"
              >
                <div className="flex items-start gap-3 min-w-0">
                  <div className="p-2 bg-slate-950 border border-slate-800 rounded-lg shrink-0 mt-0.5">
                    {getIconForType(item.type)}
                  </div>
                  <div className="min-w-0">
                    <div className="flex items-center gap-2">
                      <span className="text-[9px] uppercase font-mono px-2 py-0.5 bg-slate-800 text-slate-400 rounded-full border border-slate-750">
                        {getLabelForType(item.type)}
                      </span>
                      <span className="text-[10px] text-slate-500 font-mono">
                        {new Date(item.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
                      </span>
                    </div>
                    <p className="text-xs font-semibold text-slate-300 gap-1.5 mt-1 truncate">
                      {item.title}
                    </p>
                    <p className="text-[11px] text-slate-500 truncate leading-relaxed">
                      {item.summary}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-1.5 shrink-0 self-end md:self-center font-mono text-xs text-rose-450 bg-rose-955/10 border border-rose-900/20 px-2.5 py-1 rounded-lg">
                  <span>- 🪙 {item.creditsUsed}</span>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
