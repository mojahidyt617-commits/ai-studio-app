/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import { TRANSLATIONS, LanguageCode } from "../lib/translations";
import { PromptSpec } from "../types";
import { 
  Sparkles, Copy, Check, Terminal, Sliders, HelpCircle, 
  Video, Eye, AlertTriangle, Hammer, Lightbulb
} from "lucide-react";

interface PromptModuleProps {
  lang: LanguageCode;
  credits: number;
  deductCredits: (qty: number, actionTitle: string) => boolean;
  onPromptGenerated: (prompt: PromptSpec) => void;
  recentPrompts: PromptSpec[];
}

export default function PromptModule({
  lang,
  credits,
  deductCredits,
  onPromptGenerated,
  recentPrompts
}: PromptModuleProps) {
  const t = TRANSLATIONS[lang];

  // Inputs
  const [coreIdea, setCoreIdea] = useState("");
  const [artMedium, setArtMedium] = useState("Vivid Digital Illustration");
  const [moodTone, setMoodTone] = useState("Moody Cinematic backlight with volumetric fog");

  // Loading/Notification states
  const [loading, setLoading] = useState(false);
  const [copiedKey, setCopiedKey] = useState<string | null>(null);
  const [errorMsg, setErrorMsg] = useState("");
  const [activeTab, setActiveTab] = useState<"create" | "history">("create");

  // Current viewer
  const [selectedPrompt, setSelectedPrompt] = useState<PromptSpec | null>(null);

  const handleGenerate = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg("");

    const cost = 5;
    if (credits < cost) {
      setErrorMsg(t.insufficientCredits);
      return;
    }

    setLoading(true);

    try {
      const resp = await fetch("/api/prompt/generate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          coreIdea: coreIdea.trim(),
          selectedMedium: artMedium,
          toneAspect: moodTone
        }),
      });

      if (!resp.ok) {
        throw new Error("Prompt builder timed out");
      }

      const rawSpec: PromptSpec = await resp.json();

      // Deduct Credits
      const deducted = deductCredits(cost, `Prompt Architect: ${rawSpec.subject.substring(0, 20)}...`);
      if (!deducted) {
        setErrorMsg(t.insufficientCredits);
        setLoading(false);
        return;
      }

      onPromptGenerated(rawSpec);
      setSelectedPrompt(rawSpec);
      setActiveTab("history");

      // Reset idea
      setCoreIdea("");
    } catch (err) {
      console.error(err);
      setErrorMsg("Failed to communicate with prompt architect. Please retry.");
    } finally {
      setLoading(false);
    }
  };

  const executeCopy = (text: string, refKey: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKey(refKey);
    setTimeout(() => {
      setCopiedKey(null);
    }, 1500);
  };

  return (
    <div className="space-y-6">
      {/* Sub tabs */}
      <div className="flex border-b border-white/5">
        <button
          onClick={() => setActiveTab("create")}
          id="tab-prompt-create"
          className={`px-5 py-3 text-xs font-semibold uppercase tracking-wider cursor-pointer transition-all ${
            activeTab === "create"
              ? "text-blue-400 border-b-2 border-blue-500"
              : "text-gray-400 hover:text-white"
          }`}
        >
          {lang === "en" ? "🛠️ Architect Prompt" : "🛠️ প্রম্পট ইঞ্জিনিয়ারিং"}
        </button>
        <button
          onClick={() => {
            if (recentPrompts.length > 0 && !selectedPrompt) {
              setSelectedPrompt(recentPrompts[0]);
            }
            setActiveTab("history");
          }}
          id="tab-prompt-inspect"
          className={`px-5 py-3 text-xs font-semibold uppercase tracking-wider cursor-pointer transition-all ${
            activeTab === "history"
              ? "text-blue-400 border-b-2 border-blue-500"
              : "text-gray-400 hover:text-white"
          }`}
        >
          {lang === "en" ? `📋 Prompt Recipes (${recentPrompts.length})` : `📋 রেসিপি লাইব্রেরি (${recentPrompts.length})`}
        </button>
      </div>

      {loading && (
        <div className="bg-blue-900/5 border border-blue-500/20 p-12 rounded-2xl flex flex-col items-center justify-center space-y-4 animate-pulse">
          <div className="w-12 h-12 border-4 border-blue-500 border-t-transparent rounded-full animate-spin"></div>
          <div className="text-center">
            <h4 className="text-sm font-semibold text-blue-300">{t.promptGenerating}</h4>
            <p className="text-xs text-gray-400 mt-1">Expanding core descriptors using multi-tier prompt keywords weighting rules...</p>
          </div>
        </div>
      )}

      {!loading && activeTab === "create" && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 text-left">
          <div className="lg:col-span-7 bg-[#121212] border border-white/5 p-6 rounded-2xl space-y-5 font-sans">
            <div>
              <h3 className="text-base font-display font-medium text-white flex items-center gap-2">
                <Sliders className="w-4 h-4 text-blue-400" />
                {t.promptTitle}
              </h3>
              <p className="text-xs text-slate-400 mt-1 text-left">
                {t.promptSubtitle}
              </p>
            </div>

            {errorMsg && (
              <div id="prompt-error-alert" className="p-3.5 bg-rose-955/40 border border-rose-900/50 text-rose-300 rounded-xl flex items-start gap-2 text-xs">
                <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5" />
                <span>{errorMsg}</span>
              </div>
            )}

            <form onSubmit={handleGenerate} className="space-y-4 text-left">
              <div>
                <label className="block text-xs font-semibold uppercase tracking-wider text-slate-400 mb-1.5">{t.promptIdea}</label>
                <input
                  type="text"
                  required
                  value={coreIdea}
                  id="prompt-input-idea"
                  onChange={(e) => setCoreIdea(e.target.value)}
                  placeholder={t.promptIdeaPlaceholder}
                  className="w-full bg-[#0A0A0A] border border-white/5 focus:border-blue-500 rounded-xl py-2.5 px-3 text-xs text-white placeholder-slate-600 outline-none"
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold uppercase tracking-wider text-slate-400 mb-1.5">{t.promptMedium}</label>
                  <select
                    value={artMedium}
                    id="prompt-input-medium"
                    onChange={(e) => setArtMedium(e.target.value)}
                    className="w-full bg-[#0A0A0A] border border-white/5 focus:border-blue-500 rounded-xl py-2.5 px-3 text-xs text-white outline-none"
                  >
                    <option value="Photorealistic Cinematic Concept">Photorealistic Cinematic Concept</option>
                    <option value="Epic Fantasy Matte Painting">Epic Fantasy Matte Painting</option>
                    <option value="Unreal Engine 5 Octane 3D Render">Unreal Engine 5 Octane 3D Render</option>
                    <option value="Futuristic Cyber Noir Digital Painting">Futuristic Cyber Noir Digital Painting</option>
                    <option value="Clean Vector Graphic Outline">Clean Vector Graphic Outline</option>
                    <option value="Neo-Japanese Anime Illustration">Neo-Japanese Anime Illustration</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold uppercase tracking-wider text-slate-400 mb-1.5">{t.promptTone}</label>
                  <select
                    value={moodTone}
                    id="prompt-input-tone"
                    onChange={(e) => setMoodTone(e.target.value)}
                    className="w-full bg-[#0A0A0A] border border-white/5 focus:border-blue-500 rounded-xl py-2.5 px-3 text-xs text-white outline-none"
                  >
                    <option value="Golden hour atmospheric rays">Golden hour soft ambient glow</option>
                    <option value="Moody cinematic underbelly cyberpunk neon lighting">Neon backlit cyberpunk moody glow</option>
                    <option value="Cold surgical studio lighting, rimlight highlighting">High contrast studio rimlighting</option>
                    <option value="Ethereal cosmic light with deep void contrast">Ethereal celestial light with voids</option>
                    <option value="Pastel playful lighting with bright highlights">Soft pastel colorful highlights</option>
                  </select>
                </div>
              </div>

              <button
                type="submit"
                id="prompt-btn-generate"
                className="w-full bg-blue-600 hover:bg-blue-500 active:scale-95 transition-all py-3 rounded-xl text-xs font-semibold text-white font-display flex items-center justify-center gap-2 cursor-pointer shadow-lg shadow-blue-500/10"
              >
                <Sparkles className="w-3.5 h-3.5" />
                <span>{t.generatePromptBtn}</span>
              </button>
            </form>
          </div>

          <div className="lg:col-span-5 bg-[#151515] border border-white/5 p-6 rounded-2xl flex flex-col justify-between text-left space-y-4">
            <div className="space-y-3">
              <h4 className="text-xs font-bold uppercase text-slate-400 tracking-wider">
                {lang === "en" ? "Prompt Physics" : "প্রম্পট তৈরির পেছনের বিজ্ঞান"}
              </h4>
              <p className="text-xs text-slate-300 leading-relaxed">
                {lang === "en"
                  ? "Raw input results in repetitive flat generations. The architect applies deep structure modifiers (camera choice, lens values, specific color grading, lighting dynamics, volumetric fog effects) which forces text-to-image AI generators to activate up to 500% higher detail vectors."
                  : "সাধারণ এক লাইনের টেক্সট দিলেই অনেক সময় ফ্ল্যাট বা সাদামাটা ছবি তৈরি হয়। আমাদের এই আর্কিটেক্ট ক্যামেরা লেন্স, কালার গ্রেডিংস এবং থ্রিডি ডেসক্রিপ্টর যোগ করে ছবির আউটপুট ৫০০% আকর্ষণীয় করে তোলে।"}
              </p>
            </div>

            <div className="pt-6 border-t border-white/5 flex items-center gap-3">
              <div className="p-2 bg-blue-600/10 rounded-lg text-blue-400 font-mono text-xs border border-blue-500/25">
                🪙 5¢
              </div>
              <div className="text-left">
                <p className="text-xs font-semibold text-slate-300">
                  {lang === "en" ? "Deducted upon architecting" : "প্রম্পট রেসিпи তৈরি হলে ৫ ক্রেডিট কাটা হবে"}
                </p>
                <p className="text-[10px] text-gray-500">
                  {lang === "en" ? "Super lightweight and fast." : "অত্যন্ত দ্রুত এবং নির্ভরযোগ্য প্রসেস।"}
                </p>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* History Specs Preview */}
      {!loading && activeTab === "history" && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Recent list library */}
          <div className="lg:col-span-4 bg-slate-900/40 border border-slate-855 p-4 rounded-2xl space-y-3 max-h-[500px] overflow-y-auto">
            <h4 className="text-xs font-bold text-slate-400 uppercase tracking-widest px-2 mb-2">
              {lang === "en" ? "Prompts Database" : "প্রম্পট লাইব্রেরি"}
            </h4>
            {recentPrompts.length === 0 ? (
              <p className="text-xs text-slate-500 text-center py-6">{t.noHistory}</p>
            ) : (
              recentPrompts.map((p) => (
                <button
                  key={p.id}
                  onClick={() => setSelectedPrompt(p)}
                  className={`w-full text-left p-3 rounded-xl border transition-all flex items-center justify-between cursor-pointer ${
                    selectedPrompt?.id === p.id
                      ? "bg-slate-900 border-indigo-650"
                      : "bg-slate-950/40 border-slate-850 hover:bg-slate-900/60"
                  }`}
                >
                  <div className="truncate text-left min-w-0 pr-2">
                    <h4 className="text-xs font-bold text-slate-200 truncate">{p.subject}</h4>
                    <span className="text-[9px] font-mono text-indigo-405 text-slate-500 truncate uppercase mt-0.5 block">{p.medium}</span>
                  </div>
                </button>
              ))
            )}
          </div>

          {/* Prompt Recipe Sheets */}
          <div className="lg:col-span-8">
            {selectedPrompt ? (
              <div className="space-y-6">
                <div className="bg-slate-905 border border-slate-800 rounded-2xl p-6 text-left space-y-6">
                  {/* Title Header */}
                  <div>
                    <span className="text-[9px] font-mono bg-indigo-950/40 text-indigo-400 px-3 py-1 rounded border border-indigo-500/10 uppercase">
                      {selectedPrompt.medium}
                    </span>
                    <h3 className="text-base font-bold text-slate-100 mt-2.5">
                      {lang === "en" ? "Optimized Concept: " : "অপ্টিমাইজড কনসেপ্ট: "}
                      &ldquo;{selectedPrompt.subject}&rdquo;
                    </h3>
                  </div>

                  {/* Multi platform outputs */}
                  <div className="space-y-5">
                    {/* Midjourney block */}
                    <div className="space-y-2">
                      <div className="flex justify-between items-center">
                        <span className="text-xs font-bold text-indigo-400 font-mono tracking-wide flex items-center gap-1.5">
                          <Terminal className="w-3.5 h-3.5" />
                          <span>MIDJOURNEY V6 RECIPE</span>
                        </span>
                        
                        <button
                          onClick={() => executeCopy(selectedPrompt.fullMidjourneyPrompt, "mj")}
                          id="prompt-btn-copy-mj"
                          className="px-3 py-1 bg-slate-900 hover:bg-slate-800 text-[10px] text-slate-300 border border-slate-800 rounded-lg flex items-center gap-1.5 cursor-pointer hover:text-indigo-400"
                        >
                          {copiedKey === "mj" ? (
                            <>
                              <Check className="w-3 h-3 text-emerald-400" />
                              <span>{t.copied}</span>
                            </>
                          ) : (
                            <>
                              <Copy className="w-3 h-3" />
                              <span>{lang === "en" ? "Copy Prompt" : "কপি করুন"}</span>
                            </>
                          )}
                        </button>
                      </div>

                      <div className="bg-slate-950 p-4 border border-slate-850 rounded-xl text-xs font-mono text-slate-300 break-words select-all leading-normal">
                        {selectedPrompt.fullMidjourneyPrompt}
                      </div>
                    </div>

                    {/* Stable Diffusion block */}
                    <div className="space-y-2">
                      <div className="flex justify-between items-center">
                        <span className="text-xs font-bold text-teal-400 font-mono tracking-wide flex items-center gap-1.5">
                          <Terminal className="w-3.5 h-3.5" />
                          <span>STABLE DIFFUSION (SDXL) RECIPE</span>
                        </span>

                        <button
                          onClick={() => executeCopy(selectedPrompt.fullStableDiffusionPrompt, "sd")}
                          id="prompt-btn-copy-sd"
                          className="px-3 py-1 bg-slate-900 hover:bg-slate-800 text-[10px] text-slate-300 border border-slate-800 rounded-lg flex items-center gap-1.5 cursor-pointer hover:text-teal-400"
                        >
                          {copiedKey === "sd" ? (
                            <>
                              <Check className="w-3 h-3 text-emerald-400" />
                              <span>{t.copied}</span>
                            </>
                          ) : (
                            <>
                              <Copy className="w-3 h-3" />
                              <span>{lang === "en" ? "Copy Prompt" : "কপি করুন"}</span>
                            </>
                          )}
                        </button>
                      </div>

                      <div className="bg-slate-950 p-4 border border-slate-850 rounded-xl text-xs font-mono text-slate-300 break-words select-all leading-normal">
                        {selectedPrompt.fullStableDiffusionPrompt}
                      </div>

                      {/* Negative constraints */}
                      <div className="pt-1.5 text-[11px] text-rose-350 bg-rose-950/10 border border-rose-900/30 p-2.5 rounded-lg">
                        <strong>Negative Weights:</strong> {selectedPrompt.negativePrompt}
                      </div>
                    </div>
                  </div>

                  {/* Micro breakdown grids */}
                  <div className="border-t border-slate-850 pt-5 space-y-4">
                    <h4 className="text-xs uppercase font-bold text-slate-400 tracking-wider flex items-center gap-2">
                      <Lightbulb className="w-4 h-4 text-indigo-400" />
                      <span>{lang === "en" ? "Prompt DNA Breakdown" : "সুইচ এবং ডিএনএ স্ট্রাকচার"}</span>
                    </h4>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
                      <div className="space-y-1">
                        <span className="text-slate-500 font-mono">LIGHTING:</span>
                        <p className="text-slate-300 leading-relaxed bg-slate-950/45 p-2 rounded border border-slate-850">{selectedPrompt.lighting}</p>
                      </div>
                      <div className="space-y-1">
                        <span className="text-slate-500 font-mono">OPTICS / CAMERA:</span>
                        <p className="text-slate-300 leading-relaxed bg-slate-950/45 p-2 rounded border border-slate-850">{selectedPrompt.cameraSettings}</p>
                      </div>
                      <div className="space-y-1">
                        <span className="text-slate-500 font-mono">COLOR GRADING:</span>
                        <p className="text-slate-300 leading-relaxed bg-slate-950/45 p-2 rounded border border-slate-850">{selectedPrompt.colorGrade}</p>
                      </div>
                      <div className="space-y-1">
                        <span className="text-slate-500 font-mono">MODIFIER TAGS:</span>
                        <div className="flex flex-wrap gap-1 mt-1">
                          {selectedPrompt.additionalModifiers.map((mod, i) => (
                            <span key={i} className="text-[10px] bg-indigo-950/40 text-indigo-300 border border-indigo-900/40 px-2 py-0.5 rounded">
                              {mod}
                            </span>
                          ))}
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            ) : (
              <div className="bg-slate-900/20 border border-slate-800/40 p-16 rounded-2xl text-center space-y-3">
                <Terminal className="w-10 h-10 text-slate-600 mx-auto" />
                <h4 className="text-xs uppercase font-bold text-slate-400 tracking-wide">
                  {lang === "en" ? "No recipes loaded" : "কোনোও প্রম্পট লোড করা নেই"}
                </h4>
                <p className="text-xs text-slate-500 max-w-sm mx-auto">
                  {lang === "en" ? "Structure high detail prompts by inserting core ideas inside the 'Architect' panel." : "আর্কিটেক্ট প্যানেলে আপনার আইডিয়া সাবমিট করে সুবিন্যস্ত প্রম্পট রেসিপি তৈরি করুন।"}
                </p>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
