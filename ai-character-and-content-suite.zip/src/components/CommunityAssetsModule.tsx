import React, { useState, useEffect } from "react";
import { LanguageCode } from "../lib/translations";
import { 
  Sparkles, Award, Users, ShoppingCart, Compass, Code, 
  Copy, Timer, Play, Pause, ChevronRight, Vote, MessageSquare,
  Flame, Calendar, List, Layers, ShieldCheck, Heart
} from "lucide-react";

interface CommunityAssetsProps {
  lang: LanguageCode;
  credits: number;
  deductCredits: (qty: number, actionTitle: string) => boolean;
}

export default function CommunityAssetsModule({
  lang,
  credits,
  deductCredits,
}: CommunityAssetsProps) {
  const isEn = lang === "en";

  // Sub Navigation Tabs
  const [activeTab, setActiveTab] = useState<"challenge" | "battle" | "showcase" | "assets" | "trend">("challenge");

  // State Management
  const [loading, setLoading] = useState(false);
  const [errMessage, setErrMessage] = useState("");
  const [copiedKey, setCopiedKey] = useState<string | null>(null);

  const triggerCopy = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKey(id);
    setTimeout(() => setCopiedKey(null), 1500);
  };

  /* ==========================================
     1. DAILY DESIGN CHALLENGE & FOCUS TIMER STATE
     ========================================== */
  const [streakDays, setStreakDays] = useState(() => {
    try {
      const saved = localStorage.getItem("ai_challenge_streak");
      return saved ? parseInt(saved, 10) : 4;
    } catch {}
    return 4;
  });

  // Focus Timer States
  const [timerLeft, setTimerLeft] = useState(1500); // 25 Minutes
  const [timerActive, setTimerActive] = useState(false);

  useEffect(() => {
    let interval: any = null;
    if (timerActive && timerLeft > 0) {
      interval = setInterval(() => {
        setTimerLeft((p) => p - 1);
      }, 1000);
    } else if (timerLeft === 0) {
      setTimerActive(false);
    }
    return () => clearInterval(interval);
  }, [timerActive, timerLeft]);

  const toggleTimer = () => setTimerActive(!timerActive);
  const resetTimer = () => {
    setTimerActive(false);
    setTimerLeft(1500);
  };

  const formatTime = (sec: number) => {
    const mins = Math.floor(sec / 60);
    const secs = sec % 60;
    return `${mins.toString().padStart(2, "0")}:${secs.toString().padStart(2, "0")}`;
  };

  const [currentChallenge, setCurrentChallenge] = useState(() => {
    return {
      title: "The Zero-Waste Tea Packaging Layout",
      criteria: "Design a symmetrical cylindrical tea container layout using natural botanic green tints paired with modern Inter geometric layouts. Must use organic silhouettes.",
      difficulty: "Intermediate",
      timeReward: "+15 Streak Points"
    };
  });

  const handleGenerateChallenge = async () => {
    setErrMessage("");
    const cost = 5;
    if (credits < cost) {
      setErrMessage(isEn ? "No credits!" : "পর্যাপ্ত ক্রেডিট নেই!");
      return;
    }
    setLoading(true);

    const systemInstruction = 
      "You are a master design challenge coordinator. Return EXACTLY a single JSON object with creative ideas and guidelines: { title, criteria, difficulty, timeReward }";

    try {
      const resp = await fetch("/api/studio/general-generate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          prompt: "Generate a completely fresh unique daily prompt graphic layout challenge for designers.",
          systemInstruction,
          fallbackJson: {
            title: "Futuristic Crypto Wallet Screen",
            criteria: "Create high-contrast neon grid layouts with glassmorphic dashboards outlining secure token balances.",
            difficulty: "High",
            timeReward: "+25 Streak Points"
          }
        })
      });

      const resData = await resp.json();
      if (resData.success && resData.data) {
        setCurrentChallenge(resData.data);
        setStreakDays((p) => {
          const next = p + 1;
          localStorage.setItem("ai_challenge_streak", next.toString());
          return next;
        });
        deductCredits(cost, `Challenge Loaded: ${resData.data.title}`);
      }
    } catch {
      setErrMessage("Error downloading challenge.");
    } finally {
      setLoading(false);
    }
  };

  /* ==========================================
     2. DESIGN BATTLE / SHOWDOWNS STATE
     ========================================== */
  const [battleA_votes, setBattleA_votes] = useState(144);
  const [battleB_votes, setBattleB_votes] = useState(129);
  const [votedSide, setVotedSide] = useState<string | null>(null);

  const castCommunityVote = (side: "A" | "B") => {
    if (votedSide) return;
    setVotedSide(side);
    if (side === "A") setBattleA_votes((p) => p + 1);
    else setBattleB_votes((p) => p + 1);
  };

  /* ==========================================
     3. PORTFOLIOS & COMMUNITY REVIEWS FEED STATS
     ========================================== */
  const [feedItems, setFeedItems] = useState([
    { id: "feed_1", author: "Farhan Alam", title: "Retro Fintech Dark Deck", likes: 42, feedbacksCount: 7, tags: ["UI/UX", "Crypto"], authorAvatar: "av_1" },
    { id: "feed_2", author: "Nafisa Anjum", title: "Organic Botanical Tea Cover", likes: 88, feedbacksCount: 12, tags: ["Packaging", "Organic"], authorAvatar: "av_2" },
    { id: "feed_3", author: "Kazi Mahtab", title: "Aero Flying Car Banner Layout", likes: 65, feedbacksCount: 4, tags: ["Futurism", "SaaS"], authorAvatar: "av_3" }
  ]);

  const handleLikeItem = (id: string) => {
    setFeedItems(prev => prev.map(item => {
      if (item.id === id) return { ...item, likes: item.likes + 1 };
      return item;
    }));
  };

  /* ==========================================
     4. ASSETS CENTER / MARKETPLACE STATE
     ========================================== */
  const [marketTab, setMarketTab] = useState<"mockups" | "icons" | "gradients" | "patterns">("gradients");

  const mockupGalleries = [
    { title: "Matte Glass iPhone 17 Screen", size: "PSD (45MB)", category: "Mobile" },
    { title: "Standard Ceramic Studio Mug Backdrop", size: "Figma Layer", category: "Packaging" },
    { title: "Floating Poster Hanging Minimal System", size: "PSD + Vector template", category: "Print" }
  ];

  const iconPacks = [
    { title: "Space-Tech Vector outlines (120 icons)", tags: "SVG Minimalist and wireframe", creator: "AI Studio Pack" },
    { title: "Luxury Gold Business Icons (84 elements)", tags: "Golden stroke vectors", creator: "Creative Team" }
  ];

  const codeGradients = [
    { name: "Saturated Emerald Star", css: "background: linear-gradient(135deg, #064e3b 0%, #10b981 100%);" },
    { name: "Cosmic Lavender Shine", css: "background: linear-gradient(135deg, #1e1b4b 0%, #a855f7 50%, #ec4899 100%);" },
    { name: "Gilded Amber Dusk", css: "background: linear-gradient(135deg, #1a0c00 0%, #d97706 100%);" }
  ];

  /* ==========================================
     5. AI DESIGN TREND PREDICTOR STATE
     ========================================== */
  const [selectedMonth, setSelectedMonth] = useState("June/July 2026");
  const [trendResult, setTrendResult] = useState<{
    dominantVibe: string;
    winningColors: string[];
    layoutStrategy: string;
    bannedPracticesTips: string;
  } | null>(() => {
    return {
      dominantVibe: "Organic Cyber-Tactility (Liquid Metal meets Bio-Silhouettes)",
      winningColors: [
        "Toxic Matte Mint (#10b981)",
        "Deep Volcanic Obsidian (#0c0a09)",
        "Soft Alabaster Mist (#f4f4f5)"
      ],
      layoutStrategy: "Displaced asymmetrical block layouts framed by ultra-fine borders (0.5px) and absolute glass container layers.",
      bannedPracticesTips: "Banish high-contrast fluorescent rainbows or heavy artificial gradients. Prefer deep matte backgrounds accompanied by a single explosive neon light point."
    };
  });

  const handlePredictTrends = async () => {
    setErrMessage("");
    const cost = 10;
    if (credits < cost) {
      setErrMessage(isEn ? "No credits!" : "পর্যাপ্ত ক্রেডিট নেই!");
      return;
    }
    setLoading(true);

    const systemInstruction = 
      "You are a master design forecasting agent. Analyze modern internet communities and return EXACTLY a single JSON object with future trends: { dominantVibe, winningColors: [string, string], layoutStrategy, bannedPracticesTips }";

    try {
      const resp = await fetch("/api/studio/general-generate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          prompt: `Predict visual and interface design trends for: "${selectedMonth}"`,
          systemInstruction,
          fallbackJson: {
            dominantVibe: "Vanguard Editorial Brutalism (Heavy Serif + Raw Mono Grid)",
            winningColors: ["Deep Cherry Red (#991b1b)", "Soft Cream Alabaster (#fdfbf7)"],
            layoutStrategy: "Flat absolute borders with highly condensed vertical headings.",
            bannedPracticesTips: "Banish standard simple rounded cards. Try using sharp corners!"
          }
        })
      });

      const resData = await resp.json();
      if (resData.success && resData.data) {
        setTrendResult(resData.data);
        deductCredits(cost, `Month Trend Predicted: ${selectedMonth}`);
      }
    } catch {
      setErrMessage("Error with trend calculator.");
    } finally {
      setLoading(false);
    }
  };


  return (
    <div className="bg-[#111115] border border-white/5 rounded-3xl p-4 sm:p-8 space-y-8 text-white relative">
      <div className="absolute top-0 right-0 w-64 h-64 bg-indigo-500/5 blur-[90px] pointer-events-none rounded-full" />

      {/* Header Grid */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 border-b border-white/5 pb-6">
        <div>
          <h2 className="text-xl sm:text-2xl font-display font-medium text-white flex items-center gap-2">
            <Users className="w-6 h-6 text-indigo-400" />
            <span>{isEn ? "Community Arena & Asset Center" : "কমিউনিটি এরেনা ও অ্যাসেট সেন্টার"}</span>
            <span className="text-[10px] bg-indigo-500/20 text-indigo-400 border border-indigo-500/30 px-2 py-0.5 rounded-full uppercase font-mono">
              Live Network
            </span>
          </h2>
          <p className="text-xs text-gray-400 mt-1">
            {isEn ? "Participate in visual battles, unlock daily layout challenges, download templates, and forecast trends." : "প্রতিদিনের ডিজাইন চ্যালেঞ্জ, লাইভ ডিজাইন ব্যাটল এবং ফ্রি প্রিমিয়াম অ্যাসেটস লাইব্রেরি।"}
          </p>
        </div>

        {/* Tab Selection */}
        <div className="flex flex-wrap gap-1.5 p-1 bg-white/5 border border-white/5 rounded-2xl">
          {[
            { id: "challenge", label: isEn ? "Daily Challenge" : "ডেইলি চ্যালেন্জ", icon: Calendar },
            { id: "battle", label: isEn ? "Design Battles" : "ডিজাইন যুদ্ধ", icon: Vote },
            { id: "showcase", label: isEn ? "Showcase & Peer Review" : "শোকেস", icon: Heart },
            { id: "assets", label: isEn ? "Marketplace & Code" : "অ্যাসেট গ্যালারী", icon: ShoppingCart },
            { id: "trend", label: isEn ? "AI Trend Predictor" : "ট্রেন্ড পরিমাপক", icon: Compass },
          ].map((item) => {
            const Icon = item.icon;
            return (
              <button
                key={item.id}
                onClick={() => {
                  setActiveTab(item.id as any);
                  setErrMessage("");
                }}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold cursor-pointer transition-all ${
                  activeTab === item.id
                    ? "bg-indigo-600 text-white shadow-md shadow-indigo-950/40"
                    : "text-gray-400 hover:text-white hover:bg-white/5"
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                <span>{item.label}</span>
              </button>
            );
          })}
        </div>
      </div>

      {errMessage && (
        <div className="p-4 bg-red-900/10 border border-red-500/20 rounded-2xl text-xs text-red-100">
          {errMessage}
        </div>
      )}

      {/* CORE SPLIT AREA */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* LEFT COLUMN PANEL INPUT */}
        <div className="lg:col-span-5 space-y-6 bg-white/5 border border-white/5 p-6 rounded-2xl">
          
          {/* TAB 1: DAILY CHALLENGE CONTROL */}
          {activeTab === "challenge" && (
            <div className="space-y-4">
              <div className="flex justify-between items-center bg-indigo-950/10 border border-indigo-500/20 p-4 rounded-xl">
                <div className="flex items-center gap-2">
                  <Flame className="w-5 h-5 text-amber-500 animate-pulse" />
                  <div>
                    <span className="text-[10px] text-gray-400 uppercase tracking-wide block">Active Hot Streak</span>
                    <span className="text-sm font-black text-white font-mono">{streakDays} Days Consistently!</span>
                  </div>
                </div>
                <div className="text-[11px] font-mono text-indigo-400 font-bold uppercase">
                  RANK: ADVANCED
                </div>
              </div>

              {/* Pomodoro Focus Timer UI */}
              <div className="bg-black/40 border border-white/10 p-5 rounded-2xl text-center space-y-3 relative overflow-hidden">
                <span className="absolute top-2 right-2 text-[8px] font-mono text-gray-500 uppercase">Interactive Focus Timer</span>
                <span className="text-[10px] text-gray-400 font-semibold block uppercase tracking-wide">Designer Focus Engine</span>
                <h5 className="text-3xl font-black font-mono text-white tracking-widest">{formatTime(timerLeft)}</h5>
                
                <div className="flex gap-2 justify-center">
                  <button 
                    onClick={toggleTimer}
                    className="px-4 py-1.5 bg-indigo-600/20 hover:bg-indigo-600/45 text-indigo-300 rounded-lg text-xs font-semibold cursor-pointer transition-all flex items-center gap-1"
                  >
                    {timerActive ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
                    <span>{timerActive ? "Pause" : "Start Focus"}</span>
                  </button>
                  <button 
                    onClick={resetTimer}
                    className="px-3 py-1.5 bg-black hover:bg-white/5 text-gray-400 rounded-lg text-[10px] cursor-pointer transition-all"
                  >
                    Reset
                  </button>
                </div>
              </div>

              <p className="text-xs text-gray-400 leading-normal">
                {isEn ? "Challenge yourself to master new structural geometry constraints every single day. Triggers a streak point upon load!" : "আপনার টাইপোগ্রাফি ও প্লেসমেন্ট দক্ষতা আরও শাণিত করার প্রফেশনাল ডেইলি স্পেসিফিকেশন।"}
              </p>

              <button
                onClick={handleGenerateChallenge}
                disabled={loading}
                className="w-full bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 text-white font-semibold py-3 px-4 rounded-xl text-xs flex items-center justify-center gap-2 cursor-pointer transition-all shadow-md shadow-indigo-950/40"
              >
                <Sparkles className="w-3.5 h-3.5" />
                <span>{loading ? "Re-drafting Criteria..." : (isEn ? "Generate New Challenge (5 Credits)" : "নতুন ডিজাইন ম্যান্ডেট দিন (৫ ক্রেডিট)")}</span>
              </button>
            </div>
          )}

          {/* TAB 2: DESIGN BATTLES VOTE CONTROL */}
          {activeTab === "battle" && (
            <div className="space-y-4">
              <h3 className="text-sm font-semibold tracking-wider text-gray-300 uppercase">
                ⚔️ LIVE Community Battle #341
              </h3>
              <p className="text-xs text-gray-400 leading-relaxed">
                {isEn ? "Vote on side-by-side design drafts generated by the community. See immediately which visual style holds greater market attention!" : "পাশাপাশি দুটি আর্টওয়ার্কের ডিজাইন বিন্যাস বিশ্লেষণ করে আপনার মূল্যবান ভোট দিন।"}
              </p>

              <div className="bg-[#121215] border border-white/5 p-4 rounded-xl space-y-2">
                <span className="text-[10px] text-indigo-400 font-mono uppercase block">Active Showdown Category:</span>
                <h4 className="text-xs font-bold text-white uppercase">"Cyberpunk Neon Landing Page Hero Banner vs Clean Luxury Nordic Minimal Banner"</h4>
                <div className="text-[10px] text-gray-500 font-mono">Closing Time: 3 hours remaining</div>
              </div>

              <div className="border border-white/5 bg-black/40 p-4 rounded-xl text-center text-xs">
                {votedSide ? (
                  <span className="text-indigo-400 font-bold">🎉 Thanks for your vote! Your active streak level is logged.</span>
                ) : (
                  <span className="text-gray-400">Click vote on the preview block beside to analyze results.</span>
                )}
              </div>
            </div>
          )}

          {/* TAB 3: SHOWCASE INPUTS */}
          {activeTab === "showcase" && (
            <div className="space-y-4">
              <h3 className="text-sm font-semibold text-gray-300 uppercase">
                📢 Ask for Layout Peer Reviews
              </h3>
              <p className="text-xs text-gray-400">
                {isEn ? "Submit your currently formatted prompt, text structures, or thumbnail layout blueprints for active community rating." : "আপনার প্রস্তুতকৃত লেআউটে বড় কোনো ত্রুটি ট্র্যাকিং করার জন্য কমিউনিটি ফিডব্যাক নেটওয়ার্কে যুক্ত করুন।"}
              </p>

              <div className="space-y-1.5">
                <input
                  type="text"
                  placeholder="e.g., Submit 'Organic Skincare Cover' for grading"
                  className="w-full bg-black/40 border border-white/15 rounded-xl p-3 text-xs text-white focus:outline-none"
                  disabled
                />
                <span className="text-[9px] text-gray-500 font-mono block">Premium users submit directly from historical blueprints.</span>
              </div>

              <button
                disabled
                className="w-full bg-white/5 text-gray-500 font-semibold py-3 px-4 rounded-xl text-xs selection:bg-transparent"
              >
                Publish Draft Vector to Feed
              </button>
            </div>
          )}

          {/* TAB 4: MARKETPLACE ASSET SELECTION */}
          {activeTab === "assets" && (
            <div className="space-y-4">
              <h3 className="text-sm font-semibold tracking-wider text-gray-300 uppercase flex items-center gap-1.5">
                <ShoppingCart className="w-4 h-4 text-indigo-400" />
                <span>Premium Asset Center</span>
              </h3>
              <p className="text-xs text-gray-400">
                {isEn ? "Download pre-formatted grid mockups, vector icons, or retrieve copyable CSS styling gradients." : "আপনার প্রজেক্টের সৌন্দর্য কয়েকগুণ বাড়িয়ে নিতে তৈরি করা কোড বা টেমপ্লেট নিয়ে নিন।"}
              </p>

              <div className="grid grid-cols-2 gap-1.5 p-1 bg-black/40 border border-white/10 rounded-xl">
                {["gradients", "mockups", "icons"].map((t) => (
                  <button
                    key={t}
                    onClick={() => setMarketTab(t as any)}
                    className={`py-1.5 text-[10px] font-bold rounded-lg uppercase cursor-pointer transition-all ${
                      marketTab === t ? "bg-indigo-600 text-white" : "text-gray-400 hover:text-white"
                    }`}
                  >
                    {t}
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* TAB 5: AI DESIGN TREND PREDICTOR INPUTS */}
          {activeTab === "trend" && (
            <div className="space-y-4">
              <h3 className="text-sm font-semibold tracking-wider text-gray-300 uppercase flex items-center gap-1.5">
                <Compass className="w-4 h-4 text-indigo-400" />
                <span>Forecasting Engine</span>
              </h3>
              <p className="text-xs text-gray-400">
                {isEn ? "Let AI analyze tech blogs, global design trends, and market metrics to predict next month's aesthetic guidelines." : "টেক ও কর্পোরেট পোর্টালের ডিজাইনে আগামী মাসে কি ধরণের কালার ও লেআউটের আধিক্য থাকবে তার ভবিষ্যৎবাণী।"
                }
              </p>

              <div className="space-y-1.5">
                <label className="text-xs font-medium text-gray-300">{isEn ? "Select Future Span" : "মাস নির্বাচন করুন"}</label>
                <select
                  value={selectedMonth}
                  onChange={(e) => setSelectedMonth(e.target.value)}
                  className="w-full bg-black/40 border border-white/15 rounded-xl p-3 text-xs text-white"
                >
                  <option value="June/July 2026">🔮 Next Quarter: June/July 2026</option>
                  <option value="August/September 2026">🍁 Autumn Era: August/September 2026</option>
                  <option value="Mid Winter 2026">❄️ Winter Transition: Mid Winter 2026</option>
                </select>
              </div>

              <button
                onClick={handlePredictTrends}
                disabled={loading}
                className="w-full bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 text-white font-semibold py-3 px-4 rounded-xl text-xs flex items-center justify-center gap-2 cursor-pointer transition-all shadow-md shadow-indigo-950/40"
              >
                <Compass className="w-3.5 h-3.5" />
                <span>{loading ? "Aligning Trend Spheres..." : (isEn ? "Forecast Design Trends (10 Credits)" : "ট্রেন্ড ডাটা ক্যালকুলেট (১০ ক্রেডিট)")}</span>
              </button>
            </div>
          )}

        </div>

        {/* RIGHT COLUMN INTERACTIVE ARENA PREVIEW DISPLAY */}
        <div className="lg:col-span-7 bg-black/55 border border-white/5 p-6 rounded-2xl flex flex-col justify-between min-h-[460px] relative">
          
          {loading && (
            <div className="absolute inset-0 bg-black/85 backdrop-blur-sm z-20 flex flex-col items-center justify-center space-y-4 rounded-2xl">
              <div className="w-10 h-10 border-4 border-indigo-500 border-t-transparent rounded-full animate-spin" />
              <p className="text-xs font-mono text-indigo-300 uppercase animate-pulse tracking-wide">
                Consulting global trend database servers...
              </p>
            </div>
          )}

          <div className="space-y-6">
            <div className="flex items-center justify-between border-b border-white/5 pb-3">
              <span className="text-[10px] font-mono tracking-wider text-gray-500 uppercase flex items-center gap-1.5">
                <span className="w-1.5 h-1.5 bg-indigo-500 rounded-full animate-pulse" />
                <span>Arena Active Content Monitor</span>
              </span>
              <span className="text-[9px] bg-indigo-500/10 text-indigo-400 border border-indigo-500/20 px-2 py-0.5 rounded font-mono uppercase">
                {activeTab} VIEW
              </span>
            </div>

            {/* PREVIEW 1: DAILY DESIGN CHALLENGE */}
            {activeTab === "challenge" && currentChallenge && (
              <div className="space-y-5">
                <div>
                  <div className="flex justify-between items-start">
                    <h4 className="text-md font-bold text-white">{currentChallenge.title}</h4>
                    <span className="text-[9px] bg-indigo-500/15 text-indigo-300 border border-indigo-500/20 px-2 py-0.5 rounded uppercase font-mono font-bold">
                      {currentChallenge.difficulty} Mode
                    </span>
                  </div>
                  <p className="text-xs text-gray-300 leading-relaxed mt-2 p-4 bg-white/5 border border-white/5 rounded-xl font-mono">
                    "{currentChallenge.criteria}"
                  </p>
                </div>

                <div className="p-3 bg-emerald-950/20 border border-emerald-900/30 rounded-xl flex justify-between items-center text-xs">
                  <span className="text-emerald-400 block font-bold">🕒 Streak Reward Active:</span>
                  <span className="text-emerald-300 font-mono font-semibold">{currentChallenge.timeReward}</span>
                </div>

                {/* Simulated task boards list */}
                <div className="space-y-2">
                  <span className="text-[10px] font-mono uppercase text-gray-500 block">Required Design constraints:</span>
                  <div className="space-y-1.5 text-xs">
                    <div className="flex items-center gap-2 text-gray-400">
                      <ShieldCheck className="w-4 h-4 text-indigo-400" />
                      <span>Typography: Must pair modern Space Grotesk size ratios.</span>
                    </div>
                    <div className="flex items-center gap-2 text-gray-400">
                      <ShieldCheck className="w-4 h-4 text-indigo-400" />
                      <span>Containers: Absolute matte glass cards with stroke padding.</span>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* PREVIEW 2: DESIGN BATTLES VOTE DISP */}
            {activeTab === "battle" && (
              <div className="space-y-5">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  
                  {/* Side A visual illustration frame */}
                  <div className="bg-gradient-to-br from-indigo-950/20 to-neutral-900 border border-white/5 p-4 rounded-xl flex flex-col justify-between text-center relative overflow-hidden group">
                    <div className="absolute top-0 inset-x-0 h-1 bg-indigo-500" />
                    <div>
                      <span className="text-[9px] uppercase tracking-wider text-indigo-400 block font-mono">Draft A System</span>
                      <h5 className="text-xs font-bold text-white mt-1">Neon Grid Apex</h5>
                      <p className="text-[10px] text-gray-400 font-mono line-clamp-2 mt-1.5">Saturated violet arcs with floating glass cards.</p>
                    </div>

                    <div className="mt-4 space-y-2">
                      <div className="text-xs font-bold font-mono text-indigo-300">
                        {battleA_votes} Active Votes
                      </div>
                      <button 
                        onClick={() => castCommunityVote("A")}
                        disabled={votedSide !== null}
                        className={`w-full py-1.5 rounded-lg text-xs font-bold transition-all uppercase cursor-pointer ${
                          votedSide === "A" ? "bg-indigo-600 text-white" : "bg-white/5 text-gray-300 hover:bg-white/10"
                        }`}
                      >
                        {votedSide === "A" ? "Your Choice" : "Vote Team A"}
                      </button>
                    </div>
                  </div>

                  {/* Side B visual illustration frame */}
                  <div className="bg-gradient-to-br from-amber-950/20 to-neutral-900 border border-white/5 p-4 rounded-xl flex flex-col justify-between text-center relative overflow-hidden group">
                    <div className="absolute top-0 inset-x-0 h-1 bg-amber-500" />
                    <div>
                      <span className="text-[9px] uppercase tracking-wider text-amber-400 block font-mono">Draft B System</span>
                      <h5 className="text-xs font-bold text-white mt-1">Nordic Velvet White</h5>
                      <p className="text-[10px] text-gray-400 font-mono line-clamp-2 mt-1.5">Soft cream, ample negative spaces, custom serif headings.</p>
                    </div>

                    <div className="mt-4 space-y-2">
                      <div className="text-xs font-bold font-mono text-amber-400">
                        {battleB_votes} Active Votes
                      </div>
                      <button 
                        onClick={() => castCommunityVote("B")}
                        disabled={votedSide !== null}
                        className={`w-full py-1.5 rounded-lg text-xs font-bold transition-all uppercase cursor-pointer ${
                          votedSide === "B" ? "bg-amber-600 text-white" : "bg-white/5 text-gray-300 hover:bg-white/10"
                        }`}
                      >
                        {votedSide === "B" ? "Your Choice" : "Vote Team B"}
                      </button>
                    </div>
                  </div>

                </div>

                <div className="text-center">
                  <p className="text-[10px] text-gray-500">
                    Community design battles are synchronized live every 24 hours. Vote to level up badge stats!
                  </p>
                </div>
              </div>
            )}

            {/* PREVIEW 3: SHOWCASES FEED */}
            {activeTab === "showcase" && (
              <div className="space-y-4">
                <span className="text-[10px] font-mono uppercase text-gray-500 block">Trending Member Showrooms:</span>
                
                <div className="space-y-2.5 max-h-[300px] overflow-y-auto pr-1">
                  {feedItems.map((item) => (
                    <div key={item.id} className="bg-white/5 border border-white/5 p-4 rounded-xl flex justify-between items-center gap-4">
                      <div>
                        <span className="text-[9px] uppercase tracking-widest text-[#a855f7] font-mono">{item.author}</span>
                        <h5 className="text-xs font-bold text-white mt-0.5">{item.title}</h5>
                        <div className="flex gap-1.5 mt-1">
                          {item.tags.map((tg, idx) => (
                            <span key={idx} className="text-[9px] bg-white/5 text-gray-400 px-2 rounded">
                              {tg}
                            </span>
                          ))}
                        </div>
                      </div>

                      <div className="flex items-center gap-3">
                        <button 
                          onClick={() => handleLikeItem(item.id)}
                          className="flex items-center gap-1.5 px-3 py-1.5 bg-indigo-600/10 hover:bg-indigo-600/20 text-indigo-300 hover:text-indigo-200 border border-indigo-500/20 text-xs font-mono font-bold rounded-xl cursor-pointer transition-all"
                        >
                          <Heart className="w-3.5 h-3.5" />
                          <span>{item.likes}</span>
                        </button>
                        <span className="text-[10px] text-gray-500 font-mono">
                          💬 {item.feedbacksCount}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* PREVIEW 4: PREMIUM ASSETS CONTENT DISPLAY */}
            {activeTab === "assets" && (
              <div className="space-y-4 font-mono">
                
                {/* Mode gradients render */}
                {marketTab === "gradients" && (
                  <div className="space-y-3">
                    <span className="text-[10px] text-gray-400 uppercase block">Copyable Premium Theme Gradients:</span>
                    <div className="grid grid-cols-1 gap-2">
                      {codeGradients.map((grad, i) => (
                        <div key={i} className="bg-black/40 border border-white/15 p-3 rounded-xl flex justify-between items-center">
                          <div>
                            <span className="text-xs font-bold text-white block mb-0.5">{grad.name}</span>
                            <span className="text-[10px] text-gray-500 font-mono block truncate max-w-[280px]">{grad.css}</span>
                          </div>
                          <button 
                            onClick={() => triggerCopy(grad.css, `grad_${i}`)}
                            className="text-xs text-indigo-400 hover:text-indigo-300 font-mono font-bold cursor-pointer shrink-0"
                          >
                            {copiedKey === `grad_${i}` ? "Copied!" : "Copy CSS"}
                          </button>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Mode mockups render */}
                {marketTab === "mockups" && (
                  <div className="space-y-2.5">
                    <span className="text-[10px] text-gray-400 uppercase block">Available Preset Device Frames:</span>
                    {mockupGalleries.map((mock, i) => (
                      <div key={i} className="bg-white/5 border border-white/5 p-3 rounded-xl flex justify-between items-center text-xs">
                        <div>
                          <h5 className="font-bold text-gray-200">{mock.title}</h5>
                          <span className="text-[10px] text-gray-500 font-mono uppercase">{mock.category} format</span>
                        </div>
                        <span className="text-xs text-indigo-400 font-mono font-semibold">{mock.size}</span>
                      </div>
                    ))}
                  </div>
                )}

                {/* Mode icons render */}
                {marketTab === "icons" && (
                  <div className="space-y-2.5">
                    <span className="text-[10px] text-gray-400 uppercase block">Available Premium Icon Vector systems:</span>
                    {iconPacks.map((pack, i) => (
                      <div key={i} className="bg-white/5 border border-white/5 p-3 rounded-xl flex justify-between items-center text-xs">
                        <div>
                          <h5 className="font-bold text-gray-200">{pack.title}</h5>
                          <span className="text-[10px] text-gray-500">{pack.tags}</span>
                        </div>
                        <span className="text-[10px] bg-white/5 px-2 py-0.5 rounded text-gray-400">{pack.creator}</span>
                      </div>
                    ))}
                  </div>
                )}

              </div>
            )}

            {/* PREVIEW 5: TREND PREDICTOR RENDER */}
            {activeTab === "trend" && trendResult && (
              <div className="space-y-5">
                <div className="bg-gradient-to-br from-indigo-950/20 to-neutral-900 border border-indigo-500/20 p-5 rounded-2xl space-y-2">
                  <span className="text-[10px] font-mono text-indigo-400 block uppercase font-bold">Predicted Vibe Trend Span:</span>
                  <h4 className="text-md sm:text-lg font-bold text-white">{trendResult.dominantVibe}</h4>
                </div>

                <div className="space-y-2">
                  <span className="text-xs font-bold text-gray-300 block">🎯 Dominant Saturated Paint Swatches:</span>
                  <div className="flex flex-wrap gap-2">
                    {trendResult.winningColors.map((col, idx) => (
                      <span key={idx} className="bg-black/60 text-gray-300 text-xs px-2.5 py-1 rounded-lg border border-white/5 font-mono">
                        {col}
                      </span>
                    ))}
                  </div>
                </div>

                <div className="p-4 bg-white/5 border border-white/5 rounded-xl space-y-1 text-xs">
                  <span className="text-[10px] font-mono text-gray-400 block uppercase">Dominant Structural Layout Rule:</span>
                  <p className="text-gray-300 leading-normal font-sans">{trendResult.layoutStrategy}</p>
                </div>

                <div className="p-4 bg-amber-500/10 border border-amber-500/20 rounded-xl space-y-1 text-xs">
                  <span className="text-[10px] font-mono text-amber-300 block uppercase font-bold">⚠️ Critical Design Practice warning:</span>
                  <p className="text-gray-300 leading-normal font-sans">{trendResult.bannedPracticesTips}</p>
                </div>
              </div>
            )}

          </div>

          <div className="border-t border-white/5 pt-4 text-center text-[10px] text-gray-500 mt-6">
            All marketplace resources and predictors conform strictly to active trend monitoring servers.
          </div>

        </div>

      </div>
    </div>
  );
}
