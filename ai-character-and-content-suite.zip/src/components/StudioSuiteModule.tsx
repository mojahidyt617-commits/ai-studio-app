import React, { useState } from "react";
import { LanguageCode } from "../lib/translations";
import { 
  Sparkles, Compass, Layout, Type as FontIcon, FileText, 
  Image as ImageIcon, Award, Briefcase, Copy, Check, Info,
  ExternalLink, RotateCcw, Palette, HelpCircle, Laptop, Eye
} from "lucide-react";

interface StudioSuiteProps {
  lang: LanguageCode;
  credits: number;
  deductCredits: (qty: number, actionTitle: string) => boolean;
}

export default function StudioSuiteModule({
  lang,
  credits,
  deductCredits,
}: StudioSuiteProps) {
  const isEn = lang === "en";

  // Navigation within the sub-panel
  const [activeTool, setActiveTool] = useState<
    "moodboard" | "layout" | "fonts" | "brief" | "bgtexture" | "logo" | "portfolio"
  >("moodboard");

  // State Management for individual tools
  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState("");
  const [copiedText, setCopiedText] = useState<string | null>(null);

  const handleCopy = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedText(id);
    setTimeout(() => setCopiedText(null), 2000);
  };

  /* ==========================================
     1. AI MOODBOARD GENERATOR STATE
     ========================================== */
  const [moodKeywords, setMoodKeywords] = useState("");
  const [moodStyle, setMoodStyle] = useState("Modern Luxury");
  const [moodboardResult, setMoodboardResult] = useState<{
    title: string;
    concept: string;
    keyFonts: string[];
    colors: { name: string; hex: string; mood: string }[];
    imagery: string[];
    vibeRating: number;
  } | null>(() => {
    try {
      const saved = localStorage.getItem("ai_studio_moodboard");
      if (saved) return JSON.parse(saved);
    } catch {}
    return {
      title: "Cosmic Velvet Noir",
      concept: "A luxurious blend of high-tech space exploration elements combined with rich, tactile midnight velvet materials.",
      keyFonts: ["Cinzel Decorative", "Plus Jakarta Sans"],
      colors: [
        { name: "Deep Royal Amber", hex: "#1e112d", mood: "Mystery" },
        { name: "Neon Violet Star", hex: "#8b5cf6", mood: "Energy" },
        { name: "Dusty Gold Leaf", hex: "#d97706", mood: "Premium wealth" },
        { name: "Liquid Platinum", hex: "#cbd5e1", mood: "Futuristic clean" }
      ],
      imagery: ["Abstract liquid metal fluid swirling", "Gilded nebula dust stellar render", "Dark obsidian textured tiles"],
      vibeRating: 94
    };
  });

  const handleGenerateMoodboard = async () => {
    setErrorMsg("");
    const cost = 10;
    if (credits < cost) {
      setErrorMsg(isEn ? "Insufficient credits! Run a free Topup." : "পর্যাপ্ত ক্রেডিট নেই! বিনামূল্যে রিচার্জ করুন।");
      return;
    }
    setLoading(true);

    const promptObj = {
      keywords: moodKeywords || "cosmic gold high-fashion neo-brutalism",
      style: moodStyle,
    };

    const systemInstruction = 
      "You are a master creative director. Generate a comprehensive visual moodboard. Return ONLY a single JSON object with: { title, concept, keyFonts: [string, string], colors: [{name, hex, mood}], imagery: [string, string, string], vibeRating: number (out of 100) }";

    try {
      const response = await fetch("/api/studio/general-generate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          prompt: `Generate moodboard guidelines for: ${JSON.stringify(promptObj)}`,
          systemInstruction,
          fallbackJson: {
            title: `Experimental ${promptObj.style}`,
            concept: `A custom customized visual direction matching the keyword query: ${promptObj.keywords}.`,
            keyFonts: ["Space Grotesk", "Inter"],
            colors: [
              { name: "Theme Deep Accent", hex: "#0f172a", mood: "Stable structure" },
              { name: "Core Highlight", hex: "#3b82f6", mood: "High attention" },
              { name: "Refined Silver", hex: "#e2e8f0", mood: "Spacious breathing" }
            ],
            imagery: ["Minimal geometric lines intersecting", "Soft shadow overlay on sand textures"],
            vibeRating: 88
          }
        })
      });

      const resData = await response.json();
      if (resData.success && resData.data) {
        setMoodboardResult(resData.data);
        localStorage.setItem("ai_studio_moodboard", JSON.stringify(resData.data));
        deductCredits(cost, `Moodboard Generator: ${resData.data.title}`);
      } else {
        throw new Error();
      }
    } catch {
      setErrorMsg("Failed to generate Moodboard. Please check network connection.");
    } finally {
      setLoading(false);
    }
  };

  /* ==========================================
     2. AI LAYOUT ARCHITECT STATE
     ========================================== */
  const [layoutType, setLayoutType] = useState<"Poster Layout" | "Thumbnail Layout" | "Banner Layout" | "Social Media Layout">("Thumbnail Layout");
  const [layoutTheme, setLayoutTheme] = useState("Tech Minimalist");
  const [layoutResult, setLayoutResult] = useState<{
    blueprintTitle: string;
    dimensions: string;
    typographyGuide: string;
    components: { position: string; text: string; bgStyle: string; flexRatio: string }[];
    marketingSlogan: string;
    technicalImplementationTips: string;
  } | null>(() => {
    try {
      const saved = localStorage.getItem("ai_studio_layout");
      if (saved) return JSON.parse(saved);
    } catch {}
    return {
      blueprintTitle: "Aviation Tech Banner",
      dimensions: "1920 x 1080px (Standard Large Graphic)",
      typographyGuide: "Header: Outfit ExtraBold (Letter tracking wide). Subhead: JetBrains Mono Light.",
      components: [
        { position: "Background Canvas", text: "Dark radial slate gradient with custom vector grid mesh intersecting", bgStyle: "from-slate-950 to-neutral-900 bg-radial", flexRatio: "w-full" },
        { position: "Left Graphic Column", text: "High-contrast geometric mock wireframe glowing blue", bgStyle: "bg-blue-600/10 border border-blue-500/20", flexRatio: "md:col-span-5" },
        { position: "Right Copy Block", text: "Aviation blueprint title with a glowing badge above reading 'V.2 COMPLIANT'", bgStyle: "bg-white/5 border border-white/5", flexRatio: "md:col-span-7" }
      ],
      marketingSlogan: "FLY BEYOND THE CLOUD BOUNDS",
      technicalImplementationTips: "Apply backdrops filter blur and rich box-shadow glow styles to represent true depth gradients."
    };
  });

  const handleGenerateLayout = async () => {
    setErrorMsg("");
    const cost = 10;
    if (credits < cost) {
      setErrorMsg(isEn ? "Insufficient credits!" : "পর্যাপ্ত ক্রেডিট নেই!");
      return;
    }
    setLoading(true);

    const systemInstruction = 
      "You are a Senior UI/UX Designer specialized in high-performance layouts. Return ONLY a single JSON object structured as: { blueprintTitle, dimensions, typographyGuide, components: [{position, text, bgStyle (Tailwind bg/border classes e.g. 'bg-indigo-600/10 text-indigo-400 border border-indigo-500/20'), flexRatio (Tailwind layout classes e.g. 'col-span-12' or 'col-span-6')}], marketingSlogan, technicalImplementationTips }";

    try {
      const response = await fetch("/api/studio/general-generate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          prompt: `Create custom layout architecture blueprint for: Type: "${layoutType}", Theme: "${layoutTheme}"`,
          systemInstruction,
          fallbackJson: {
            blueprintTitle: `Standard Refined ${layoutType}`,
            dimensions: "1200 x 630px (Responsive layout)",
            typographyGuide: "Primary heading in interbold matched with modern subtle mono secondary tags.",
            components: [
              { position: "Visual Frame", text: "Generous left section containing the focal asset preview", bgStyle: "bg-emerald-600/10 border-emerald-500/20 border", flexRatio: "md:col-span-4" },
              { position: "Details & Text Card", text: "Generates descriptive information, title tags, CTA buttons", bgStyle: "bg-[#18181B] border-white/5 border", flexRatio: "md:col-span-8" }
            ],
            marketingSlogan: "PERFECT HARMONY OF SPACE AND CONTENT",
            technicalImplementationTips: "Keep padding fluid and rely heavily on gap-4 flex wrap on adaptive screen breaks."
          }
        })
      });

      const resData = await response.json();
      if (resData.success && resData.data) {
        setLayoutResult(resData.data);
        localStorage.setItem("ai_studio_layout", JSON.stringify(resData.data));
        deductCredits(cost, `Layout Architected: ${resData.data.blueprintTitle}`);
      }
    } catch {
      setErrorMsg("Failed to generate layout blueprint. Try again later.");
    } finally {
      setLoading(false);
    }
  };

  /* ==========================================
     3. AI FONT PAIRING GENERATOR STATE
     ========================================== */
  const [fontIndustry, setFontIndustry] = useState("Luxury Vintage");
  const [userFontText, setUserFontText] = useState("The quick brown fox jumps over the lazy dog");
  const [fontResult, setFontResult] = useState<{
    pairingName: string;
    headlineFont: string;
    bodyFont: string;
    rationale: string;
    headlineStylingClass: string;
    bodyStylingClass: string;
  } | null>(() => {
    try {
      const saved = localStorage.getItem("ai_studio_fonts");
      if (saved) return JSON.parse(saved);
    } catch {}
    return {
      pairingName: "Classic Editorial",
      headlineFont: "Playfair Display",
      bodyFont: "Inter",
      rationale: "Serif headings evoke luxury, legacy, and heritage, while a clean geometric sans-serif keeps the body highly readable on all screen sizes.",
      headlineStylingClass: "font-serif tracking-tight text-3xl",
      bodyStylingClass: "font-sans leading-relaxed text-sm text-gray-300"
    };
  });

  const handleGenerateFonts = async () => {
    setErrorMsg("");
    const cost = 5;
    if (credits < cost) {
      setErrorMsg(isEn ? "No credits!" : "ক্রেডিট নেই!");
      return;
    }
    setLoading(true);

    const systemInstruction = 
      "You are a typography specialist. Generate an outstanding font pairing of classic free Google Fonts. Return ONLY a single JSON object: { pairingName, headlineFont, bodyFont, rationale, headlineStylingClass (e.g. Tailwind classes like tracking-wide), bodyStylingClass }";

    try {
      const response = await fetch("/api/studio/general-generate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          prompt: `Generate font pairing suggestions for: Niche: "${fontIndustry}"`,
          systemInstruction,
          fallbackJson: {
            pairingName: "Modern Vanguard",
            headlineFont: "Space Grotesk",
            bodyFont: "Inter",
            rationale: "Tech-forward wide sans-serif provides immediate attitude, nicely complemented by highly legible text standards.",
            headlineStylingClass: "font-sans tracking-tight text-3xl font-bold uppercase",
            bodyStylingClass: "font-sans leading-relaxed text-sm text-gray-300"
          }
        })
      });

      const resData = await response.json();
      if (resData.success && resData.data) {
        setFontResult(resData.data);
        localStorage.setItem("ai_studio_fonts", JSON.stringify(resData.data));
        deductCredits(cost, `Fonts Engineered: ${resData.data.pairingName}`);
      }
    } catch {
      setErrorMsg("Error creating pairings.");
    } finally {
      setLoading(false);
    }
  };

  /* ==========================================
     4. AI DESIGN BRIEF GENERATOR STATE
     ========================================== */
  const [rawRequirement, setRawRequirement] = useState("");
  const [briefResult, setBriefResult] = useState<{
    projectTitle: string;
    objective: string;
    targetAudience: string;
    toneOfVoice: string;
    deliverables: string[];
    timelineEstimation: string;
    competitorAnalysisSummary: string;
  } | null>(() => {
    try {
      const saved = localStorage.getItem("ai_studio_brief");
      if (saved) return JSON.parse(saved);
    } catch {}
    return {
      projectTitle: "BrewCraft Artisan Cafe Rebranding",
      objective: "Reposition an organic coffee roastery for urban remote workers and eco-conscious youth, emphasizing zero-waste practices.",
      targetAudience: "Eco-minded professionals, design students, and specialty coffee lovers (Ages 18-45)",
      toneOfVoice: "Warm, authentic, earthy yet high-quality modern minimalist",
      deliverables: ["1x Core Emblem Logo", "3x Eco-friendly Cup Textures", "Responsive Brand Style Guide"],
      timelineEstimation: "Weeks 1-2: Direction & Moodboarding. Weeks 3-4: Refinement. Week 5: Package Asset Delivery.",
      competitorAnalysisSummary: "Competitors rely heavily on dark charcoal colors and corporate logos. Brewcraft stands out using handmade tactile patterns and natural botanical tones."
    };
  });

  const handleGenerateBrief = async () => {
    setErrorMsg("");
    const cost = 15;
    if (credits < cost) {
      setErrorMsg(isEn ? "No credits!" : "ক্রেডিট নেই!");
      return;
    }
    setLoading(true);

    const systemInstruction = 
      "You are a business and design analyst. Convert raw requirements into an exquisite, professional, high-agency Creative Design Brief. Return EXACTLY a single JSON object: { projectTitle, objective, targetAudience, toneOfVoice, deliverables: [string, string], timelineEstimation, competitorAnalysisSummary }";

    try {
      const response = await fetch("/api/studio/general-generate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          prompt: `Translate raw request: "${rawRequirement || "Need branding for organic beauty studio"}"`,
          systemInstruction,
          fallbackJson: {
            projectTitle: "GlowPure Organic Aesthetics",
            objective: "Establish a serene brand identity emphasizing medical authenticity and botanical purity.",
            targetAudience: "Quality-driven premium cosmetics users looking for eco-clean choices.",
            toneOfVoice: "Soothing, pure, luxurious, informative.",
            deliverables: ["Primary Logomark", "Premium Glass Bottle Labels", "Social media templates."],
            timelineEstimation: "Estimated delivery of all visual systems in 3 calendar weeks.",
            competitorAnalysisSummary: "Competitors are overly bright and clinical. Focus on botanical textures and deep soft olive hues."
          }
        })
      });

      const resData = await response.json();
      if (resData.success && resData.data) {
        setBriefResult(resData.data);
        localStorage.setItem("ai_studio_brief", JSON.stringify(resData.data));
        deductCredits(cost, `Formulated Brief: ${resData.data.projectTitle}`);
        setRawRequirement("");
      }
    } catch {
      setErrorMsg("Error formulating brief.");
    } finally {
      setLoading(false);
    }
  };

  /* ==========================================
     5. AI BACKGROUND & TEXTURE GENERATOR STATE
     ========================================== */
  const [textureStyle, setTextureStyle] = useState<"Abstract Wave" | "Luxury Gold Grid" | "Neo-Tech Grid" | "Textured Paper" | "Metallic Steel" | "Frosted Glass">("Neo-Tech Grid");
  const [generatedTexture, setGeneratedTexture] = useState<{
    title: string;
    cssCode: string;
    svgMarkup: string;
    promptExplanation: string;
  } | null>(() => {
    return {
      title: "Interactive Matrix Grid",
      cssCode: "background-image: radial-gradient(circle at 1px 1px, rgba(59, 130, 246, 0.15) 1px, transparent 0); background-size: 24px 24px;",
      svgMarkup: `<svg width="100" height="100" xmlns="http://www.w3.org/2000/svg"><pattern id="grid" width="20" height="20" patternUnits="userSpaceOnUse"><path d="M 20 0 L 0 0 0 20" fill="none" stroke="rgba(59,130,246,0.2)" stroke-width="0.5"/></pattern><rect width="100%" height="100%" fill="url(#grid)"/></svg>`,
      promptExplanation: "A tech-forward vector grid mesh symbolizing high-performance system pathways and secure databases."
    };
  });

  const handleGenerateTexture = () => {
    // Generate real-time cool textures client-side instantly to be interactive, saving credits!
    let title = `${textureStyle} Canvas Pattern`;
    let cssCode = "";
    let svgMarkup = "";
    let promptExplanation = "";

    if (textureStyle === "Neo-Tech Grid") {
      cssCode = "background-image: linear-gradient(rgba(59, 130, 246, 0.1) 1px, transparent 1px), linear-gradient(90deg, rgba(59,130,246,0.1) 1px, transparent 1px); background-size: 30px 30px;";
      svgMarkup = `<svg width="100%" height="150" xmlns="http://www.w3.org/2000/svg"><defs><pattern id="grid" width="30" height="30" patternUnits="userSpaceOnUse"><path d="M 30 0 L 0 0 0 30" fill="none" stroke="#3b82f6" stroke-width="0.5" stroke-opacity="0.2"/></pattern></defs><rect width="100%" height="100%" fill="url(#grid)" /></svg>`;
      promptExplanation = "Modern futuristic architectural wiring design, perfect for cybersecurity dashboards or luxury dark assets.";
    } else if (textureStyle === "Luxury Gold Grid") {
      cssCode = "background-image: linear-gradient(45deg, #261605 25%, transparent 25%), linear-gradient(-45deg, #261605 25%, transparent 25%), linear-gradient(45deg, transparent 75%, #261605 75%); background-size: 40px 40px; background-color: #0b0704;";
      svgMarkup = `<svg width="100%" height="150" xmlns="http://www.w3.org/2000/svg"><rect width="100%" height="100%" fill="#0b0704"/><path d="M0 0 L150 150 M150 0 L0 150" stroke="#fbbf24" stroke-width="0.5" stroke-opacity="0.15" fill="none"/></svg>`;
      promptExplanation = "Gilded premium diamond weave pattern radiating extreme opulence, ideal for luxury menus, watch brands, or high-end portals.";
    } else if (textureStyle === "Abstract Wave") {
      cssCode = "background: radial-gradient(circle at 10% 20%, rgba(99, 102, 241, 0.2) 0%, rgba(168, 85, 247, 0.05) 90.2%);";
      svgMarkup = `<svg width="100%" height="150" xmlns="http://www.w3.org/2000/svg"><path d="M0 80 Q 75 10, 150 80 T 300 80 T 450 80" fill="none" stroke="#6366f1" stroke-width="2" stroke-opacity="0.4"/></svg>`;
      promptExplanation = "Smooth cosmic fluid curve vectors conveying organic harmony, motion, and digital elegance.";
    } else if (textureStyle === "Textured Paper") {
      cssCode = "background-color: #121214; background-image: radial-gradient(rgba(255,255,255,0.03) 1px, transparent 0); background-size: 8px 8px;";
      svgMarkup = `<svg width="100%" height="150" xmlns="http://www.w3.org/2000/svg"><filter id="noise"><feTurbulence type="fractalNoise" baseFrequency="0.8" numOctaves="3" result="noise"/><feColorMatrix type="matrix" values="0 0 0 0 0   0 0 0 0 0   0 0 0 0 0  0 0 0 0.07 0"/></filter><rect width="100%" height="100%" filter="url(#noise)" fill="#111"/></svg>`;
      promptExplanation = "Fine tactile handmade linen fiber noise pattern, adding realistic touch values to screens.";
    } else if (textureStyle === "Metallic Steel") {
      cssCode = "background: linear-gradient(135deg, #1f2937 0%, #111827 50%, #1f2937 100%);";
      svgMarkup = `<svg width="100%" height="150" xmlns="http://www.w3.org/2000/svg"><path d="M0 10 L400 10 M0 50 L400 50 M0 90 L400 90" stroke="rgba(255,255,255,0.05)" stroke-width="2"/></svg>`;
      promptExplanation = "Brushed space-grade industrial steel armor lines reflecting subtle horizontal glowing shines.";
    } else {
      cssCode = "background: rgba(255, 255, 255, 0.03); backdrop-filter: blur(16px); border: 1px solid rgba(255,255,255,0.08);";
      svgMarkup = `<svg width="100%" height="150" xmlns="http://www.w3.org/2000/svg"><rect width="100%" height="100%" fill="rgba(255,255,255,0.03)" rx="10"/><circle cx="50" cy="50" r="30" fill="#a855f7" opacity="0.1" filter="blur(8px)"/></svg>`;
      promptExplanation = "True translucent high-contrast frosted glass container layout with ambient purple bokeh blur behind.";
    }

    setGeneratedTexture({ title, cssCode, svgMarkup, promptExplanation });
  };

  /* ==========================================
     6. AI LOGO IDEA GENERATOR STATE
     ========================================== */
  const [logoCompany, setLogoCompany] = useState("");
  const [logoConcept, setLogoConcept] = useState("Symmetrical emblem containing waves");
  const [logoResult, setLogoResult] = useState<{
    suggestedName: string;
    conceptualSketches: { title: string; description: string; symbolMeaning: string }[];
    recommendedColors: string[];
  } | null>(() => {
    try {
      const saved = localStorage.getItem("ai_studio_logo");
      if (saved) return JSON.parse(saved);
    } catch {}
    return {
      suggestedName: "HydroFlow Athletics",
      conceptualSketches: [
        { title: "The Dynamic Circle", description: "Consists of three intersecting blue and teal wave vectors forming an unbroken Zen circle.", symbolMeaning: "Represents endless persistence, flow, and energetic renewal." },
        { title: "Linear Peak Emblem", description: "A minimalist jagged mountain shape where the peak morphs into a fluid drop.", symbolMeaning: "Contrasts rigid stability with dynamic, organic adaptation." }
      ],
      recommendedColors: ["#0284c7 (Ocean Sapphire)", "#2dd4bf (Neon Mint Teal)", "#f8fafc (Pure Alpine White)"]
    };
  });

  const handleGenerateLogo = async () => {
    setErrorMsg("");
    const cost = 10;
    if (credits < cost) {
      setErrorMsg(isEn ? "No credits!" : "ক্রেডিট নেই!");
      return;
    }
    setLoading(true);

    const systemInstruction = 
      "You are a premier logo strategist. Return EXACTLY a single JSON object with layout sketches and name suggestions: { suggestedName, conceptualSketches: [{title, description, symbolMeaning}], recommendedColors: [string, string] }";

    try {
      const response = await fetch("/api/studio/general-generate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          prompt: `Create a logo blueprint system for brand: "${logoCompany || "Apex Energy"}", details: "${logoConcept}"`,
          systemInstruction,
          fallbackJson: {
            suggestedName: logoCompany || "Vortex Spark",
            conceptualSketches: [
              { title: "The Shield of Aurora", description: "A sharp triangular modern shield outlined in gold with neon lightning arcs in negative space.", symbolMeaning: "Expresses secure shield dynamics with dynamic electricity bursts." }
            ],
            recommendedColors: ["#fbbf24 (Amber Gold)", "#1e293b (Midnight)", "#ef4444 (Vivid Flare Gold)"]
          }
        })
      });

      const resData = await response.json();
      if (resData.success && resData.data) {
        setLogoResult(resData.data);
        localStorage.setItem("ai_studio_logo", JSON.stringify(resData.data));
        deductCredits(cost, `Logo Concept Derived: ${resData.data.suggestedName}`);
        setLogoCompany("");
      }
    } catch {
      setErrorMsg("Error generating logo systems.");
    } finally {
      setLoading(false);
    }
  };

  /* ==========================================
     7. AI PORTFOLIO BUILDER STATE
     ========================================== */
  const [designerName, setDesignerName] = useState("");
  const [personalNiche, setPersonalNiche] = useState("Visual Strategist & Brand Designer");
  const [portfolioResult, setPortfolioResult] = useState<{
    profileName: string;
    headline: string;
    aboutText: string;
    coreStack: string[];
    caseStudies: { title: string; client: string; problem: string; conceptSolution: string; outputStat: string }[];
  } | null>(() => {
    try {
      const saved = localStorage.getItem("ai_studio_portfolio");
      if (saved) return JSON.parse(saved);
    } catch {}
    return {
      profileName: "Sarah Al-Jamil",
      headline: "Crafting High-Performance Visual Identity Packages for Fast-Growing Tech Startups.",
      aboutText: "With over 6 years of experience intersecting brand strategy with high-conversion landing page layouts, I help high-growth SaaS firms acquire user trust through premium visual credibility.",
      coreStack: ["Brand Systems", "Interactive Layouts", "Custom Figma Libraries", "Tailwind Design"],
      caseStudies: [
        { title: "Revisiting Fintech Interface Trust", client: "PayShield Global", problem: "Client had high drop-off rates on signups because customers found the interface too complicated.", conceptSolution: "Simplified visual complexity, introduced absolute layout grids, and optimized color hierarchy around trust accents.", outputStat: "Boosted completed registrations by 44% in 30 days." },
        { title: "Launching Modern Mobility Hub", client: "Voyage Electric", problem: "Need to launch a brand new EV booking app visually separate from old corporate vehicles.", conceptSolution: "Curated a bold cyber-emerald theme paired with Space Grotesk display fonts to convey speed and future readiness.", outputStat: "Acquired 10k downloads in first pilot week." }
      ]
    };
  });

  const handleBuildPortfolio = async () => {
    setErrorMsg("");
    const cost = 15;
    if (credits < cost) {
      setErrorMsg(isEn ? "No credits!" : "ক্রেডিট নেই!");
      return;
    }
    setLoading(true);

    const systemInstruction = 
      "You are a luxury career coach for developers and designers. Build an amazing, premium personal design portfolio overview. Return EXACTLY a single JSON object: { profileName, headline, aboutText, coreStack: [string, string, string], caseStudies: [{title, client, problem, conceptSolution, outputStat}] }";

    try {
      const response = await fetch("/api/studio/general-generate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          prompt: `Build tailored design portfolio profile for: Designer Name: "${designerName || "Rashed Ahmed"}", Specialty: "${personalNiche}"`,
          systemInstruction,
          fallbackJson: {
            profileName: designerName || "Kazi Mahtab",
            headline: "Designing immersive experiences for digital pioneers.",
            aboutText: "Fusing functional minimalist aesthetics with rigorous analytical strategy to drive design success.",
            coreStack: ["Visual Systems", "SVG Vector Design", "Web Interaction Flow"],
            caseStudies: [
              { title: "Ditching the Static Corporate Shell", client: "Starlight Biotech", problem: "Corporate portal felt prehistoric, failing to attract research collaborators.", conceptSolution: "Implemented micro-animations, glass containers, and high-contrast layouts.", outputStat: "Partnerships grew by 35% within two quarters." }
            ]
          }
        })
      });

      const resData = await response.json();
      if (resData.success && resData.data) {
        setPortfolioResult(resData.data);
        localStorage.setItem("ai_studio_portfolio", JSON.stringify(resData.data));
        deductCredits(cost, `Portfolio Built: ${resData.data.profileName}`);
        setDesignerName("");
      }
    } catch {
      setErrorMsg("Error generating portfolio system.");
    } finally {
      setLoading(false);
    }
  };


  return (
    <div className="bg-[#111115] border border-white/5 rounded-3xl p-4 sm:p-8 space-y-8 text-white relative overflow-hidden">
      {/* Absolute styling blurs */}
      <div className="absolute -top-10 -left-10 w-48 h-48 bg-indigo-500/10 blur-[80px] pointer-events-none rounded-full" />
      
      {/* Title Header */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 border-b border-white/5 pb-6">
        <div>
          <h2 className="text-xl sm:text-2xl font-display font-medium tracking-tight text-white flex items-center gap-2">
            <Compass className="w-6 h-6 text-indigo-400 rotate-12" />
            <span>{isEn ? "AI Creator Studio Suite" : "এআই ক্রিয়েটর স্টুডিও স্যুট"}</span>
            <span className="text-[10px] bg-indigo-600/20 text-indigo-400 border border-indigo-500/30 px-2 py-0.5 rounded-full uppercase font-mono">
              Premium Enabled
            </span>
          </h2>
          <p className="text-xs text-gray-400 mt-1">
            {isEn ? "Instant generative workflows to fast-track your complete aesthetic production cycle." : "আপনার সম্পূর্ণ নান্দনিক ডিজাইনের প্রোডাকশন সাইকেল দ্রুত কার্যকর করুন।"}
          </p>
        </div>

        {/* Quick Horizontal Sub-Navigation */}
        <div className="flex flex-wrap gap-1.5 p-1 bg-white/5 border border-white/5 rounded-2xl max-w-full">
          {[
            { id: "moodboard", label: isEn ? "Moodboard" : "মুডবোর্ড", icon: Palette },
            { id: "layout", label: isEn ? "Layouts" : "লেআউটস", icon: Layout },
            { id: "fonts", label: isEn ? "Fonts" : "ফন্ট পেয়ার", icon: FontIcon },
            { id: "brief", label: isEn ? "Briefs" : "ডিজাইন ব্রিফ", icon: FileText },
            { id: "bgtexture", label: isEn ? "Textures" : "টেক্সচার্স", icon: ImageIcon },
            { id: "logo", label: isEn ? "Logo Ideas" : "লোগো আইডিয়া", icon: Award },
            { id: "portfolio", label: isEn ? "Portfolios" : "পোর্টফোলিও", icon: Briefcase },
          ].map((tool) => {
            const Icon = tool.icon;
            return (
              <button
                key={tool.id}
                onClick={() => {
                  setActiveTool(tool.id as any);
                  setErrorMsg("");
                }}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold cursor-pointer transition-all ${
                  activeTool === tool.id
                    ? "bg-indigo-600 text-white shadow-md shadow-indigo-900/40"
                    : "text-gray-400 hover:text-white hover:bg-white/5"
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                <span>{tool.label}</span>
              </button>
            );
          })}
        </div>
      </div>

      {errorMsg && (
        <div className="p-4 bg-red-900/10 border border-red-500/20 rounded-2xl text-xs text-red-400 flex items-center gap-2">
          <Info className="w-4 h-4 shrink-0" />
          <span>{errorMsg}</span>
        </div>
      )}

      {/* Primary Workspace Area */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* LEFT COLUMN: Tool Parameters Inputs */}
        <div className="lg:col-span-5 space-y-6 bg-white/5 border border-white/5 p-6 rounded-2xl">
          
          {/* 1. MOODBOARD FORM */}
          {activeTool === "moodboard" && (
            <div className="space-y-4">
              <h3 className="text-sm font-semibold tracking-wider text-gray-300 uppercase flex items-center gap-2">
                <Palette className="w-4 h-4 text-indigo-400" />
                <span>{isEn ? "Generate Moodboard" : "মুডবোর্ড তৈরি করুন"}</span>
              </h3>
              <p className="text-xs text-gray-400">
                {isEn ? "Synthesize visual references, premium color palettes, and typeface combinations based on simple concept ideas." : "আপনার কনসেপ্টের উপর ভিত্তি করে প্রিমিয়াম কালার স্কিম ও ভিজ্যুয়াল রিলেশনশিপ প্রম্পট বের করুন।"}
              </p>
              
              <div className="space-y-1.5">
                <label className="text-xs font-medium text-gray-300">{isEn ? "Idea/Keywords" : "আইডিয়া অথবা কী-ওয়ার্ডসমূহ"}</label>
                <input
                  type="text"
                  placeholder="e.g., luxury organic green coffee, cyberpunk neon underground"
                  value={moodKeywords}
                  onChange={(e) => setMoodKeywords(e.target.value)}
                  className="w-full bg-black/40 border border-white/15 rounded-xl p-3 text-xs text-white placeholder-gray-500 focus:outline-none focus:border-indigo-500 transition-all"
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-medium text-gray-300">{isEn ? "Style Theme" : "স্টাইল থিম"}</label>
                <select
                  value={moodStyle}
                  onChange={(e) => setMoodStyle(e.target.value)}
                  className="w-full bg-black/40 border border-white/15 rounded-xl p-3 text-xs text-sh-neutral-50 focus:outline-none focus:border-indigo-500 transition-all text-white"
                >
                  <option value="Modern Luxury">💎 Modern Luxury / প্রিমিয়াম লাক্সারি</option>
                  <option value="Neo Brutalism">⚡ Neo Brutalism / বোল্ড নিও-ব্রুটালিজম</option>
                  <option value="Nordic Minimalist">🌲 Nordic Minimalist / শান্ত মিনিমালিস্ট</option>
                  <option value="Synthwave Retro">👾 Synthwave Retro / সাইবারRetro</option>
                  <option value="Earthy Organic">🍃 Earthy Organic / প্রাকৃতিক অর্গানিক</option>
                </select>
              </div>

              <button
                onClick={handleGenerateMoodboard}
                disabled={loading}
                className="w-full mt-2 bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 text-white font-semibold py-3 px-4 rounded-xl text-xs flex items-center justify-center gap-2 cursor-pointer transition-all shadow-md shadow-indigo-900/40"
              >
                <Sparkles className="w-3.5 h-3.5" />
                <span>{loading ? (isEn ? "Designing Moodboard..." : "তৈরি হচ্ছে...") : (isEn ? "Generate Moodboard (10 Credits)" : "মুডবোর্ড জেনারেট করুন (১০ ক্রেডিট)")}</span>
              </button>
            </div>
          )}

          {/* 2. LAYOUT ARCHITECT FORM */}
          {activeTool === "layout" && (
            <div className="space-y-4">
              <h3 className="text-sm font-semibold tracking-wider text-gray-300 uppercase flex items-center gap-2">
                <Layout className="w-4 h-4 text-indigo-400" />
                <span>{isEn ? "Layout Blueprint Planner" : "লেআউট প্ল্যানার"}</span>
              </h3>
              <p className="text-xs text-gray-400">
                {isEn ? "Let AI outline premium wireframe partitions, placement details, and exact viewport components." : "এআই পুরো ইমেজ ও টেক্সট প্লেসমেন্টের স্ট্রাকচারাল রিলেশন প্ল্যানিং করে দেবে।"}
              </p>

              <div className="space-y-1.5">
                <label className="text-xs font-medium text-gray-300">{isEn ? "Select Category" : "ক্যাটাগরি নির্বাচন"}</label>
                <div className="grid grid-cols-2 gap-2">
                  {["Thumbnail Layout", "Poster Layout", "Banner Layout", "Social Media Layout"].map((type) => (
                    <button
                      key={type}
                      onClick={() => setLayoutType(type as any)}
                      className={`p-2.5 rounded-xl border text-[11px] font-medium text-center transition-all cursor-pointer ${
                        layoutType === type
                          ? "bg-indigo-600/20 border-indigo-500 text-indigo-300"
                          : "bg-black/30 border-white/5 text-gray-400 hover:text-white"
                      }`}
                    >
                      {type}
                    </button>
                  ))}
                </div>
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-medium text-gray-300">{isEn ? "Vibe Direction" : "স্টাইল ডিরেকশন"}</label>
                <input
                  type="text"
                  placeholder="e.g., Bold Typography with geometric curves, dark cyber neon"
                  value={layoutTheme}
                  onChange={(e) => setLayoutTheme(e.target.value)}
                  className="w-full bg-black/40 border border-white/15 rounded-xl p-3 text-xs text-white placeholder-gray-500 focus:outline-none focus:border-indigo-500 transition-all"
                />
              </div>

              <button
                onClick={handleGenerateLayout}
                disabled={loading}
                className="w-full bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 text-white font-semibold py-3 px-4 rounded-xl text-xs flex items-center justify-center gap-2 cursor-pointer transition-all"
              >
                <Layout className="w-3.5 h-3.5" />
                <span>{loading ? "Planning System..." : (isEn ? "Draft Layout Blueprint (10 Credits)" : "লেআউট সিস্টেম বানান (১০ ক্রেডিট)")}</span>
              </button>
            </div>
          )}

          {/* 3. FONT PAIRING FORM */}
          {activeTool === "fonts" && (
            <div className="space-y-4">
              <h3 className="text-sm font-semibold tracking-wider text-gray-300 uppercase flex items-center gap-2">
                <FontIcon className="w-4 h-4 text-indigo-400" />
                <span>{isEn ? "Font Combination System" : "ফন্ট কম্বিনেশন"}</span>
              </h3>
              <p className="text-xs text-gray-400">
                {isEn ? "Discover high-status typography pairings that resonate with specific industries and users." : "যেকোনো প্রোডাক্ট ক্যাটাগরির জন্য ফাস্ট-ক্লাস টাইপোগ্রাফি পেয়ারিং খুঁজে বের করুন।"}
              </p>

              <div className="space-y-1.5">
                <label className="text-xs font-medium text-gray-300">{isEn ? "Niche Vibe" : "নিশ ভাইব"}</label>
                <input
                  type="text"
                  placeholder="e.g., Luxury Wristwatches, Organic Skincare"
                  value={fontIndustry}
                  onChange={(e) => setFontIndustry(e.target.value)}
                  className="w-full bg-black/40 border border-white/15 rounded-xl p-3 text-xs text-white placeholder-gray-500 focus:outline-none focus:border-indigo-500 transition-all"
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-medium text-gray-300">{isEn ? "Type Custom Preview Text" : "প্রিভিউ টেক্সট পরিবর্তন করুন"}</label>
                <input
                  type="text"
                  value={userFontText}
                  onChange={(e) => setUserFontText(e.target.value)}
                  placeholder="The quick brown fox..."
                  className="w-full bg-black/40 border border-white/15 rounded-xl p-2.5 text-xs text-white placeholder-gray-500 focus:outline-none focus:border-indigo-500 transition-all"
                />
              </div>

              <button
                onClick={handleGenerateFonts}
                disabled={loading}
                className="w-full bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 text-white font-semibold py-3 px-4 rounded-xl text-xs flex items-center justify-center gap-2 cursor-pointer transition-all"
              >
                <FontIcon className="w-3.5 h-3.5" />
                <span>{loading ? "Matching Fonts..." : (isEn ? "Synthesize Font Pairing (5 Credits)" : "ফন্ট পেয়ার জেনারেট (৫ ক্রেডিট)")}</span>
              </button>
            </div>
          )}

          {/* 4. DESIGN BRIEF FORM */}
          {activeTool === "brief" && (
            <div className="space-y-4">
              <h3 className="text-sm font-semibold tracking-wider text-gray-300 uppercase flex items-center gap-2">
                <FileText className="w-4 h-4 text-indigo-400" />
                <span>{isEn ? "Client Brief Translator" : "ক্লায়েন্ট ব্রিফ অ্যানালাইজার"}</span>
              </h3>
              <p className="text-xs text-gray-400">
                {isEn ? "Convert disorganized client chats or emails into an industrial-standard detailed Creative Design Brief." : "এলোমেলো ফেসবুক বা হোয়াটসঅ্যাপ চ্যাট থেকে এক ক্লিকে সম্পূর্ণ প্রফেশনাল ডিজাইন ব্রিফ তৈরি করুন।"}
              </p>

              <div className="space-y-1.5">
                <label className="text-xs font-medium text-gray-300">{isEn ? "Raw Requirement/Paste chat here" : "কাঁচা ক্লায়েন্ট রিকোয়ারমেন্ট অথবা চ্যাট পেস্ট করুন"}</label>
                <textarea
                  rows={4}
                  placeholder="e.g., 'i have a small grocery store called GreenCart, we want eco packaging and must have delivery bike illustration. finished in 10 days max please'"
                  value={rawRequirement}
                  onChange={(e) => setRawRequirement(e.target.value)}
                  className="w-full bg-black/40 border border-white/15 rounded-xl p-3 text-xs text-white placeholder-gray-500 focus:outline-none focus:border-indigo-500 transition-all font-mono"
                />
              </div>

              <button
                onClick={handleGenerateBrief}
                disabled={loading || !rawRequirement.trim()}
                className="w-full bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 text-white font-semibold py-3 px-4 rounded-xl text-xs flex items-center justify-center gap-2 cursor-pointer transition-all"
              >
                <FileText className="w-3.5 h-3.5" />
                <span>{loading ? "Drafting Brief..." : (isEn ? "Compile Professional Brief (15 Credits)" : "ডিজাইন ব্রিফ জেনারেট করুন (১৫ ক্রেডিট)")}</span>
              </button>
            </div>
          )}

          {/* 5. BACKGROUNDS & TEXTURE FORM */}
          {activeTool === "bgtexture" && (
            <div className="space-y-4">
              <h3 className="text-sm font-semibold tracking-wider text-gray-300 uppercase flex items-center gap-2">
                <ImageIcon className="w-4 h-4 text-indigo-400" />
                <span>{isEn ? "Background & Texture Kit" : "ব্যাকগ্রাউন্ড ও টেক্সচার"}</span>
              </h3>
              <p className="text-xs text-gray-400">
                {isEn ? "Preview interactive canvas meshes and instantly copy CSS background snippets or SVG layers." : "আপনার প্রজেক্টে ব্যবহারের জন্য ইন্টারেক্টিভ ক্যানভাস প্যারামিটার কোড জেনারেট করুন।"}
              </p>

              <div className="space-y-1.5">
                <label className="text-xs font-medium text-gray-300">{isEn ? "Choose Pattern Vibe" : "প্যাটার্ন ক্যাটাগরি"}</label>
                <div className="space-y-2">
                  {[
                    "Neo-Tech Grid",
                    "Luxury Gold Grid",
                    "Abstract Wave",
                    "Textured Paper",
                    "Metallic Steel",
                    "Frosted Glass"
                  ].map((style) => (
                    <button
                      key={style}
                      onClick={() => setTextureStyle(style as any)}
                      className={`w-full p-2.5 rounded-xl border text-left text-xs transition-all flex items-center justify-between cursor-pointer ${
                        textureStyle === style
                          ? "bg-indigo-600/25 border-indigo-500 text-indigo-100"
                          : "bg-black/40 border-white/5 text-gray-400 hover:bg-white/5 hover:text-white"
                      }`}
                    >
                      <span>{style}</span>
                      <span className="text-[9px] bg-white/10 text-gray-300 px-1.5 py-0.5 rounded uppercase">Code Ready</span>
                    </button>
                  ))}
                </div>
              </div>

              <button
                onClick={handleGenerateTexture}
                className="w-full bg-indigo-600 hover:bg-indigo-5050 text-white font-semibold py-3 px-4 rounded-xl text-xs flex items-center justify-center gap-2 cursor-pointer transition-all"
              >
                <ImageIcon className="w-3.5 h-3.5" />
                <span>{isEn ? "Render Pattern Preview (Instant)" : "প্যাটার্ন প্রিভিউ রেন্ডার করুন"}</span>
              </button>
            </div>
          )}

          {/* 6. LOGO IDEA FORM */}
          {activeTool === "logo" && (
            <div className="space-y-4">
              <h3 className="text-sm font-semibold tracking-wider text-gray-300 uppercase flex items-center gap-2">
                <Award className="w-4 h-4 text-indigo-400" />
                <span>{isEn ? "Logo Concept Generator" : "লোগো আইডিয়া জেনারেটর"}</span>
              </h3>
              <p className="text-xs text-gray-400">
                {isEn ? "Input brand attributes and receive symbolic geometry suggestions, logo blueprints, and color guidelines." : "ব্র্যান্ড নাম দিয়ে অসাধারণ সিম্বলিক ও জ্যামিতিক লোগো মেকিং ফর্মুলা বের করুন।"}
              </p>

              <div className="space-y-1.5">
                <label className="text-xs font-medium text-gray-300">{isEn ? "Brand Name" : "ব্র্যান্ডের নাম"}</label>
                <input
                  type="text"
                  placeholder="e.g., Solas Financial"
                  value={logoCompany}
                  onChange={(e) => setLogoCompany(e.target.value)}
                  className="w-full bg-black/40 border border-white/15 rounded-xl p-3 text-xs text-white placeholder-gray-500 focus:outline-none focus:border-indigo-500 transition-all font-sans font-semibold"
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-medium text-gray-300">{isEn ? "Visual Elements & Similes" : "ভিজ্যুয়াল এলিমেন্টস"}</label>
                <input
                  type="text"
                  placeholder="e.g., stylized rising sun inside a hexagon"
                  value={logoConcept}
                  onChange={(e) => setLogoConcept(e.target.value)}
                  className="w-full bg-black/40 border border-white/15 rounded-xl p-3 text-xs text-white placeholder-gray-500 focus:outline-none focus:border-indigo-500 transition-all"
                />
              </div>

              <button
                onClick={handleGenerateLogo}
                disabled={loading}
                className="w-full bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 text-white font-semibold py-3 px-4 rounded-xl text-xs flex items-center justify-center gap-2 cursor-pointer transition-all"
              >
                <Award className="w-3.5 h-3.5" />
                <span>{loading ? "Forging Logos..." : (isEn ? "Synthesize Logo Blueprint (10 Credits)" : "লোগো আইডিয়া জেনারেট (১০ ক্রেডিট)")}</span>
              </button>
            </div>
          )}

          {/* 7. PORTFOLIO BUILDER FORM */}
          {activeTool === "portfolio" && (
            <div className="space-y-4">
              <h3 className="text-sm font-semibold tracking-wider text-gray-300 uppercase flex items-center gap-2">
                <Briefcase className="w-4 h-4 text-indigo-400" />
                <span>{isEn ? "Instant Portfolio Builder" : "পোর্টফোলিও বিল্ডার"}</span>
              </h3>
              <p className="text-xs text-gray-400">
                {isEn ? "Synthesize custom startup-ready biography and interactive design case studies for your potential clients." : "এক ক্লিকে ক্লায়েন্ট-উইন করার মতো কেস স্টাডি ও পার্সোনাল পোর্টফোলিও স্ক্রিপ্ট তৈরি করুন।"}
              </p>

              <div className="space-y-1.5">
                <label className="text-xs font-medium text-gray-300">{isEn ? "Your Profile Name" : "আপনার নাম"}</label>
                <input
                  type="text"
                  placeholder="e.g., Ahsan Kabir"
                  value={designerName}
                  onChange={(e) => setDesignerName(e.target.value)}
                  className="w-full bg-black/40 border border-white/15 rounded-xl p-3 text-xs text-white placeholder-gray-500 focus:outline-none focus:border-indigo-500 transition-all font-sans"
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-medium text-gray-300">{isEn ? "Your Primary Focus Class" : "ডিজাইন স্পেশালাইজেশন ক্যাটাগরি"}</label>
                <input
                  type="text"
                  placeholder="e.g., High CTR Thumbnails & Ad Creatives Designer"
                  value={personalNiche}
                  onChange={(e) => setPersonalNiche(e.target.value)}
                  className="w-full bg-black/40 border border-white/15 rounded-xl p-3 text-xs text-white placeholder-gray-500 focus:outline-none focus:border-indigo-500 transition-all"
                />
              </div>

              <button
                onClick={handleBuildPortfolio}
                disabled={loading}
                className="w-full bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 text-white font-semibold py-3 px-4 rounded-xl text-xs flex items-center justify-center gap-2 cursor-pointer transition-all"
              >
                <Briefcase className="w-3.5 h-3.5" />
                <span>{loading ? "Structuring Portfolio..." : (isEn ? "Build Personal Portfolio (15 Credits)" : "পোর্টফোলিও বিল্ড করুন (১৫ ক্রেডিট)")}</span>
              </button>
            </div>
          )}

        </div>

        {/* RIGHT COLUMN: Gorgeous Live Output Interactive Rendering */}
        <div className="lg:col-span-7 flex flex-col justify-between bg-black/60 border border-white/5 p-6 rounded-2xl min-h-[460px] relative">
          
          {loading && (
            <div className="absolute inset-0 bg-black/80 backdrop-blur-sm z-10 flex flex-col items-center justify-center space-y-4">
              <div className="w-10 h-10 border-4 border-indigo-500 border-t-transparent rounded-full animate-spin" />
              <p className="text-xs font-mono text-indigo-400 animate-pulse uppercase tracking-wider">
                {isEn ? "Gemini AI Synthesizing Creative Spectrum..." : "জেমিনি এআই আপনার রিকোয়ারমেন্ট এনালাইসিস করছে..."}
              </p>
            </div>
          )}

          <div className="space-y-6">
            <div className="flex items-center justify-between border-b border-white/5 pb-3">
              <span className="text-[10px] font-mono tracking-wider text-gray-500 uppercase flex items-center gap-1.5">
                <span className="w-1.5 h-1.5 bg-indigo-500 rounded-full animate-ping" />
                <span>{isEn ? "Interactive Studio Output Monitor" : "ইন্টারেক্টিভ স্টুডিও মনিটর"}</span>
              </span>
              <span className="text-[10px] bg-white/5 text-gray-400 border border-white/5 px-2 py-0.5 rounded font-mono">
                {activeTool.toUpperCase()} MODE
              </span>
            </div>

            {/* Render 1: MOODBOARD GENERATOR PREVIEW */}
            {activeTool === "moodboard" && moodboardResult && (
              <div className="space-y-6">
                <div>
                  <h4 className="text-lg font-semibold text-white tracking-tight">{moodboardResult.title}</h4>
                  <p className="text-xs text-gray-300 mt-1.5 leading-relaxed">{moodboardResult.concept}</p>
                </div>

                {/* Sub-bento color blocks */}
                <div className="space-y-2">
                  <span className="text-[10px] font-mono uppercase text-indigo-400 tracking-wider">Color Swatches</span>
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                    {moodboardResult.colors.map((c, i) => (
                      <div 
                        key={i} 
                        onClick={() => handleCopy(c.hex, `color_${i}`)}
                        className="group relative bg-[#131316] border border-white/5 p-2 rounded-xl cursor-copy hover:border-indigo-500/30 transition-all"
                      >
                        <div className="w-full h-10 rounded-lg transition-transform group-hover:scale-[1.02]" style={{ backgroundColor: c.hex }} />
                        <div className="mt-2">
                          <p className="text-[10px] font-semibold text-gray-200 truncate">{c.name}</p>
                          <p className="text-[9px] font-mono text-gray-500 flex items-center justify-between mt-0.5">
                            <span>{c.hex}</span>
                            <span className="text-indigo-400 uppercase text-[8px] opacity-0 group-hover:opacity-100 transition-opacity">Copy</span>
                          </p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Imagery Prompts */}
                <div className="space-y-2">
                  <span className="text-[10px] font-mono uppercase text-indigo-400 tracking-wider">Art Prompt Guides</span>
                  <div className="space-y-1.5">
                    {moodboardResult.imagery.map((img, i) => (
                      <div key={i} className="bg-white/5 p-2.5 border border-white/5 rounded-xl text-xs text-gray-300 flex justify-between items-center group">
                        <span className="truncate pr-4 italic">"{img}"</span>
                        <button 
                          onClick={() => handleCopy(img, `img_${i}`)}
                          className="text-xs text-indigo-400 hover:text-indigo-300 cursor-pointer shrink-0"
                        >
                          {copiedText === `img_${i}` ? "Copied" : <Copy className="w-3.5 h-3.5" />}
                        </button>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Fonts */}
                <div className="flex flex-wrap items-center justify-between gap-4 p-3 bg-indigo-950/20 border border-indigo-900/30 rounded-xl">
                  <div className="flex items-center gap-2">
                    <Palette className="w-4 h-4 text-indigo-400" />
                    <span className="text-xs font-medium text-gray-300">Recommended Typefaces:</span>
                    <span className="text-xs font-mono text-white bg-black/40 px-2 py-0.5 rounded border border-white/5">
                      {moodboardResult.keyFonts.join("  +  ")}
                    </span>
                  </div>
                  <div className="text-[11px] font-semibold text-indigo-400">
                    Vibe Score: {moodboardResult.vibeRating}%
                  </div>
                </div>
              </div>
            )}

            {/* Render 2: LAYOUT ARCHITECT PREVIEW */}
            {activeTool === "layout" && layoutResult && (
              <div className="space-y-6">
                <div className="flex justify-between items-start">
                  <div>
                    <h4 className="text-md font-semibold text-white tracking-wide">{layoutResult.blueprintTitle}</h4>
                    <p className="text-[11px] font-mono text-gray-400 mt-0.5">{layoutResult.dimensions}</p>
                  </div>
                  <div className="px-2.5 py-1 bg-indigo-500/10 border border-indigo-500/20 text-[10px] text-indigo-400 font-bold uppercase rounded-lg">
                    {layoutResult.marketingSlogan}
                  </div>
                </div>

                {/* Wireframe Interactive Visual Mockup */}
                <div className="border border-white/5 rounded-2xl bg-[#09090b] p-4">
                  <span className="text-[9px] font-mono text-gray-500 uppercase tracking-widest block mb-3">Live Structural Blueprint Preview</span>
                  <div className="grid grid-cols-12 gap-3 min-h-[160px] p-2 border border-white/5 rounded-xl bg-black/40">
                    {layoutResult.components.map((c, i) => (
                      <div 
                        key={i} 
                        className={`${c.flexRatio || "col-span-12"} ${c.bgStyle || "bg-white/5"} min-h-[80px] p-3 rounded-lg flex flex-col justify-between text-left transition-all hover:scale-[1.01]`}
                      >
                        <span className="text-[9px] font-bold tracking-wider uppercase text-indigo-300">{c.position}</span>
                        <p className="text-[10px] text-gray-400 leading-snug font-mono line-clamp-2 mt-2">{c.text}</p>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Details */}
                <div className="bg-[#121214] border border-white/5 p-4 rounded-xl space-y-2">
                  <p className="text-xs text-gray-300">
                    <strong className="text-indigo-400 font-semibold font-mono text-[10px] uppercase block mb-1">Typography Strategy:</strong>
                    {layoutResult.typographyGuide}
                  </p>
                  <p className="text-xs text-gray-300">
                    <strong className="text-indigo-400 font-semibold font-mono text-[10px] uppercase block mb-1">Implementation Advice:</strong>
                    {layoutResult.technicalImplementationTips}
                  </p>
                </div>
              </div>
            )}

            {/* Render 3: FONT PAIRING PREVIEW */}
            {activeTool === "fonts" && fontResult && (
              <div className="space-y-6">
                <div>
                  <h4 className="text-md font-semibold text-white">{fontResult.pairingName} Pairing</h4>
                  <p className="text-xs text-gray-400 mt-1">{fontResult.rationale}</p>
                </div>

                {/* Live Font Sample Playground */}
                <div className="bg-black/40 border border-white/5 rounded-2xl p-6 space-y-4 relative">
                  <span className="absolute top-2.5 right-2.5 text-[8px] font-mono text-emerald-400 bg-emerald-500/15 px-2 py-0.5 rounded uppercase">Interactive Playground</span>
                  
                  <div className="space-y-4">
                    <div>
                      <span className="text-[9px] font-mono text-indigo-400">Headline Font Suggestion: {fontResult.headlineFont}</span>
                      <h2 className={`text-white transition-all mt-1 ${fontResult.headlineStylingClass || "text-xl font-bold"}`}>
                        {userFontText || "Empowering Creative Freedom"}
                      </h2>
                    </div>

                    <div className="border-t border-white/5 pt-4">
                      <span className="text-[9px] font-mono text-indigo-400">Body Font Suggestion: {fontResult.bodyFont}</span>
                      <p className={`mt-1 text-gray-300 ${fontResult.bodyStylingClass || "text-sm"}`}>
                        {userFontText ? userFontText + ". " : ""}This is the body copy specification. It is balanced, legible, and optimized for reading long-term descriptions. Try typing in the inputs!
                      </p>
                    </div>
                  </div>
                </div>

                {/* CSS snippet Copy */}
                <div className="bg-[#18181b] border border-white/5 p-3.5 rounded-xl flex justify-between items-center">
                  <div className="font-mono text-xs text-gray-400 truncate">
                    font-family: "{fontResult.headlineFont}", "{fontResult.bodyFont}", sans-serif;
                  </div>
                  <button 
                    onClick={() => handleCopy(`/* Font Pairing CSS */\nh1 { font-family: '${fontResult.headlineFont}', serif; }\np { font-family: '${fontResult.bodyFont}', sans-serif; }`, "font_css")}
                    className="flex items-center gap-1.5 px-3 py-1.5 bg-indigo-600/20 text-indigo-300 hover:bg-indigo-650 rounded-lg text-xs font-semibold cursor-pointer transition-all"
                  >
                    <Copy className="w-3.5 h-3.5" />
                    <span>{copiedText === "font_css" ? "Copied" : "Copy CSS"}</span>
                  </button>
                </div>
              </div>
            )}

            {/* Render 4: DESIGN BRIEF PREVIEW */}
            {activeTool === "brief" && briefResult && (
              <div className="space-y-5">
                <div className="flex justify-between items-center border-b border-white/5 pb-3">
                  <h4 className="text-md font-semibold text-indigo-400">{briefResult.projectTitle}</h4>
                  <button 
                    onClick={() => handleCopy(JSON.stringify(briefResult, null, 2), "json_brief")}
                    className="text-xs text-indigo-400 hover:text-indigo-300 flex items-center gap-1 cursor-pointer"
                  >
                    <Copy className="w-3 h-3" />
                    <span>{copiedText === "json_brief" ? "Copied!" : "Copy Full JSON"}</span>
                  </button>
                </div>

                <div className="space-y-3 text-xs leading-relaxed max-h-[300px] overflow-y-auto pr-1">
                  <div>
                    <span className="font-bold text-gray-300 block">🎯 Strategic Objectives</span>
                    <p className="text-gray-400 mt-0.5">{briefResult.objective}</p>
                  </div>
                  
                  <div>
                    <span className="font-bold text-gray-300 block">👥 Target Demographics</span>
                    <p className="text-gray-400 mt-0.5">{briefResult.targetAudience}</p>
                  </div>

                  <div>
                    <span className="font-bold text-gray-300 block">🗣️ Brand Persona & Tone</span>
                    <p className="text-gray-400 mt-0.5">{briefResult.toneOfVoice}</p>
                  </div>

                  <div>
                    <span className="font-bold text-gray-300 block">📋 Complete Phase Milestones</span>
                    <p className="text-gray-400 mt-0.5">{briefResult.timelineEstimation}</p>
                  </div>

                  <div className="p-3 bg-white/5 border border-white/5 rounded-xl">
                    <span className="font-bold text-indigo-300 block text-[11px] mb-1">Competitor Strategy Loop</span>
                    <p className="text-gray-400 text-[11px]">{briefResult.competitorAnalysisSummary}</p>
                  </div>
                </div>
              </div>
            )}

            {/* Render 5: BACKGROUNDS & TEXTURE PREVIEW */}
            {activeTool === "bgtexture" && generatedTexture && (
              <div className="space-y-5">
                <div>
                  <h4 className="text-md font-semibold text-white">{generatedTexture.title}</h4>
                  <p className="text-xs text-gray-400 mt-0.5">{generatedTexture.promptExplanation}</p>
                </div>

                {/* Render Texture Div Live using style property */}
                <div 
                  className="w-full h-40 border border-white/5 rounded-2xl relative shadow-inner overflow-hidden flex items-center justify-center"
                  style={{ cssText: generatedTexture.cssCode }}
                >
                  <span className="bg-black/70 backdrop-blur border border-white/5 px-3 py-1.5 rounded-xl text-xs text-indigo-300 font-mono font-medium select-none shadow">
                    Interactive Grid Render
                  </span>
                </div>

                <div className="space-y-3">
                  <div>
                    <div className="flex justify-between items-center mb-1">
                      <span className="text-[9px] font-mono text-gray-500 uppercase">Tailwind / Inline CSS Code</span>
                      <button 
                        onClick={() => handleCopy(generatedTexture.cssCode, "tex_css")}
                        className="text-[10px] text-indigo-400 hover:text-indigo-300 font-mono cursor-pointer"
                      >
                        {copiedText === "tex_css" ? "Copied!" : "Copy CSS"}
                      </button>
                    </div>
                    <pre className="p-3 bg-[#0c0c0e] border border-white/5 rounded-xl text-[11px] font-mono text-indigo-400 overflow-x-auto">
                      {generatedTexture.cssCode}
                    </pre>
                  </div>

                  <div>
                    <div className="flex justify-between items-center mb-1">
                      <span className="text-[9px] font-mono text-gray-500 uppercase">SVG Vector Segment</span>
                      <button 
                        onClick={() => handleCopy(generatedTexture.svgMarkup, "tex_svg")}
                        className="text-[10px] text-indigo-400 hover:text-indigo-300 font-mono cursor-pointer"
                      >
                        {copiedText === "tex_svg" ? "Copied!" : "Copy SVG"}
                      </button>
                    </div>
                    <pre className="p-3 bg-[#0c0c0e] border border-white/5 rounded-xl text-[10px] font-mono text-indigo-400/80 overflow-x-auto truncate">
                      {generatedTexture.svgMarkup}
                    </pre>
                  </div>
                </div>
              </div>
            )}

            {/* Render 6: LOGO IDEA PREVIEW */}
            {activeTool === "logo" && logoResult && (
              <div className="space-y-5">
                <div>
                  <h4 className="text-md font-semibold text-white">Suggested Brand: {logoResult.suggestedName}</h4>
                </div>

                <div className="space-y-4">
                  <span className="text-[10px] font-mono uppercase text-indigo-400 tracking-wider">Concept Blueprint Options:</span>
                  
                  {logoResult.conceptualSketches.map((concept, idx) => (
                    <div key={idx} className="bg-white/5 border border-white/5 p-4 rounded-xl space-y-2 relative overflow-hidden">
                      <div className="absolute top-0 right-0 w-8 h-8 opacity-20 bg-indigo-500 rounded-bl-full" />
                      <h5 className="text-xs font-bold text-indigo-300 flex items-center gap-1.5">
                        <Award className="w-3.5 h-3.5 text-indigo-400" />
                        <span>Concept {idx + 1}: {concept.title}</span>
                      </h5>
                      <p className="text-xs text-gray-300 leading-normal">{concept.description}</p>
                      <p className="text-[11px] text-gray-400 italic">
                        <strong className="text-indigo-400/90 font-medium not-italic">Symbology Meaning: </strong> 
                        {concept.symbolMeaning}
                      </p>
                    </div>
                  ))}
                </div>

                <div className="p-3 bg-indigo-950/20 border border-indigo-900/40 rounded-xl">
                  <span className="text-[10px] font-mono uppercase text-indigo-300 block mb-1">Recommended Paint System</span>
                  <div className="flex flex-wrap gap-2">
                    {logoResult.recommendedColors.map((colStr, i) => (
                      <span key={i} className="text-[11px] bg-black/40 text-gray-300 px-2.5 py-1 rounded-lg border border-white/5 font-mono">
                        {colStr}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {/* Render 7: PORTFOLIO BUILDER PREVIEW */}
            {activeTool === "portfolio" && portfolioResult && (
              <div className="space-y-5">
                <div className="border border-indigo-500/20 bg-indigo-950/10 p-5 rounded-2xl space-y-4 relative overflow-hidden">
                  <div className="absolute -top-10 -right-10 w-24 h-24 bg-emerald-500/10 blur-[40px] pointer-events-none rounded-full" />
                  
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full bg-gradient-to-r from-indigo-500 to-purple-600 flex items-center justify-center font-bold text-white text-md">
                      {portfolioResult.profileName.substring(0, 2).toUpperCase()}
                    </div>
                    <div>
                      <h4 className="text-sm font-bold text-white uppercase tracking-tight">{portfolioResult.profileName}</h4>
                      <div className="flex flex-wrap gap-1 mt-1">
                        {portfolioResult.coreStack.map((tech, idx) => (
                          <span key={idx} className="text-[8px] uppercase tracking-wider bg-indigo-600/20 text-indigo-300 px-1.5 py-0.5 rounded-full border border-indigo-500/20 font-mono">
                            {tech}
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>

                  <div>
                    <h3 className="text-xs font-bold text-indigo-300 mt-2 italic">"{portfolioResult.headline}"</h3>
                    <p className="text-[11px] text-gray-300 mt-1.5 leading-relaxed">{portfolioResult.aboutText}</p>
                  </div>
                </div>

                {/* Case Study breakdown */}
                <div className="space-y-3">
                  <span className="text-[10px] font-mono uppercase text-indigo-400 tracking-wider">Highlight Case Studies (Automatic)</span>
                  
                  {portfolioResult.caseStudies.map((cs, idx) => (
                    <div key={idx} className="bg-black/40 border border-white/5 p-4 rounded-xl space-y-2">
                      <div className="flex justify-between items-start">
                        <div>
                          <span className="text-[9px] uppercase tracking-widest text-emerald-400 font-mono">{cs.client}</span>
                          <h5 className="text-xs font-bold text-white">{cs.title}</h5>
                        </div>
                        <span className="text-[10px] text-emerald-400 font-bold bg-emerald-500/10 px-2 py-0.5 rounded">
                          {cs.outputStat}
                        </span>
                      </div>
                      <p className="text-[11px] text-gray-400">
                        <strong className="text-gray-300">Challenge:</strong> {cs.problem}
                      </p>
                      <p className="text-[11px] text-gray-400">
                        <strong className="text-indigo-400">Design Victory:</strong> {cs.conceptSolution}
                      </p>
                    </div>
                  ))}
                </div>

                <button 
                  onClick={() => handleCopy(JSON.stringify(portfolioResult, null, 2), "port_code")}
                  className="w-full py-2.5 bg-indigo-600/10 hover:bg-indigo-600/25 border border-indigo-500/20 text-indigo-300 text-xs font-semibold cursor-pointer rounded-xl transition-all flex items-center justify-center gap-1.5"
                >
                  <ExternalLink className="w-3.5 h-3.5" />
                  <span>{copiedText === "port_code" ? "Copied" : "Copy Live Portfolio JSON Code"}</span>
                </button>
              </div>
            )}

          </div>

          <div className="border-t border-white/5 pt-4 text-center mt-6">
            <p className="text-[10px] text-gray-500 leading-normal">
              {isEn ? "All visual frameworks conform strictly to typography grids." : "সকল ফ্রেমওয়ার্ক আধুনিক রেস্পন্সিভ গ্রিড দ্বারা সুসজ্জিত।"}
            </p>
          </div>

        </div>

      </div>
    </div>
  );
}
