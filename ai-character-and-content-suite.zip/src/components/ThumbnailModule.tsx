/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import { TRANSLATIONS, LanguageCode } from "../lib/translations";
import { ThumbnailSpec } from "../types";
import { 
  Sparkles, RefreshCcw, Image, Play, Settings, Paintbrush, 
  HelpCircle, Copy, AlertTriangle, Layers, Layers3, MonitorPlay,
  Plus, Trash2, Check, Bookmark
} from "lucide-react";

export interface ResolutionPreset {
  id: string;
  name: string;
  aspectRatio: string; // "16:9" | "9:16" | "1:1" | "4:3" | "21:9"
  isHiFiExport: boolean;
  exportResolution?: "4k" | "8k";
  isDnaConsistent: boolean;
  isCustom?: boolean;
}

const BUILT_IN_PRESETS: ResolutionPreset[] = [
  { id: "yt-thumb", name: "YouTube Thumbnail", aspectRatio: "16:9", isHiFiExport: false, exportResolution: "4k", isDnaConsistent: true },
  { id: "ig-story", name: "Instagram Story / Reels", aspectRatio: "9:16", isHiFiExport: true, exportResolution: "4k", isDnaConsistent: true },
  { id: "yt-banner", name: "YouTube Banner", aspectRatio: "21:9", isHiFiExport: true, exportResolution: "8k", isDnaConsistent: true },
  { id: "ig-square", name: "Instagram Square Post", aspectRatio: "1:1", isHiFiExport: true, exportResolution: "4k", isDnaConsistent: true },
  { id: "pin-video", name: "Pinterest Video Pin", aspectRatio: "9:16", isHiFiExport: true, exportResolution: "8k", isDnaConsistent: true },
];

const ASPECT_RATIO_OPTIONS = ["16:9", "9:16", "1:1", "4:3", "21:9"];

interface ThumbnailModuleProps {
  lang: LanguageCode;
  credits: number;
  deductCredits: (qty: number, actionTitle: string) => boolean;
  onThumbnailGenerated: (thumb: ThumbnailSpec) => void;
  recentThumbnails: ThumbnailSpec[];
}

export default function ThumbnailModule({
  lang,
  credits,
  deductCredits,
  onThumbnailGenerated,
  recentThumbnails
}: ThumbnailModuleProps) {
  const t = TRANSLATIONS[lang];

  // Form states
  const [thumbTitle, setThumbTitle] = useState("");
  const [thumbSubtitle, setThumbSubtitle] = useState("");
  const [thumbStyle, setThumbStyle] = useState("Vaporwave / Retro");
  const [thumbSubject, setThumbSubject] = useState("");

  // New: High-Fidelity export engine states
  const [isHiFiExport, setIsHiFiExport] = useState(false);
  const [exportResolution, setExportResolution] = useState<"4k" | "8k">("4k");
  const [isDnaConsistent, setIsDnaConsistent] = useState(true);

  // Resolution Presets and Active aspect ratio state
  const [aspectRatio, setAspectRatio] = useState("16:9");
  
  const [presets, setPresets] = useState<ResolutionPreset[]>(() => {
    try {
      const custom = localStorage.getItem("ai_custom_resolution_presets");
      const parsedCustom = custom ? JSON.parse(custom) : [];
      return [...BUILT_IN_PRESETS, ...parsedCustom];
    } catch {
      return BUILT_IN_PRESETS;
    }
  });

  const [selectedPresetId, setSelectedPresetId] = useState<string>("yt-thumb");

  // Custom preset creation form states
  const [showCustomPresetForm, setShowCustomPresetForm] = useState(false);
  const [newPresetName, setNewPresetName] = useState("");
  const [newPresetAspect, setNewPresetAspect] = useState("16:9");
  const [newPresetHiFi, setNewPresetHiFi] = useState(true);
  const [newPresetRes, setNewPresetRes] = useState<"4k" | "8k">("4k");
  const [newPresetDna, setNewPresetDna] = useState(true);

  const handleSelectPreset = (p: ResolutionPreset) => {
    setSelectedPresetId(p.id);
    setAspectRatio(p.aspectRatio);
    setIsHiFiExport(p.isHiFiExport);
    if (p.isHiFiExport && p.exportResolution) {
      setExportResolution(p.exportResolution);
    }
    setIsDnaConsistent(p.isDnaConsistent);
  };

  const handleSaveCustomPreset = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newPresetName.trim()) return;

    const newPresetId = "custom_" + Date.now();
    const newPreset: ResolutionPreset = {
      id: newPresetId,
      name: newPresetName.trim(),
      aspectRatio: newPresetAspect,
      isHiFiExport: newPresetHiFi,
      exportResolution: newPresetHiFi ? newPresetRes : undefined,
      isDnaConsistent: newPresetDna,
      isCustom: true
    };

    try {
      const custom = localStorage.getItem("ai_custom_resolution_presets");
      const currentCustom = custom ? JSON.parse(custom) : [];
      const updatedCustom = [...currentCustom, newPreset];
      localStorage.setItem("ai_custom_resolution_presets", JSON.stringify(updatedCustom));
      setPresets([...BUILT_IN_PRESETS, ...updatedCustom]);
    } catch (err) {
      console.error("Failed to save custom preset to localStorage", err);
    }

    setSelectedPresetId(newPresetId);
    setAspectRatio(newPresetAspect);
    setIsHiFiExport(newPresetHiFi);
    if (newPresetHiFi) {
      setExportResolution(newPresetRes);
    }
    setIsDnaConsistent(newPresetDna);

    // Reset Form
    setNewPresetName("");
    setShowCustomPresetForm(false);
  };

  const handleDeletePreset = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    try {
      const custom = localStorage.getItem("ai_custom_resolution_presets");
      const currentCustom = custom ? JSON.parse(custom) : [];
      const updatedCustom = currentCustom.filter((p: any) => p.id !== id);
      localStorage.setItem("ai_custom_resolution_presets", JSON.stringify(updatedCustom));
      
      const newPresetList = [...BUILT_IN_PRESETS, ...updatedCustom];
      setPresets(newPresetList);
      
      if (selectedPresetId === id) {
        // Fallback to youtube preset
        handleSelectPreset(BUILT_IN_PRESETS[0]);
      }
    } catch (err) {
      console.error("Failed to delete custom preset", err);
    }
  };

  // Loading/Error states
  const [loading, setLoading] = useState(false);
  const [imageGenerating, setImageGenerating] = useState(false);
  const [errorMsg, setErrorMsg] = useState("");
  const [activeTab, setActiveTab] = useState<"create" | "view">("create");
  
  // Selected viewer
  const [selectedThumb, setSelectedThumb] = useState<ThumbnailSpec | null>(null);

  const handleGenerate = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg("");

    let cost = 10;
    if (isHiFiExport) {
      cost = exportResolution === "4k" ? 15 : 25;
    }
    
    if (credits < cost) {
      setErrorMsg(t.insufficientCredits);
      return;
    }

    setLoading(true);

    try {
      const response = await fetch("/api/thumbnail/generate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          title: thumbTitle.trim(),
          subtitle: thumbSubtitle.trim(),
          style: thumbStyle,
          focusSubject: thumbSubject.trim()
        }),
      });

      if (!response.ok) {
        throw new Error("Failed to design thumbnail layouts");
      }

      const rawLayout: ThumbnailSpec = await response.json();

      // Deduct credits on design success
      const deducted = deductCredits(cost, `Thumbnail Spec (${isHiFiExport ? exportResolution.toUpperCase() : 'Standard'}): ${rawLayout.title}`);
      if (!deducted) {
        setErrorMsg(t.insufficientCredits);
        setLoading(false);
        return;
      }

      const upgradedLayout: ThumbnailSpec = {
        ...rawLayout,
        isHiFiExport: isHiFiExport,
        exportResolution: isHiFiExport ? exportResolution : undefined,
        isDnaConsistent: isDnaConsistent,
        aspectRatio: aspectRatio
      };

      onThumbnailGenerated(upgradedLayout);
      setSelectedThumb(upgradedLayout);
      setActiveTab("view");

      // Clear inputs
      setThumbTitle("");
      setThumbSubtitle("");
      setThumbSubject("");
    } catch (err) {
      console.error(err);
      setErrorMsg("Failed to call AI Thumbnail layout engineer. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  const handlePaintBackground = async () => {
    if (!selectedThumb) return;
    setErrorMsg("");

    const cost = 20;
    if (credits < cost) {
      setErrorMsg(t.insufficientCredits);
      return;
    }

    setImageGenerating(true);

    try {
      const resp = await fetch("/api/generate-image", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ prompt: selectedThumb.generatedPrompt }),
      });

      const data = await resp.json();

      if (!resp.ok || !data.success) {
        throw new Error(data.message || data.error || "Failed to paint image asset");
      }

      // Deduct premium credits
      const deducted = deductCredits(cost, `Imagen Artwork: ${selectedThumb.title}`);
      if (!deducted) return;

      const updatedThumb = {
        ...selectedThumb,
        thumbnailBase64: data.image
      };

      setSelectedThumb(updatedThumb);
      onThumbnailGenerated(updatedThumb); // Sync inside history too
    } catch (err: any) {
      console.error(err);
      setErrorMsg(err.message || "Failed to call premium assets painting. Image APIs require active Paid API key.");
    } finally {
      setImageGenerating(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Tab navigation bar */}
      <div className="flex border-b border-white/5">
        <button
          onClick={() => setActiveTab("create")}
          id="tab-thumb-create"
          className={`px-5 py-3 text-xs font-semibold uppercase tracking-wider cursor-pointer transition-all ${
            activeTab === "create"
              ? "text-blue-400 border-b-2 border-blue-500"
              : "text-gray-400 hover:text-white"
          }`}
        >
          {lang === "en" ? "🎨 Design Layout" : "🎨 নতুন লেআউট তৈরি"}
        </button>
        <button
          onClick={() => {
            if (recentThumbnails.length > 0 && !selectedThumb) {
              setSelectedThumb(recentThumbnails[0]);
            }
            setActiveTab("view");
          }}
          id="tab-thumb-inspect"
          className={`px-5 py-3 text-xs font-semibold uppercase tracking-wider cursor-pointer transition-all ${
            activeTab === "view"
              ? "text-blue-400 border-b-2 border-blue-500"
              : "text-gray-400 hover:text-white"
          }`}
        >
          {lang === "en" ? `📺 Preview Studio (${recentThumbnails.length})` : `📺 ক্যানভাস স্টুডিও (${recentThumbnails.length})`}
        </button>
      </div>

      {loading && (
        <div className="bg-blue-900/5 border border-blue-500/20 p-12 rounded-2xl flex flex-col items-center justify-center space-y-4 animate-pulse">
          <div className="w-12 h-12 border-4 border-blue-500 border-t-transparent rounded-full animate-spin"></div>
          <div className="text-center">
            <h4 className="text-sm font-semibold text-blue-300">{t.thumbGenerating}</h4>
            <p className="text-xs text-slate-500 mt-1">AI laying color blueprints, typographic scale and contrast hierarchies...</p>
          </div>
        </div>
      )}

      {/* Creation Pane */}
      {!loading && activeTab === "create" && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          <div className="lg:col-span-7 bg-[#121212] border border-white/5 p-6 rounded-2xl space-y-5 text-left">
            <div>
              <h3 className="text-base font-display font-medium text-white flex items-center gap-2">
                <Paintbrush className="w-4 h-4 text-blue-400" />
                {t.thumbTitle}
              </h3>
              <p className="text-xs text-slate-400 mt-1 mt-1">
                {t.thumbSubtitle}
              </p>
            </div>

            {errorMsg && (
              <div id="thumb-error-alert" className="p-3.5 bg-rose-950/40 border border-rose-900/50 text-rose-300 rounded-xl flex items-start gap-2 text-xs">
                <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5" />
                <span>{errorMsg}</span>
              </div>
            )}

            <form onSubmit={handleGenerate} className="space-y-4 text-left">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold uppercase tracking-wider text-slate-400 mb-1.5">{t.thumbText}</label>
                  <input
                    type="text"
                    required
                    value={thumbTitle}
                    id="thumb-input-title"
                    onChange={(e) => setThumbTitle(e.target.value)}
                    placeholder={t.thumbTextPlaceholder}
                    className="w-full bg-[#0A0A0A] border border-white/5 focus:border-blue-550 rounded-xl py-2.5 px-3 text-xs text-white placeholder-slate-600 outline-none"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold uppercase tracking-wider text-slate-400 mb-1.5">{t.thumbSub}</label>
                  <input
                    type="text"
                    required
                    value={thumbSubtitle}
                    id="thumb-input-sub"
                    onChange={(e) => setThumbSubtitle(e.target.value)}
                    placeholder={t.thumbSubPlaceholder}
                    className="w-full bg-[#0A0A0A] border border-white/5 focus:border-blue-550 rounded-xl py-2.5 px-3 text-xs text-white placeholder-slate-600 outline-none"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold uppercase tracking-wider text-slate-400 mb-1.5">{t.thumbStyle}</label>
                  <select
                    value={thumbStyle}
                    id="thumb-input-style"
                    onChange={(e) => setThumbStyle(e.target.value)}
                    className="w-full bg-[#0A0A0A] border border-white/5 focus:border-blue-550 rounded-xl py-2.5 px-3 text-xs text-white outline-none"
                  >
                    <option value="Epic Cinematic Dark">{lang === "en" ? "Epic Cinematic Dark" : "এপিক সিনেমাটিক ডার্ক"}</option>
                    <option value="Vibrant Vaporwave Neon">{lang === "en" ? "Vibrant Vaporwave Neon" : "ভাইব্রেন্ট ভেপরওয়েভ নিয়ন"}</option>
                    <option value="Minimal Clean Editorial">{lang === "en" ? "Minimal Clean Editorial" : "মিনিমাল ক্লিন এডিটোরিয়াল"}</option>
                    <option value="Bright Cute Vlog">{lang === "en" ? "Bright Cute Vlog / Pastel" : "ব্রাইট কিউট ভ্লগ / প্যাস্টেল"}</option>
                    <option value="Retro Arcade Gaming">{lang === "en" ? "Retro Arcade Gaming" : "রেট্রো আর্কেড গেমিং"}</option>
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-semibold uppercase tracking-wider text-slate-400 mb-1.5">{t.thumbSubject}</label>
                  <input
                    type="text"
                    required
                    value={thumbSubject}
                    id="thumb-input-subject"
                    onChange={(e) => setThumbSubject(e.target.value)}
                    placeholder={t.thumbSubjectPlaceholder}
                    className="w-full bg-[#0A0A0A] border border-white/5 focus:border-blue-550 rounded-xl py-2.5 px-3 text-xs text-white placeholder-slate-600 outline-none"
                  />
                </div>
              </div>

              {/* High-Fidelity Export Toggle and Options */}
              <div className="border-t border-white/5 pt-4 space-y-4">
                <div className="flex items-center justify-between p-3 bg-[#0C0C0E] border border-white/5 rounded-xl">
                  <div className="space-y-0.5 text-left max-w-[75%]">
                    <span className="text-xs font-mono font-bold text-gray-200 block">
                      ✨ {lang === "en" ? "High-Fidelity Export Mode" : "হাই-ফিডেলিটি এক্সপোর্ট মোড"}
                    </span>
                    <p className="text-[10px] text-zinc-500 leading-normal">
                      {lang === "en"
                        ? "Synthesize layout at ultra-high resolution (4K UHD or 8K Master) and synchronize with computed designer guidelines."
                        : "৪কে বা ৮কে মাস্টার কোয়ালিটিতে ছবি জেনারেট করুন এবং ডিজাইন জেনোম গাইডের সাথে সামঞ্জস্য বজায় রাখুন।"}
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={() => setIsHiFiExport(!isHiFiExport)}
                    className={`w-9 h-5 rounded-full p-0.5 transition-colors cursor-pointer shrink-0 ${
                      isHiFiExport ? "bg-indigo-650" : "bg-zinc-800"
                    }`}
                  >
                    <div className={`w-4 h-4 rounded-full bg-white transition-transform ${isHiFiExport ? "translate-x-4" : "translate-x-0"}`} />
                  </button>
                </div>

                {isHiFiExport && (
                  <div className="grid grid-cols-2 gap-3 p-3 bg-[#0A0A0C] border border-white/5 rounded-xl text-left">
                    <div>
                      <label className="block text-[10px] font-mono font-bold uppercase tracking-wider text-zinc-400 mb-1.5 animate-pulse">
                        {lang === "en" ? "Master Resolution" : "টার্গেট রেজোলিউশন"}
                      </label>
                      <div className="grid grid-cols-2 gap-1.5">
                        <button
                          type="button"
                          onClick={() => setExportResolution("4k")}
                          className={`py-1.5 px-2.5 rounded-lg border text-xs font-mono transition-all text-center flex flex-col justify-center items-center cursor-pointer ${
                            exportResolution === "4k"
                              ? "bg-indigo-600/15 border-indigo-550 text-indigo-400 font-bold"
                              : "bg-black/40 border-white/5 text-gray-400 hover:text-gray-200 hover:bg-white/5"
                          }`}
                        >
                          <span>4K UHD</span>
                          <span className="text-[8px] text-zinc-550">🪙 15</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => setExportResolution("8k")}
                          className={`py-1.5 px-2.5 rounded-lg border text-xs font-mono transition-all text-center flex flex-col justify-center items-center cursor-pointer ${
                            exportResolution === "8k"
                              ? "bg-indigo-600/15 border-indigo-550 text-indigo-400 font-bold"
                              : "bg-black/40 border-white/5 text-gray-400 hover:text-gray-200 hover:bg-white/5"
                          }`}
                        >
                          <span>8K Master</span>
                          <span className="text-[8px] text-zinc-550">🪙 25</span>
                        </button>
                      </div>
                    </div>

                    <div>
                      <label className="block text-[10px] font-mono font-bold uppercase tracking-wider text-zinc-400 mb-1.5">
                        {lang === "en" ? "Apply DNA guidelines" : "ডিএনএ সেটআপ"}
                      </label>
                      <div className="flex items-center justify-between h-9 px-2 bg-black/40 border border-white/5 rounded-lg">
                        <span className="text-[10px] text-zinc-500 font-mono">
                          {isDnaConsistent ? (lang === "en" ? "DNA-Consistent" : "ডিএনএ সামঞ্জস্য") : (lang === "en" ? "Standard Style" : "স্বাভাবিক")}
                        </span>
                        <button
                          type="button"
                          onClick={() => setIsDnaConsistent(!isDnaConsistent)}
                          className={`w-7 h-4 rounded-full p-0.5 transition-colors cursor-pointer ${
                            isDnaConsistent ? "bg-emerald-600" : "bg-zinc-850"
                          }`}
                        >
                          <div className={`w-3 h-3 rounded-full bg-white transition-transform ${isDnaConsistent ? "translate-x-3" : "translate-x-0"}`} />
                        </button>
                      </div>
                    </div>
                  </div>
                )}
              </div>

              <button
                type="submit"
                id="thumb-btn-generate"
                className="w-full bg-blue-600 hover:bg-blue-500 active:scale-95 transition-all py-3 rounded-xl text-xs font-semibold text-white font-display flex items-center justify-center gap-2 cursor-pointer shadow-lg shadow-blue-500/10"
              >
                <Layers className="w-3.5 h-3.5" />
                <span>{t.generateThumbBtn}</span>
              </button>
            </form>
          </div>

          <div className="lg:col-span-5 bg-[#151515] border border-white/5 p-6 rounded-2xl flex flex-col justify-between text-left">
            <div className="space-y-4">
              <h4 className="text-xs font-bold uppercase text-slate-400 tracking-wider">
                {lang === "en" ? "Thumbnail Layout Metrics" : "সিটিআর বাড়ানোর হ্যাকস"}
              </h4>
              <p className="text-xs text-slate-300 leading-relaxed">
                {lang === "en" 
                  ? "YouTube looks for extreme visual readability. We combine primary complementary colors with distinct background prompts. The design generates clean separation layout structures optimized for mobile screens."
                  : "ইউটিউব থাম্বনেইলের রিডাবিলিটি বা স্পষ্টতা অনেক জরুরী। আমরা কালার স্কিম এবং ব্যাকগ্রাউন্ড প্রম্পটের ইউনিক কম্বিনেশন তৈরি করি যা বিশেষ করে মোবাইলে অতি স্পষ্ট থাম্বনেইল লেআউট তৈরি করতে সক্ষম।"}
              </p>

              <div className="space-y-1 bg-[#0A0A0A] p-3 border border-white/5 rounded-xl text-xs text-slate-400 font-mono">
                <div>💥 <strong>Ratio:</strong> 16:9 HD Broadcast</div>
                <div>🎨 <strong>Safety:</strong> High contrast border guides</div>
                <div>🏆 <strong>Standard:</strong> Web accessibility compliance</div>
              </div>
            </div>

            <div className="pt-6 border-t border-white/5 flex items-center gap-3">
              <div className="p-2 bg-blue-600/10 rounded-lg text-blue-400 font-mono text-xs border border-blue-500/25">
                🪙 {isHiFiExport ? (exportResolution === "4k" ? "15" : "25") : "10"}
              </div>
              <div className="text-left">
                <p className="text-xs font-semibold text-gray-300">
                  {lang === "en" 
                    ? `Deducted upon design (${isHiFiExport ? exportResolution.toUpperCase() + ' High-Fidelity' : 'Standard FHD'})` 
                    : `ডিজাইন সম্পন্ন হলে ${isHiFiExport ? (exportResolution === "4k" ? '১৫' : '২৫') : '১০'} ক্রেডিট কাটা হবে`}
                </p>
                <p className="text-[10px] text-gray-500">
                  {lang === "en" ? "No charge if execution aborts." : "সম্পন্ন না হলে কোনো টোকেন যাবে না।"}
                </p>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Canvas View Inspector */}
      {!loading && activeTab === "view" && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* History selection */}
          <div className="lg:col-span-4 bg-[#121212] border border-white/5 p-4 rounded-2xl space-y-3 max-h-[500px] overflow-y-auto">
            <h4 className="text-xs font-bold text-gray-400 uppercase tracking-widest px-2 mb-2">
              {lang === "en" ? "Recent Layout Specs" : "লেআউট হিস্টোরি"}
            </h4>
            {recentThumbnails.length === 0 ? (
              <p className="text-xs text-gray-500 text-center py-6">{t.noHistory}</p>
            ) : (
              recentThumbnails.map((h) => (
                <button
                  key={h.id}
                  onClick={() => setSelectedThumb(h)}
                  className={`w-full text-left p-3 rounded-xl border transition-all flex items-center justify-between cursor-pointer ${
                    selectedThumb?.id === h.id
                      ? "bg-[#151515] border-blue-500/80"
                      : "bg-[#0A0A0A] border-white/5 hover:bg-white/5"
                  }`}
                >
                  <div className="flex items-center gap-2">
                    <div 
                      className="w-8 h-5 rounded border border-white/10 font-mono text-[6px] shrink-0"
                      style={{ backgroundColor: h.primaryColor }}
                    />
                    <div className="truncate text-left min-w-0">
                      <h4 className="text-xs font-bold text-white truncate">{h.title}</h4>
                      <p className="text-[10px] text-gray-500 truncate">{h.style}</p>
                      
                      {/* Thumbnail high fidelity tags metadata display */}
                      <div className="flex flex-wrap gap-1.5 mt-1">
                        {h.isHiFiExport && (
                          <span className="text-[7.5px] font-mono font-bold bg-indigo-500/15 text-indigo-300 border border-indigo-500/25 px-1 py-0.5 rounded uppercase leading-none">
                            {h.exportResolution || "4K"}
                          </span>
                        )}
                        {h.isDnaConsistent && (
                          <span className="text-[7.5px] font-mono font-bold bg-emerald-500/15 text-emerald-300 border border-emerald-500/25 px-1 py-0.5 rounded uppercase leading-none">
                            DNA-Consistent
                          </span>
                        )}
                      </div>
                    </div>
                  </div>
                </button>
              ))
            )}
          </div>

          {/* Interactive Live Canvas Preview */}
          <div className="lg:col-span-8">
            {selectedThumb ? (
              <div className="space-y-6">
                <div>
                  <h4 className="text-xs uppercase font-bold text-gray-400 tracking-wider mb-3 text-left">
                    {t.thumbPreview}
                  </h4>

                  {/* 16:9 Styled Preview Canvas Card */}
                  <div 
                    className="w-full aspect-[16/9] bg-[#0A0A0A] rounded-2xl border-2 border-white/5 overflow-hidden relative shadow-2xl flex flex-col justify-between p-6 select-none group"
                    style={{
                      background: selectedThumb.thumbnailBase64 
                        ? `url(${selectedThumb.thumbnailBase64}) center/cover no-repeat` 
                        : `linear-gradient(135deg, ${selectedThumb.secondaryColor || '#0a0f1d'} 0%, #030712 50%, ${selectedThumb.primaryColor || '#6366f1'}40 100%)`
                    }}
                  >
                    {/* Shadow layer for readability if background exists */}
                    {selectedThumb.thumbnailBase64 && (
                      <div className="absolute inset-0 bg-[#0A0A0A]/50 backdrop-blur-[1px] z-0" />
                    )}

                    {/* Gradient spotlight overlay */}
                    <div className="absolute inset-0 bg-radial-gradient from-transparent to-black/80 pointer-events-none z-0" />

                    {/* Top items: LIVE sticker / badge */}
                    <div className="flex justify-between items-center z-10">
                      <div className="flex items-center gap-1 bg-red-650 text-white font-mono text-[10px] uppercase px-3 py-1 font-bold rounded-md shadow-lg shadow-red-500/20">
                        <span className="w-1.5 h-1.5 rounded-full bg-white leading-none"></span>
                        <span>LIVE</span>
                      </div>

                      {/* Display elements badge sticker */}
                      <div className="flex items-center gap-2">
                        {selectedThumb.overlayElements.map((el, index) => (
                          <span 
                            key={index}
                            className="text-[9px] bg-[#0A0A0A]/80 text-blue-400 font-mono px-2.5 py-1 border border-white/5 rounded-md uppercase"
                          >
                            {el}
                          </span>
                        ))}
                      </div>
                    </div>

                    {/* Left text layout blocks VS Right vector subject representation */}
                    <div className="grid grid-cols-12 gap-3 items-end z-10 w-full">
                      {/* Left Typography Block */}
                      <div className="col-span-8 space-y-2 text-left">
                        {/* Subtitle Accent */}
                        <span 
                          className="inline-block text-[10px] px-2.5 py-1 text-slate-900 font-bold uppercase rounded-md tracking-widest"
                          style={{ backgroundColor: selectedThumb.primaryColor }}
                        >
                          {selectedThumb.subtitle}
                        </span>

                        {/* Heading Title (Extremely high-fidelity typography styling) */}
                        <h1 className="text-xl md:text-3xl font-display font-bold leading-tight uppercase tracking-tight text-white drop-shadow-[0_4px_12px_rgba(0,0,0,0.8)] decoration-clone">
                          {selectedThumb.title}
                        </h1>
                      </div>

                      {/* Right procedural graphics placeholder representing searchSubject */}
                      <div className="col-span-4 flex flex-col items-center justify-end pb-1.5">
                        {!selectedThumb.thumbnailBase64 && (
                          <div className="w-14 h-14 rounded-full bg-blue-500/10 border border-blue-500/35 backdrop-blur-md flex items-center justify-center relative shadow-lg shadow-blue-500/10 animate-pulse">
                            <MonitorPlay className="w-6 h-6 text-blue-400" />
                            <div className="absolute inset-0 rounded-full border border-blue-500/30 animate-ping opacity-30" />
                          </div>
                        )}
                      </div>
                    </div>

                    {/* Lower Status Info overlay */}
                    <div className="absolute bottom-2 right-3 z-10 bg-black/60 backdrop-blur-md px-2 py-0.5 border border-white/5 rounded text-[8px] text-gray-400 font-mono">
                      <span>CTR Blueprints V1</span>
                    </div>
                  </div>
                </div>

                {errorMsg && (
                  <div className="p-3 bg-rose-955/40 border border-rose-900/50 text-rose-300 rounded-xl text-xs flex items-center gap-2">
                    <AlertTriangle className="w-4 h-4" />
                    <span>{errorMsg}</span>
                  </div>
                )}

                {/* Properties specifications */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-left">
                  <div className="bg-[#121212] border border-white/5 p-4 rounded-xl space-y-2">
                    <h5 className="text-xs font-bold uppercase text-gray-400">
                      {t.thumbProperties}
                    </h5>
                    
                    <div className="space-y-1.5 text-xs text-gray-300 font-mono">
                      <div><span className="text-gray-500">STYLE VIBE:</span> {selectedThumb.style}</div>
                      <div><span className="text-gray-500">STRUCTURE:</span> {selectedThumb.layoutType}</div>
                      <div><span className="text-gray-500">PRIMARY HEX:</span> <span className="underline" style={{ color: selectedThumb.primaryColor }}>{selectedThumb.primaryColor}</span></div>
                      <div><span className="text-gray-500">BACKDROP HEX:</span> <span className="underline" style={{ color: selectedThumb.secondaryColor }}>{selectedThumb.secondaryColor}</span></div>
                      <div><span className="text-gray-500">ACCESSIBILITY:</span> {selectedThumb.contrastRatio}</div>
                      
                      {/* High-fidelity specific layout data metadata items */}
                      {selectedThumb.isHiFiExport && (
                        <div>
                          <span className="text-gray-500">RESOLUTION:</span>{" "}
                          <span className="text-indigo-400 font-bold bg-indigo-500/10 border border-indigo-500/25 px-1 py-0.5 rounded text-[10px]">
                            {selectedThumb.exportResolution?.toUpperCase()} DYNAMIC EXP
                          </span>
                        </div>
                      )}
                      <div>
                        <span className="text-gray-500">CONSISTENCY:</span>{" "}
                        {selectedThumb.isDnaConsistent ? (
                          <span className="text-emerald-400 font-bold bg-emerald-500/10 border border-emerald-500/25 px-1 py-0.5 rounded text-[10px] inline-flex items-center gap-1 font-mono uppercase">
                            ● DNA-CONSISTENT
                          </span>
                        ) : (
                          <span className="text-gray-400 font-mono">STANDARD</span>
                        )}
                      </div>
                    </div>
                  </div>

                  <div className="bg-[#151515] border border-white/5 p-4 rounded-xl flex flex-col justify-between">
                    <div className="space-y-1.5 text-left">
                      <h5 className="text-xs font-bold uppercase text-gray-450">
                        {lang === "en" ? "Imagen Backdrop painter" : "ব্যাকগ্রাউন্ড পেইন্ট করুন"}
                      </h5>
                      <p className="text-[11px] text-gray-400 leading-relaxed">
                        {lang === "en" 
                          ? "Run premium diffusion model to paint the backdrop image for your video focus subject."
                          : "প্রিমিয়াম ইমেজেন মডেল দিয়ে ক্যানভাসে সামঞ্জস্যপূর্ণ ব্যাকগ্রাউন্ড ছবি তৈরি করুন।"}
                      </p>
                    </div>

                    <button
                      onClick={handlePaintBackground}
                      id="thumb-btn-paint"
                      disabled={imageGenerating}
                      className="bg-blue-600 hover:bg-blue-500 font-semibold active:scale-95 text-white rounded-xl py-2 px-3 text-[10px] uppercase font-mono tracking-wider transition-all flex items-center justify-center gap-1.5 cursor-pointer disabled:opacity-50 mt-3"
                    >
                      {imageGenerating ? (
                        <>
                          <RefreshCcw className="w-3.5 h-3.5 animate-spin text-white" />
                          <span>Painting backdrop...</span>
                        </>
                      ) : (
                        <>
                          <Image className="w-3.5 h-3.5 text-white" />
                          <span>Generate Background (🪙 20)</span>
                        </>
                      )}
                    </button>
                  </div>
                </div>

                {/* AI Prompts detailed */}
                <div className="bg-[#121212] p-4 rounded-xl text-left border border-white/5 space-y-2">
                  <h5 className="text-xs font-bold uppercase text-gray-450">
                    {t.thumbArtPrompt}
                  </h5>
                  <p className="text-[11px] text-gray-350 font-mono bg-[#0A0A0A] p-3 rounded-lg border border-white/5 break-words select-all">
                    {selectedThumb.generatedPrompt}
                  </p>
                </div>
              </div>
            ) : (
              <div className="bg-[#121212] border border-white/5 p-16 rounded-2xl text-center space-y-3">
                <MonitorPlay className="w-10 h-10 text-gray-650 mx-auto" />
                <h4 className="text-xs uppercase font-bold text-gray-400 tracking-wide">
                  {lang === "en" ? "Studio Preview Empty" : "প্রিভিউ স্টুডিও খালি"}
                </h4>
                <p className="text-xs text-gray-500 max-w-sm mx-auto">
                  {lang === "en" ? "Create visual blueprints by submitting configurations in the 'Design Layout' panel." : "লেআউট প্যানেলে কনফিগারেশন সাবমিট করে ভিজ্যুয়াল ব্লুপ্রিন্ট তৈরি করুন।"}
                </p>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
