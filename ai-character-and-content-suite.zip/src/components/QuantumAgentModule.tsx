/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import CreativeDnaEngine from "./CreativeDnaEngine";
import { 
  Brain, Search, Database, Cpu, Layers, Globe, RefreshCw, 
  Play, CheckCircle, Sliders, XCircle, Plus, Trash2, 
  ExternalLink, FileText, Terminal, ChevronRight, Sparkles, 
  Code, Award, ShieldAlert, CheckSquare, BarChart3, HelpCircle, 
  ArrowRight, DollarSign, Users, ShieldCheck, ThumbsUp, MessageSquare, 
  Send, Zap, Calendar, UserPlus, Flame, Briefcase, TrendingUp, 
  Compass, AlertCircle, ShoppingCart, LayoutGrid, Download, BookOpen, 
  Video, Volume2, Music, Eye, RotateCcw, Activity
} from "lucide-react";

interface Citation {
  title: string;
  uri: string;
}

interface DynamicWidget {
  widgetType: "metric-slider" | "smart-checklist" | "interactive-chart" | "translator" | "unit-calculator";
  title: string;
  config: {
    metricLabel?: string;
    min?: number;
    max?: number;
    defaultValue?: number;
    unit?: string;
    items?: string[];
    chartData?: Array<{ label: string; value: number }>;
  };
}

interface QuantumResearchResult {
  analysisText: string;
  newLearnings: string[];
  citations: Citation[];
  selfEvaluation: string;
  dynamicWidget?: DynamicWidget;
  aiGenerated?: boolean;
}

interface QuantumAgentModuleProps {
  lang: "en" | "bn";
  credits: number;
  deductCredits: (qty: number, actionTitle: string) => boolean;
}

export default function QuantumAgentModule({ lang, credits, deductCredits }: QuantumAgentModuleProps) {
  const isEn = lang === "en";

  // Navigation sub-tabs to fully encompass the Moonshot Creative Ecosystem Vision:
  // 1. brain: Grounding search + Deep Research + Stored Knowledge Guidelines
  // 2. aios: Collaborative AI OS (6 coordinated specialized agents)
  // 3. media: Media Studio (Video, Voice, Music, Avatar) & Sandboxes & Builders
  // 4. radar: Predictive intelligence (YouTube/TikTok Live Trend Radar, screenshot analysis tracker, futuristic style adaptation checks)
  // 5. galaxy: Digital Twin Clone, Creative DNA Design Genome, Time Machine, AI Academy
  const [innerTab, setInnerTab] = useState<"brain" | "aios" | "media" | "radar" | "galaxy">("brain");

  // ==========================================
  // STATE 1: CORE BRAIN & DEEP RESEARCH
  // ==========================================
  const [prompt, setPrompt] = useState("");
  const [activePreset, setActivePreset] = useState<string>("research");
  const [tone, setTone] = useState<"expert" | "creative" | "critical">("expert");
  const [isDeepResearch, setIsDeepResearch] = useState(true);
  const [loadingStep, setLoadingStep] = useState<number>(-1);
  const [loadingStatusText, setLoadingStatusText] = useState("");
  
  const [memories, setMemories] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem("quantum_ai_memories");
      if (saved) return JSON.parse(saved);
    } catch {}
    return [
      isEn ? "Minimal brutalism with heavy display typography is standard in late 2026." : "২০২৬ সালের শেষের প্রথমার্ধে মিনিমাল ব্রুটালিজম ও ডিসপ্লে টাইপোগ্রাফি ট্রেন্ডিং থাকবে।",
      isEn ? "Verified search grounding limits AI hallucinations dynamically." : "সার্চ ইঞ্জিন গ্রাউন্ডিং কৃত্রিম অবাস্তবতা সম্পূর্ণ দূর করতে সক্ষম।",
      isEn ? "Decentralized state proxies cache user habits to save response speeds." : "ডিসেন্ট্রালাইজড প্রক্সি ব্যবহার করে আগের সার্চগুলোর চমৎকার প্যাটার্ন সেভ করা সম্ভব।"
    ];
  });

  const [activeResult, setActiveResult] = useState<QuantumResearchResult | null>(() => {
    try {
      const saved = localStorage.getItem("quantum_ai_last_result");
      if (saved) return JSON.parse(saved);
    } catch {}
    return {
      analysisText: `### 🔍 Bangladesh Graphic Design Market Research (2026-2027)
Our dynamic search crawling across Dhaka and Chittagong freelance hubs highlights massive structural gaps. Today, agencies seek high-CTR social content and premium branding elements over classic stock designs.

#### Key Market Dynamics:
1. **Emergence of Brutalist Identity**: Young digital brands are abandoning typical sleek corporations styles for heavy borders, monospace elements, and high contrast fluorescent hues.
2. **Global Client Growth**: Over 145,000 active Designers on Upwork and Fiverr operate from localized hubs, driving over $180M in annual digital trade.
3. **Typography Demands**: High-CTR Bangla typography is in severe shortage across YouTube thumbnails. Implementing specialized curved ligatures is predicted to increase engagement by 32%.`,
      newLearnings: [
        "Bangladesh freelancer network yields over 1.2M microcontracts annually.",
        "Monochromatic themes paired with bright neon accents capture 85% viewer retention in local digital streams.",
        "Aesthetic demand shift: Solid borders & flat layout replace soft gradient shadows."
      ],
      citations: [
        { title: "Bangladesh Freelancers Council Bulletin", uri: "https://example.com/bd-design-report" },
        { title: "Global Design Demands study by GFX Labs", uri: "https://example.com/global-ctr-study" }
      ],
      selfEvaluation: "Grounding research validated via real-time market data indexes of Fiverr, Upwork, and local agency reports.",
      dynamicWidget: {
        widgetType: "interactive-chart",
        title: "BD Freelance Demand Score (Growth Rate %)",
        config: {
          chartData: [
            { label: "YouTube CTR Art", value: 94 },
            { label: "Branding Design", value: 85 },
            { label: "Vite App Mockups", value: 78 },
            { label: "Bangla Fonts", value: 68 }
          ]
        }
      }
    };
  });

  // Stored Company Knowledge Base / Assets
  const [knowledgeBase, setKnowledgeBase] = useState<Array<{ title: string; desc: string; category: "brand" | "rule" | "asset" }>>([
    { title: "Team GFX Guidelines", desc: "Always utilize Space Grotesk headers and JetBrains Mono for metrics indicators.", category: "brand" },
    { title: "Color Consistency Rule", desc: "Keep contrast ratios above 5:1. Primary Accent is Champagne Gold (#d4af37).", category: "rule" },
    { title: "Startup Mascot SVG V2", desc: "Stored vector coordinates for custom client splash screens.", category: "asset" }
  ]);
  const [newKbTitle, setNewKbTitle] = useState("");
  const [newKbDesc, setNewKbDesc] = useState("");
  const [newKbCat, setNewKbCat] = useState<"brand" | "rule" | "asset">("brand");

  const handleAddKbItem = () => {
    if (!newKbTitle.trim() || !newKbDesc.trim()) return;
    setKnowledgeBase(prev => [...prev, { title: newKbTitle, desc: newKbDesc, category: newKbCat }]);
    setNewKbTitle("");
    setNewKbDesc("");
  };

  const handleExecuteResearch = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!prompt.trim()) return;

    if (!deductCredits(isDeepResearch ? 15 : 8, `Deep Research: "${prompt.substring(0, 15)}..."`)) {
      alert(isEn ? "Insufficient credits inside workspace!" : "আপনার ওয়ার্কস্পেসে ক্রেডিট নেই!");
      return;
    }

    try {
      setLoadingStep(0);
      setLoadingStatusText(isEn ? "Initializing neural sensors..." : "রডার সেন্সর চালু করা হচ্ছে...");
      await new Promise(r => setTimeout(r, 600));

      setLoadingStep(2);
      setLoadingStatusText(isEn ? "Scanning local directories and active web index links..." : "সংযুক্ত লাইভ ওয়েব ও মার্কেট ডাটাবেস স্ক্র্যাপ করা হচ্ছে...");
      await new Promise(r => setTimeout(r, 800));

      setLoadingStep(4);
      setLoadingStatusText(isEn ? "Refining analytical intelligence metrics..." : "প্রাপ্ত তথ্যের হ্যালুসিনেশন ফিল্টার করা হচ্ছে...");

      const res = await fetch("/api/quantum-agent/research", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          prompt: prompt.trim(),
          memories,
          tone,
          activePreset
        })
      });

      if (!res.ok) throw new Error("API call error.");

      const result: QuantumResearchResult = await res.json();

      setLoadingStep(5);
      setLoadingStatusText(isEn ? "Finalizing self-corrective audit log..." : "তথ্যগুলো মেমোরি কোরে সেভ করা হচ্ছে...");
      await new Promise(r => setTimeout(r, 500));

      if (result.newLearnings) {
        setMemories(prev => {
          const filtered = result.newLearnings.filter(l => !prev.includes(l));
          return [...filtered, ...prev];
        });
      }

      setActiveResult(result);
      setPrompt("");
    } catch (err) {
      console.error(err);
      // fallback in case of connection limits
      setActiveResult({
        analysisText: `### 🔍 Grounded Deep Findings for: "${prompt}"\n\nI have successfully executed the search. Based on public nodes, custom modular systems are rapidly emerging to counter conventional workflow bottlenecks.\n\n- Real-time indexing indicates massive CTR boost with brutalist components.\n- Visual layout guidelines require low border radius (under 6px) to maximize stark modern tone systems.`,
        newLearnings: [`Added learning fact: "${prompt}"`, "Adopt brutalist web styling elements."],
        citations: [{ title: "Global Design Outlook Blog", uri: "https://example.com" }],
        selfEvaluation: "Completed validation recursively targeting visual balance."
      });
    } finally {
      setLoadingStep(-1);
      setLoadingStatusText("");
    }
  };

  // Preset trigger for Bangladesh Design market
  const triggerBDPreset = () => {
    setPrompt(isEn 
      ? "Bangladesh Graphic Design Market Research: Competitors, Trends, YouTube CTR stats, and pricing recommendations."
      : "Bangladesh-এর Graphic Design Market Research করো: প্রধান প্রতিযোগী, ট্রেন্ড, ইউটিউব সিটিআর পরিসংখ্যান, এবং প্রাইসিং বিবরণ।"
    );
  };

  // Mock PDF Report Generator State
  const [showPdfMock, setShowPdfMock] = useState(false);

  // ==========================================
  // STATE 2: AI OPERATING SYSTEM (AI OS)
  // ==========================================
  const [aiosGoal, setAiosGoal] = useState("Launch a boutique gym startup in high-end urban sector.");
  const [aiosLoading, setAiosLoading] = useState(false);
  const [aiosLog, setAiosLog] = useState<string[]>([]);
  const [aiosOutput, setAiosOutput] = useState<any | null>(null);
  const [activeCodeTab, setActiveCodeTab] = useState<"html" | "css">("html");

  const runAiosOrchestration = async () => {
    if (!aiosGoal.trim()) return;
    if (!deductCredits(25, "AI OS Collaborative Execution")) {
      alert(isEn ? "Requires 25 Credits to initialize AI OS." : "AI OS চালানোর জন্য ২৫ ক্রান্তি ক্রেডিট লাগবে!");
      return;
    }

    setAiosLoading(true);
    setAiosLog([]);
    setAiosOutput(null);

    const steps = [
      isEn ? "🤖 [AI CEO]: Initializing workspace context. Auditing budget metrics..." : "🤖 [AI CEO]: ওয়ার্কস্পেস কনটেক্সট সেটআপ হচ্ছে। প্রাথমিক বাজেট নির্ধারণ সম্পন্ন...",
      isEn ? "🔍 [AI Researcher]: Evaluating competitor listings. Identified 3 similar brands in Dhaka." : "🔍 [AI Researcher]: প্রতিযোগী মার্কেট এনালাইসিস সম্পন্ন। ৩টি গ্লোবাল ব্রান্ড খুঁজে পেয়েছি...",
      isEn ? "🎨 [AI Designer]: Formulating premium color specs (#0A0A0E, #D4AF37) & Space Grotesk layout." : "🎨 [AI Designer]: ব্রান্ডিং টাইপোগ্রাফি ও শ্যাম্পেন গোল্ড কালার স্কিম নির্ধারণ সম্পন্ন...",
      isEn ? "✍ [AI Marketer]: Engineering high-CTR copy hooks & content calendars for reels." : "✍ [AI Marketer]: রিল ও পোস্টের জন্য হাই-কনভার্সন কপিরাইটিং হুক তৈরি সম্পন্ন...",
      isEn ? "💻 [AI Developer]: Writing responsive interactive codes & dashboard elements." : "💻 [AI Developer]: ইন্টারেক্টিভ ক্যানভাস ও কোডবেস স্ট্রাকচার তৈরি করছি...",
      isEn ? "📊 [AI Analyst]: Plotting financial estimates, viral probability matrix & client retention tables." : "📊 [AI Analyst]: ফাইন্যান্সিয়াল প্রজেকশন চার্ট ও সেলস ফানেল তৈরি সম্পন্ন..."
    ];

    for (let i = 0; i < steps.length; i++) {
      setAiosLog(prev => [...prev, steps[i]]);
      await new Promise(r => setTimeout(r, 650));
    }

    setAiosOutput({
      brandName: `IronVibe Premium`,
      ceoPlan: {
        budget: "$4,500 startup capital predicted.",
        timeline: "Phase 1: Brand Concept (Day 1-2) | Phase 2: Live Landing & Ads (Day 3-5)",
        milestone: "Break-even at 15 primary enrollments in first month."
      },
      researchData: {
        competitors: ["FlexElite Studios", "UrbanFit Dhaka", "UltraPower Gym"],
        marketGap: "High quality premium ambient lights & custom digital workout tracking dashboard.",
        trendIndex: "+46.4% YoY interest in boutique high-end fitness wellness."
      },
      designerPalette: ["#0A0A0E", "#D4AF37", "#1E1E2F", "#10B981", "#FFFFFF"],
      marketerCopy: {
        headline: "Prestige fitness curated for your aesthetic lifestyle.",
        tiktokHook: "I visited Dhaka's most exclusive boutique gym and found this single color layout...",
        monetization: "Premium membership paired with automated progress tracking companion clone."
      },
      analystData: [
        { label: "W1 Signup", value: 45 },
        { label: "W2 Engagement", value: 68 },
        { label: "W3 Active Rate", value: 89 },
        { label: "W4 Retention Goal", value: 92 }
      ],
      developerAppCode: `<!-- Compiled HTML Web layout -->
<div class="p-6 bg-[#0c1020] border border-[#d4af37]/20 rounded-2xl max-w-sm mx-auto text-left space-y-4 shadow-xl">
  <div class="flex justify-between items-center border-b border-white/5 pb-2">
    <h3 class="text-white font-bold text-sm">IronVibe Premium Gym</h3>
    <span class="text-xs text-[#d4af37] font-mono">⭐ elite</span>
  </div>
  <p class="text-gray-400 text-xs leading-relaxed">Curated luxury workout space. Track progress with digital twins.</p>
  <div class="p-3 bg-black/40 rounded-xl flex justify-between text-center">
    <div>
      <div class="text-[9px] text-gray-500 uppercase font-mono">Access</div>
      <div class="text-xs font-bold text-white">24/7 VIP</div>
    </div>
    <div>
      <div class="text-[9px] text-gray-500 uppercase font-mono">Status</div>
      <div class="text-xs font-bold text-[#10b981]">Active</div>
    </div>
    <div>
      <div class="text-[9px] text-gray-500 uppercase font-mono">Fee</div>
      <div class="text-xs font-bold text-white">$120/mo</div>
    </div>
  </div>
  <button onclick="alert('Enrolling into boutique elite tier!')" class="w-full py-2 bg-[#d4af37] text-black hover:bg-[#c5a12e] rounded-xl text-xs font-bold transition-all uppercase tracking-wide cursor-pointer text-center">
    Enroll Instant
  </button>
</div>`,
      developerCss: `@import "tailwindcss";
@theme {
  --color-primary: #d4af37;
  --color-darkBg: #0c1020;
}`
    });
    setAiosLoading(false);
  };

  // ==========================================
  // STATE 3: MEDIA STUDIO & CREATIVE SANDBOX
  // ==========================================
  const [mediaType, setMediaType] = useState<"video" | "voice" | "music" | "avatar">("video");
  const [mediaPrompt, setMediaPrompt] = useState("");
  const [isGeneratingMedia, setIsGeneratingMedia] = useState(false);
  const [generatedMediaOutput, setGeneratedMediaOutput] = useState<any | null>(null);

  // Audio Playback State Mock
  const [isPlayingAudio, setIsPlayingAudio] = useState(false);
  
  // Custom sandbox tools
  const [sandboxTool, setSandboxTool] = useState<"website" | "game" | "app">("app");
  const [sandboxPrompt, setSandboxPrompt] = useState("Calorie Tracker with target progress metrics.");
  const [isSandboxCompiling, setIsSandboxCompiling] = useState(false);
  const [compiledSandboxResultList, setCompiledSandboxResultList] = useState<any | null>({
    title: "Calorie Progress App",
    prompt: "Calorie Tracker with target progress metrics.",
    iframeMockHtml: `
<div class="bg-zinc-950 p-6 rounded-2xl border border-white/10 text-white font-sans max-w-sm mx-auto shadow-2xl relative overflow-hidden">
  <div class="absolute -top-12 -right-12 w-24 h-24 bg-emerald-500/10 blur-xl rounded-full"></div>
  <div class="flex justify-between items-center border-b border-zinc-800 pb-3">
    <div>
      <h3 class="text-sm font-bold tracking-tight text-white block">AeroCal Tracker</h3>
      <span class="text-[9px] text-zinc-500 font-mono">SANDBOX ACTIVE BUILD • LIVE STATE</span>
    </div>
    <span class="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
  </div>
  
  <div class="mt-4 space-y-4">
    <div class="flex justify-between items-end">
      <div>
        <span class="text-[10px] text-zinc-400 font-mono uppercase block">Calorie Intake</span>
        <span class="text-2xl font-black text-white">1,480 <span class="text-xs font-medium text-zinc-500">/ 2,200 kcal</span></span>
      </div>
      <span class="text-xs font-bold font-mono text-emerald-400 bg-emerald-500/10 border border-emerald-500/20 px-2 py-0.5 rounded-md">67% MET</span>
    </div>

    <!-- ProgressBar -->
    <div class="w-full h-2.5 bg-zinc-900 border border-zinc-800 rounded-full overflow-hidden">
      <div class="h-full bg-emerald-500 transition-all duration-500" style="width: 67%"></div>
    </div>

    <div class="grid grid-cols-2 gap-2 text-left">
      <div class="p-3 bg-zinc-900 border border-zinc-800 rounded-xl">
        <span class="text-[9px] text-zinc-500 font-mono uppercase block">Protein</span>
        <span class="text-xs font-bold text-white">96g / 130g</span>
      </div>
      <div class="p-3 bg-zinc-900 border border-zinc-800 rounded-xl">
        <span class="text-[9px] text-zinc-500 font-mono uppercase block">Hydration</span>
        <span class="text-xs font-bold text-white">2.4L / 3.0L</span>
      </div>
    </div>

    <div class="p-3 bg-zinc-900 border border-zinc-800 rounded-xl space-y-2">
      <span class="text-[9px] text-zinc-500 font-mono uppercase block">Interactive Food logger</span>
      <div class="flex gap-1.5 flex-wrap">
        <button onclick="alert('Added 350 kcal: Egg & Whole Toast')" class="px-2.5 py-1.5 bg-white/5 hover:bg-white/10 text-white rounded-lg text-[10px] transition-all cursor-pointer">🍳 Add Eggs (+350c)</button>
        <button onclick="alert('Added 520 kcal: Grilled Chicken Rice')" class="px-2.5 py-1.5 bg-white/5 hover:bg-white/10 text-white rounded-lg text-[10px] transition-all cursor-pointer">🍗 Add Lunch (+520c)</button>
      </div>
    </div>
  </div>
</div>`
  });

  const handleRunMediaGen = async () => {
    if (!mediaPrompt.trim()) return;
    setIsGeneratingMedia(true);
    await new Promise(r => setTimeout(r, 1400));

    if (mediaType === "video") {
      setGeneratedMediaOutput({
        prompt: mediaPrompt,
        videoPlaceholderUrl: "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?q=80&w=600&auto=format&fit=crop",
        fps: 24,
        duration: "4.5 seconds",
        resolution: "1080x1080 (Insta Square)",
        motionVector: "Smooth lateral drift with gentle bokeh flare loops"
      });
    } else if (mediaType === "voice") {
      setGeneratedMediaOutput({
        prompt: mediaPrompt,
        speaker: "Adam - Deep Corporate Native (US English)",
        wordCount: 85,
        audioLength: "14 seconds",
        sampleRate: "48,000 Hz Hi-Res audio"
      });
    } else if (mediaType === "music") {
      setGeneratedMediaOutput({
        prompt: mediaPrompt,
        bpm: 110,
        genre: "Chill Sunset Lo-Fi Beats with vinyl crackle loops",
        structures: ["Acoustic guitar loop background", "Ethereal synth subpad", "808 low snare kicks"]
      });
    } else {
      setGeneratedMediaOutput({
        prompt: mediaPrompt,
        avatarName: "Sofia - Executive Digital Companion",
        expression: "Professional polite, smiling posture with synchronized lip meshes",
        voiceFile: "Sofia_US_Accent_Synced.wav"
      });
    }
    setIsGeneratingMedia(false);
  };

  const handleSandboxCompile = async () => {
    if (!sandboxPrompt.trim()) return;
    setIsSandboxCompiling(true);
    await new Promise(r => setTimeout(r, 1500));

    let html = "";
    if (sandboxTool === "game") {
      html = `
<div class="bg-[#0b0c10] p-6 rounded-2xl border border-[#3b82f6]/20 text-white font-sans text-center max-w-sm mx-auto shadow-2xl space-y-4">
  <div class="flex justify-between items-center pb-2 border-b border-white/5">
    <span class="text-xs font-bold text-[#3b82f6] font-mono">METAVERSE SPACE SHOOTER</span>
    <span class="text-[9px] text-zinc-500 font-mono">SCORE: 00480</span>
  </div>
  
  <div class="w-full h-40 bg-black rounded-xl relative border border-white/5 overflow-hidden flex flex-col justify-between p-3">
    <div class="flex justify-around">
      <span class="px-2 py-0.5 bg-rose-500/10 text-rose-400 text-[9px] font-mono border border-rose-500/20 rounded-md">🔴 TARGET [STRIKER]</span>
      <span class="px-2 py-0.5 bg-cyan-500/10 text-cyan-400 text-[9px] font-mono border border-cyan-500/20 rounded-md">🔵 BOSS ACTIVE [100%]</span>
    </div>
    
    <div class="flex justify-center my-2 text-2xl font-bold animate-bounce flex-1 items-center">
      👾 ⚔️ 🚀
    </div>
    
    <div class="flex justify-between text-[10px] text-gray-500 font-mono">
      <span>LASER: ACTIVE</span>
      <span>ENERGY: 94%</span>
    </div>
  </div>

  <div class="flex gap-2">
    <button onclick="alert('Firing plasma cannon! Enemy hit!')" class="flex-1 py-2 rounded-xl bg-[#3b82f6] text-white hover:bg-[#2563eb] text-xs font-bold font-mono cursor-pointer">🔥 FIRE PLASMA CANNON</button>
    <button onclick="alert('Active shields initialized!')" class="px-4 py-2 bg-white/5 hover:bg-white/10 rounded-xl text-xs font-mono border border-white/10 cursor-pointer">🛡️ SHIELD</button>
  </div>
</div>`;
    } else if (sandboxTool === "website") {
      html = `
<div class="bg-[#050505] p-6 rounded-2xl border border-[#d4af37]/20 text-white font-sans max-w-sm mx-auto shadow-2xl text-left space-y-4">
  <div class="text-center pb-3 border-b border-white/5">
    <h3 class="text-md font-bold tracking-widest text-[#d4af37] font-mono uppercase">VINTAGE BRUTALIST</h3>
    <span class="text-[9px] font-mono text-zinc-500">CURATED DESIGN COWORK PORTAL</span>
  </div>
  
  <div class="space-y-3">
    <h1 class="text-xl font-black font-sans leading-tight">We build elegant digital realities for corporate rebels.</h1>
    <p class="text-[11px] text-zinc-400 leading-relaxed font-sans">A collaborative suite consisting of six specialized computer clones performing deep marketing layouts dynamically.</p>
    
    <div class="p-3 bg-zinc-950 border border-zinc-800 rounded-xl flex items-center justify-between">
      <span class="text-xs text-zinc-400">Design Accents</span>
      <div class="flex gap-1">
        <span class="w-3 h-3 rounded-full bg-[#d4af37]"></span>
        <span class="w-3 h-3 rounded-full bg-indigo-500"></span>
      </div>
    </div>
    
    <button onclick="alert('Connected to workspace concierge!')" class="w-full py-2 bg-[#d4af37] text-black font-bold text-xs uppercase tracking-wider rounded-xl hover:bg-[#c39c2c] transition-all text-center cursor-pointer">Connect Concierge</button>
  </div>
</div>`;
    } else {
      html = `
<div class="bg-zinc-950 p-6 rounded-2xl border border-white/10 text-white font-sans max-w-sm mx-auto shadow-2xl relative overflow-hidden">
  <div class="absolute -top-12 -right-12 w-24 h-24 bg-purple-500/10 blur-xl rounded-full"></div>
  <div class="flex justify-between items-center border-b border-zinc-800 pb-3">
    <div>
      <h3 class="text-sm font-bold tracking-tight text-white block">${sandboxPrompt.split(" ")[0] || "Custom App"} Helper</h3>
      <span class="text-[9px] text-zinc-500 font-mono">SANDBOX ACTIVE BUILD • LIVE STATE</span>
    </div>
    <span class="w-2 h-2 rounded-full bg-purple-500 animate-pulse"></span>
  </div>
  
  <div class="mt-4 space-y-3 font-sans text-xs">
    <p class="text-zinc-400">Your tailored workspace for: <span class="text-purple-400">"${sandboxPrompt}"</span></p>
    
    <div class="p-4 bg-zinc-900 border border-zinc-800 rounded-xl space-y-2">
      <div class="flex justify-between font-mono text-[10px] text-zinc-400">
        <span>Target Goal</span>
        <span class="text-white">Active</span>
      </div>
      <div class="p-2 bg-black/40 rounded border border-white/5 text-[11px] font-mono">${sandboxPrompt}</div>
    </div>
    
    <button onclick="alert('Sandbox task processed successfully inside compile container!')" class="w-full py-2 bg-purple-600 hover:bg-purple-500 text-white font-bold text-xs uppercase tracking-wide rounded-xl text-center cursor-pointer">Execute Action</button>
  </div>
</div>`;
    }

    setCompiledSandboxResultList({
      title: `${sandboxTool.toUpperCase()} Built Prototype`,
      prompt: sandboxPrompt,
      iframeMockHtml: html
    });
    setIsSandboxCompiling(false);
  };

  // ==========================================
  // STATE 4: TREND RADAR & SCREEN ANALYZER
  // ==========================================
  const [trends, setTrends] = useState<Array<{ tag: string; ctr: number; rate: number; channel: string }>>([
    { tag: "#MinimalBrutalist", ctr: 94.2, rate: 85, channel: "Instagram Reels" },
    { tag: "#VelvetMidnightGold", ctr: 88.5, rate: 74, channel: "YouTube Tech Vids" },
    { tag: "#TypographyGrids", ctr: 91.0, rate: 90, channel: "TikTok Feed Art" },
    { tag: "#ResponsiveSandboxing", ctr: 82.3, rate: 68, channel: "Twitter Dev" }
  ]);

  // Visual Screenshot Analyzer Option SELECT
  const [selectedScreenshotType, setSelectedScreenshotType] = useState<"thumbnail" | "landing" | "logo">("thumbnail");
  const [analyzedStructure, setAnalyzedStructure] = useState<any | null>(null);
  const [isAnalyzingScreenshot, setIsAnalyzingScreenshot] = useState(false);

  const mockScreenshots = {
    thumbnail: "https://images.unsplash.com/photo-1542751371-adc38448a05e?q=80&w=400&auto=format&fit=crop",
    landing: "https://images.unsplash.com/photo-1531403009284-440f080d1e12?q=80&w=400&auto=format&fit=crop",
    logo: "https://images.unsplash.com/photo-1626785774573-4b799315345d?q=80&w=400&auto=format&fit=crop"
  };

  const handleAnalyzeScreenshot = async () => {
    setIsAnalyzingScreenshot(true);
    await new Promise(r => setTimeout(r, 1200));

    if (selectedScreenshotType === "thumbnail") {
      setAnalyzedStructure({
        dimensions: "1280x720 Standard YouTube Aspect Ratio",
        flawScore: "7.8 / 10 Overall Rating (Good CTR structure)",
        hotspots: [
          { x: "25%", y: "45%", label: "Typography alignment: Contrast is 3.5:1 (Slightly low and may compress in dark mode mobile feeds)" },
          { x: "75%", y: "50%", label: "Mascot Glow effect: Perfectly calibrated. Volumetric rim-lights provide elite depth." }
        ],
        improvementGuides: [
          "Increase text border lines to 4px solid dark black values.",
          "Widen negative bounds around the human mascot's face profile to prevent thumbnail crowding."
        ]
      });
    } else if (selectedScreenshotType === "landing") {
      setAnalyzedStructure({
        dimensions: "1920x1080 Responsive Desktop View",
        flawScore: "5.4 / 10 Overall Rating (Action Required!)",
        hotspots: [
          { x: "10%", y: "15%", label: "Hero logo overlap: Font families clash and confuse visitors." },
          { x: "50%", y: "80%", label: "CTA Button Margin: Touch targeting is under 32px. Users on android mobile will misclick." }
        ],
        improvementGuides: [
          "Switch body display font to Inter family to allow spacious legibility.",
          "Add 15px padding above CTA button nodes to preserve white space guidelines."
        ]
      });
    } else {
      setAnalyzedStructure({
        dimensions: "512x512 Pure Vector Monogram",
        flawScore: "9.1 / 10 Excellent minimalist ratio!",
        hotspots: [
          { x: "50%", y: "50%", label: "Negative spacing grid lines: Masterfully drawn, creating deep high-brand value premium aura." }
        ],
        improvementGuides: [
          "Preserve the #d4af37 (Champagne Gold) accent color to scale brand luxury."
        ]
      });
    }
    setIsAnalyzingScreenshot(false);
  };

  // Futuristic Simulator
  const [futuristicInput, setFuturisticInput] = useState("AeroCal Fitness Platform Logo");
  const [futuristicYear, setFuturisticYear] = useState<number>(2030);
  const [isSimulatingFuture, setIsSimulatingFuture] = useState(false);
  const [futureSimulationResult, setFutureSimulationResult] = useState<any | null>(null);

  const handleSimulateFuture = async () => {
    if (!futuristicInput.trim()) return;
    setIsSimulatingFuture(true);
    await new Promise(r => setTimeout(r, 1100));

    setFutureSimulationResult({
      input: futuristicInput,
      year: futuristicYear,
      predictedStyleVibe: futuristicYear === 2027 
        ? "Micro-glassmorphism paired with dynamic physics constraints where interfaces warp slightly in response to eyeball track speeds."
        : "Holographic sensory interface layout. Static typography is entirely abandoned for real-time generative particles.",
      dominantAestheticAccents: ["#D4AF37 Champagne Gold", "#10B981 Neon Emerald", "Deep space void black backgrounds"],
      futureCtrForecast: `Predicted CTR index is +58.4% higher than today's baseline layouts.`
    });
    setIsSimulatingFuture(false);
  };

  // AI Success Predictor
  const [projectTitleToPredict, setProjectTitleToPredict] = useState("E-Learning portal responsive login canvas");
  const [isPredictingSuccess, setIsPredictingSuccess] = useState(false);
  const [successPrediction, setSuccessPrediction] = useState<any | null>({
    title: "E-Learning portal responsive login canvas",
    satisfaction: 92,
    viralChance: 78,
    engagement: 85,
    conversion: 89,
    remark: "Exceptional UI balance and spacious borders increase sign-up efficiency."
  });

  const handlePredictSuccess = async () => {
    if (!projectTitleToPredict.trim()) return;
    setIsPredictingSuccess(true);
    await new Promise(r => setTimeout(r, 1000));

    const sat = Math.floor(Math.random() * 25) + 70;
    const vir = Math.floor(Math.random() * 30) + 60;
    const eng = Math.floor(Math.random() * 20) + 75;
    const con = Math.floor(Math.random() * 25) + 70;

    setSuccessPrediction({
      title: projectTitleToPredict,
      satisfaction: sat,
      viralChance: vir,
      engagement: eng,
      conversion: con,
      remark: sat > 85 
        ? "Exceptional layout contrast ratios predict massive positive viewer response on both mobile and grid browsers."
        : "Improve contrast or increase font margin heights to secure stellar visual reviews."
    });
    setIsPredictingSuccess(false);
  };


  // ==========================================
  // STATE 5: PERSONAL AI CLONE TWIN & ACADEMY
  // ==========================================
  const [cloneAutonomousMode, setCloneAutonomousMode] = useState(false);
  const [cloneActions, setCloneActions] = useState<string[]>([
    "🤖 [Digital Twin]: Analyzing user color preferences (Midnight Indigo focus)...",
    "🤖 [Digital Twin]: Learned prompt pattern: preferences represent Brutalist Bold frames."
  ]);
  const [autonomousEarningLog, setAutonomousEarningLog] = useState<Array<{ time: string; action: string; earned: number }>>([
    { time: "12:15 UTC", action: "Completed custom logo design review contract anonymously.", earned: 15 },
    { time: "11:40 UTC", action: "Optimized social media post layout for Fiverr client.", earned: 12 }
  ]);

  useEffect(() => {
    if (!cloneAutonomousMode) return;
    const interval = setInterval(() => {
      const actionsList = [
        "🤖 [Digital Twin IDLE MODE WORKING]: Scanning Upwork opportunities for luxury brand gigs...",
        "🤖 [Digital Twin IDLE MODE WORKING]: Submitting design proposal using modeled signature styles...",
        "🤖 [Digital Twin IDLE MODE WORKING]: Discovered and closed a $45 microcontract on Fiverr!",
        "🤖 [Digital Twin IDLE MODE WORKING]: Updating local creative DNA matrices automatically..."
      ];
      const randomAction = actionsList[Math.floor(Math.random() * actionsList.length)];
      setCloneActions(prev => [randomAction, ...prev.slice(0, 10)]);

      if (randomAction.includes("closed")) {
        setAutonomousEarningLog(prev => [
          { time: new Date().toLocaleTimeString(), action: "Completed autonomous freelancer gig.", earned: 10 },
          ...prev
        ]);
      }
    }, 4500);

    return () => clearInterval(interval);
  }, [cloneAutonomousMode]);

  // Project Time Machine
  const [timeMachineVersions, setTimeMachineVersions] = useState([
    { ver: "V1.0.0", date: "2026-05-20", accent: "#3B82F6 (Sky Blue)", contrast: "4.2:1 (Slightly low)", desc: "Initial layout draft, standard container." },
    { ver: "V1.1.2", date: "2026-05-22", accent: "#A855F7 (Purple)", contrast: "5.8:1 (Excellent)", desc: "Optimized border weight and spacing margins." },
    { ver: "V2.0.0", date: "2026-05-23", accent: "#D4AF37 (Champagne Gold)", contrast: "7.1:1 (VVIP Elite)", desc: "Current production master copy." }
  ]);
  const [selectedVerA, setSelectedVerA] = useState("V1.0.0");
  const [selectedVerB, setSelectedVerB] = useState("V2.0.0");
  const [timeMachineCompareResult, setTimeMachineCompareResult] = useState<string>("");

  const handleCompareVersions = () => {
    const vA = timeMachineVersions.find(v => v.ver === selectedVerA);
    const vB = timeMachineVersions.find(v => v.ver === selectedVerB);
    if (!vA || !vB) return;

    setTimeMachineCompareResult(
      isEn 
        ? `🔥 Evolution Diff of ${selectedVerA} vs. ${selectedVerB}:
- **Accent Shift**: Moved from standard ${vA.accent} index to prestige ${vB.accent} system.
- **Accessibility**: Contrast ratio rose from ${vA.contrast} to ${vB.contrast}, making elements significantly cleaner on mobile.
- **Layout update notes**: ${vB.desc} successfully integrated and approved.`
        : `🔥 ${selectedVerA} বনাম ${selectedVerB} এর কম্পারিজন রিপোর্ট:
- **কালার পরিবর্তন**: পূর্বের ${vA.accent} থেকে আপগ্রেড করে প্রিমিয়াম ${vB.accent} যুক্ত করা হয়েছে।
- **সিটিআর এবং অ্যাক্সেসিবিলিটি**: কনট্রাস্ট রেশিও ${vA.contrast} থেকে বৃদ্ধি পেয়ে ${vB.contrast} হয়েছে।
- **আপডেট বিবরণ**: ${vB.desc} সফলভাবে সেভ করা হয়েছে।`
    );
  };

  // AI University and Certifications
  const [dailyChallengeCompleted, setDailyChallengeCompleted] = useState(false);
  const dailyChallengeText = isEn 
    ? "Challenge: Outline a high-contrast dark mode pricing table layout with gold accents in 5 minutes."
    : "আজকের চ্যালেঞ্জ: ৫ মিনিটের মধ্যে গোল্ডেন এক্সেন্ট সহ একটি ডার্ক মোড প্রাইসিং টেবিল স্ট্রাকচার ডিজাইন করুন।";

  return (
    <div className="space-y-8" id="unified-quantum-agent-system">
      
      {/* 1. Header with inner subtabs options */}
      <div className="relative p-6 sm:p-8 bg-gradient-to-r from-[#0d0d0f] via-[#121215] to-[#141419] border border-white/5 rounded-3xl overflow-hidden shadow-xl text-left">
        <div className="absolute top-0 right-0 w-96 h-96 bg-purple-500/10 blur-[130px] rounded-full pointer-events-none" />
        <div className="absolute -bottom-10 -left-10 w-60 h-60 bg-blue-500/5 blur-[100px] rounded-full pointer-events-none" />

        <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center gap-6 z-10 relative">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 bg-purple-500/10 border border-purple-500/20 rounded-full text-[10px] text-purple-400 font-mono tracking-widest uppercase mb-3">
              <span className="w-1.5 h-1.5 rounded-full bg-purple-500 animate-pulse"></span>
              🛰️ {isEn ? "Quantum Universal AI Suite Active" : "কোয়ান্টাম ইউনিভার্সাল এআই ওয়ার্কস্পেস"}
            </div>
            <h2 className="text-2xl sm:text-3xl font-display font-medium tracking-tight text-white uppercase flex items-center gap-2">
              <Brain className="w-7 h-7 text-purple-400 rotate-6" />
              <span>{isEn ? "Unified AI Operating System" : "ইউনিফাইড অল-ইন-ওয়ান এআই হাব"}</span>
            </h2>
            <p className="text-xs sm:text-sm text-gray-400 font-sans mt-2 max-w-2xl leading-relaxed">
              {isEn 
                ? "An advanced, Moonshot-level ecosystem: Deep grounding research models, a collaborative AI OS with six specialized agents, prompt sandboxes, predictive trend radar, screenshot analyzers, and personal digital cloning."
                : "ডিজিটাল ডিজাইনার ও ফ্রিল্যান্সারদের জন্য রাজকীয় সব শক্তিশালী এআই টুলস। ইন্টারনেট লাইভ গ্রাউন্ডিং, স্পেশালিস্ট এআই চ্যাট এজেন্ট, ডিজাইনার প্রজেক্ট ম্যানেজার, এসেট কালেকশন ও ভবিষ্যৎ ট্রেন্ড এনালাইজার একসাথে।"}
            </p>
          </div>

          <div className="flex items-center gap-3 px-4.5 py-3.5 bg-black/40 border border-white/5 rounded-2xl shrink-0">
            <Flame className="w-5 h-5 text-amber-400 animate-pulse" />
            <div>
              <div className="text-[10px] text-gray-500 font-mono uppercase tracking-wider">{isEn ? "Evolving Knowledge Base" : "সক্রিয় মেমোরিটোকেন"}</div>
              <div className="text-xs font-mono font-bold text-white">{memories.length} {isEn ? "Learned Facts Saved" : "টি তথ্য মেমোরিতে সেভড"}</div>
            </div>
          </div>
        </div>

        {/* 2. Sleek Inner Suite Segment Tabs Switch Controller */}
        <div className="flex flex-wrap items-center gap-1.5 mt-8 p-1 bg-black/30 border border-white/5 rounded-2xl max-w-fit">
          {[
            { id: "brain", label: isEn ? "🧠 Core Brain & Custom Knowledge" : "🧠 কোর ব্রেইন ও রিসার্চ", color: "bg-purple-600 text-white" },
            { id: "aios", label: isEn ? "🤖 Collaborative AI OS" : "🤖 কো-অর্ডিনেটেড AI OS", color: "bg-blue-600 text-white" },
            { id: "media", label: isEn ? "🎥 Media Studio & Sandbox" : "🎥 মিডিয়া স্টুডিও ও স্যান্ডবক্স", color: "bg-emerald-600 text-white" },
            { id: "radar", label: isEn ? "🛰️ Trend Radar & Screenshot Analyzer" : "🛰️ ট্রেন্ড রাডার ও এনালাইজার", color: "bg-indigo-600 text-white" },
            { id: "galaxy", label: isEn ? "🔮 Personal AI Twin & Academy" : "🔮 এআই ক্লোন ও একাডেমি", color: "bg-amber-600 text-white" }
          ].map((tabSpec) => (
            <button
              key={tabSpec.id}
              onClick={() => setInnerTab(tabSpec.id as any)}
              className={`px-4 py-2.5 rounded-xl text-xs font-semibold font-sans tracking-wide cursor-pointer transition-all ${
                innerTab === tabSpec.id 
                  ? tabSpec.color
                  : "text-gray-400 hover:text-white hover:bg-white/5"
              }`}
            >
              {tabSpec.label}
            </button>
          ))}
        </div>
      </div>

      {/* 3. INNER TAB WORKSPACES CONTAINER SWITCH */}
      <div className="min-h-[500px]">
        {innerTab === "brain" && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
            
            {/* Left Memory and Stored Knowledge panel */}
            <div className="lg:col-span-4 space-y-6 text-left">
              <div className="bg-[#121212] border border-white/5 rounded-2xl overflow-hidden p-5 space-y-4">
                <div className="flex justify-between items-center border-b border-white/5 pb-3">
                  <div className="flex items-center gap-2">
                    <Database className="w-4 h-4 text-purple-400" />
                    <span className="text-xs font-mono font-bold text-gray-300 uppercase">{isEn ? "Personal Knowledge Base" : "নিউরাল মেমোরি স্টোর"}</span>
                  </div>
                  <button 
                    onClick={() => setMemories([])} 
                    className="text-[10px] text-rose-400 font-mono tracking-wider cursor-pointer font-bold"
                  >
                    {isEn ? "[Wipe]" : "[মুছুন]"}
                  </button>
                </div>

                <p className="text-xs text-gray-500 font-sans leading-relaxed">
                  {isEn 
                    ? "Our self-learning model continuously saves structured rules, design preferences, and grounding facts here. Feel free to teach AI customized instructions."
                    : "এই এআই প্রতিনিয়ত নিজেকে আপডেট করতে পারে ও শিখতে পারে। গবেষণালব্ধ সব তথ্য ও সূত্র এখানে সেভ হয় যেন পরবর্তী প্রশ্নে তা নিখুঁতভাবে কাজে লাগানো যায়।"}
                </p>

                <div className="space-y-2 max-h-52 overflow-y-auto pr-1">
                  {memories.map((mem, idx) => (
                    <div key={idx} className="p-3 bg-black/40 border border-white/5 rounded-xl text-xs text-gray-400 flex items-start gap-2 relative group">
                      <span className="w-1.5 h-1.5 rounded-full bg-purple-500 mt-1.5 shrink-0" />
                      <span className="leading-relaxed font-sans">{mem}</span>
                      <button 
                        onClick={() => setMemories(prev => prev.filter((_, i) => i !== idx))}
                        className="absolute right-2 top-2 opacity-0 group-hover:opacity-100 text-rose-400 transition-all cursor-pointer"
                      >
                        <Trash2 className="w-3 h-3" />
                      </button>
                    </div>
                  ))}
                </div>

                <div className="flex items-center gap-1.5">
                  <input 
                    type="text"
                    placeholder={isEn ? "Teach AI custom style/rule..." : "एআই-কে নতুন নিয়ম শেখান..."}
                    value={prompt}
                    onChange={(e) => setPrompt(e.target.value)}
                    onKeyDown={(e) => e.key === "Enter" && (memories.includes(prompt) || setMemories(prev => [prompt.trim(), ...prev]), setPrompt(""))}
                    className="flex-1 text-xs bg-black/30 border border-white/5 rounded-xl px-3 py-2 text-white outline-none font-sans"
                  />
                  <button 
                    onClick={() => {
                      if (!prompt.trim()) return;
                      setMemories(prev => [prompt.trim(), ...prev]);
                      setPrompt("");
                    }}
                    className="p-2 bg-purple-600/10 border border-purple-500/20 rounded-xl text-purple-400 cursor-pointer hover:bg-purple-600/20 transition-all"
                  >
                    <Plus className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>

              {/* Company & Team Stored Knowledge Base */}
              <div className="bg-[#121212] border border-white/5 rounded-2xl p-5 space-y-4">
                <div className="flex items-center gap-2 border-b border-white/5 pb-2.5">
                  <ShieldCheck className="w-4 h-4 text-emerald-400" />
                  <span className="text-xs font-mono font-bold tracking-wider uppercase text-gray-300">
                    {isEn ? "Company Knowledge Base" : "কোম্পানি ও টিম গাইডলাইনস"}
                  </span>
                </div>
                
                <p className="text-[11px] text-gray-500 font-sans leading-relaxed">
                  {isEn 
                    ? "Manage brand assets, consistency instructions, and style guidelines. AI actively reads these modules to avoid brand misalignment."
                    : "টিম ব্রান্ড বুক, কোম্পানির নিয়মাবলী এবং লোগো গাইডলাইন সেভ করে রাখুন। এআই এগুলো এনালাইজ করে কনটেক্সট মিলিয়ে উত্তর দিবে।"}
                </p>

                <div className="space-y-2.5">
                  {knowledgeBase.map((kb, idx) => (
                    <div key={idx} className="p-3 bg-white/5 border border-white/5 rounded-xl text-xs space-y-1 text-left relative group">
                      <div className="flex justify-between items-center font-mono text-[9px]">
                        <span className={`px-2 py-0.5 rounded-md uppercase font-bold ${
                          kb.category === "brand" ? "bg-purple-500/10 text-purple-400" :
                          kb.category === "rule" ? "bg-amber-500/10 text-amber-400" : "bg-blue-500/10 text-blue-400"
                        }`}>
                          {kb.category}
                        </span>
                        <button 
                          onClick={() => setKnowledgeBase(prev => prev.filter((_, i) => i !== idx))}
                          className="opacity-0 group-hover:opacity-100 text-rose-400 transition-all"
                        >
                          <Trash2 className="w-3 h-3" />
                        </button>
                      </div>
                      <h4 className="font-bold text-gray-200 mt-1">{kb.title}</h4>
                      <p className="text-[11px] text-gray-400 leading-normal font-sans">{kb.desc}</p>
                    </div>
                  ))}
                </div>

                {/* Stored Knowledge Insert form */}
                <div className="p-3 bg-black/40 border border-white/5 rounded-xl space-y-2">
                  <input 
                    type="text"
                    placeholder="Title or Asset name"
                    value={newKbTitle}
                    onChange={(e) => setNewKbTitle(e.target.value)}
                    className="w-full text-xs bg-zinc-900 border border-white/5 rounded-lg px-2 py-1 text-white select-text"
                  />
                  <textarea 
                    placeholder="Description or color values..."
                    value={newKbDesc}
                    onChange={(e) => setNewKbDesc(e.target.value)}
                    className="w-full text-xs bg-zinc-900 border border-white/5 rounded-lg px-2 py-1 text-white h-12 select-text"
                  />
                  <div className="flex justify-between items-center gap-2">
                    <select 
                      value={newKbCat} 
                      onChange={(e) => setNewKbCat(e.target.value as any)}
                      className="text-[10px] bg-zinc-900 border border-white/5 rounded px-1 text-gray-300"
                    >
                      <option value="brand">Brand</option>
                      <option value="rule">Rule</option>
                      <option value="asset">Asset</option>
                    </select>
                    <button 
                      onClick={handleAddKbItem}
                      className="px-3 py-1 bg-emerald-600 hover:bg-emerald-500 text-white rounded text-[10px] font-bold uppercase transition-all cursor-pointer"
                    >
                      Save Item
                    </button>
                  </div>
                </div>
              </div>
            </div>

            {/* Right deep query & comparative sources pane */}
            <div className="lg:col-span-8 space-y-6">
              
              <form onSubmit={handleExecuteResearch} className="bg-[#121212] border border-white/5 rounded-2xl p-6 space-y-5 text-left">
                <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
                  <div>
                    <h3 className="text-sm font-bold uppercase tracking-wider text-white font-mono flex items-center gap-2">
                      <Search className="w-4 h-4 text-purple-400" />
                      <span>{isEn ? "Autonomous Grounded Deep Research" : "গভীর ওয়েব গ্রাউন্ডিং এন্ড সেলফ-কারেকশন ইঞ্জিন"}</span>
                    </h3>
                    <p className="text-xs text-gray-500 font-sans mt-0.5">
                      {isEn ? "Compare multiple sources, forecast trends, design interactive charts, and export PDF summaries." : "সিস্টেমটি ওয়েব সার্চ করবে, একাধিক উৎস যাচাই করবে, হ্যালুসিনেশন চেক করবে এবং ইন্টারেক্টিভ উইজেট সহ উত্তর দেবে।"}
                    </p>
                  </div>

                  <div className="flex items-center gap-2 shrink-0">
                    <button
                      type="button"
                      onClick={triggerBDPreset}
                      className="px-3 py-1.5 bg-rose-600/10 hover:bg-rose-600/20 border border-rose-500/20 rounded-xl text-[10px] font-mono text-rose-400 font-bold tracking-wide cursor-pointer transition-all"
                    >
                      🇧🇩 BD Design Market Preset
                    </button>
                    <button
                      type="button"
                      onClick={() => setIsDeepResearch(!isDeepResearch)}
                      className={`px-3 py-1.5 rounded-xl text-[10px] font-mono tracking-wider uppercase transition-all border ${
                        isDeepResearch
                          ? "bg-purple-600/10 border-purple-500/30 text-purple-400 font-bold"
                          : "bg-transparent border-white/5 text-gray-400 hover:text-white"
                      }`}
                    >
                      🔬 {isDeepResearch ? (isEn ? "Deep Loop (15 Cr)" : "ডিপ লুপ (১৫ ক্রেডিট)") : (isEn ? "Standard (8 Cr)" : "স্ট্যান্ডার্ড (৮ ক্রেডিট)")}
                    </button>
                  </div>
                </div>

                <div className="relative">
                  <textarea 
                    rows={3}
                    value={prompt}
                    onChange={(e) => setPrompt(e.target.value)}
                    placeholder={isEn 
                      ? "Query anything... (e.g. 'What will be the high-converting branding trends in Bangladesh graphic design market for 2027? Generate source checklist, forecast charts, and click PDF Report.')"
                      : "আপনার যেকোনো প্রশ্ন লিখুন... (যেমন: '২০২৭ সালে বাংলাদেশে কেমন থাকবে থাম্বনেইল ডিজাইনের বাজার? রঙের ট্রেন্ড এবং মার্কেট কম্পিটিটর এনালাইসিস করে দিন।')"
                    }
                    className="w-full text-sm bg-black/40 border border-white/5 focus:border-purple-500/40 rounded-xl px-4 py-3.5 text-white placeholder-gray-600 outline-none resize-none font-sans"
                    required
                  />
                </div>

                <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-t border-white/5 pt-4">
                  <div className="flex flex-wrap items-center gap-2.5">
                    <span className="text-[10px] text-gray-500 font-mono uppercase">{isEn ? "Output Styling:" : "আউটপুট টাইপ:"}</span>
                    <div className="flex items-center gap-1.5 p-0.5 bg-black/20 rounded-xl border border-white/5">
                      {["expert", "creative", "critical"].map((v) => (
                        <button
                          key={v}
                          type="button"
                          onClick={() => setTone(v as any)}
                          className={`px-2.5 py-1 rounded-lg text-[9px] font-mono uppercase transition-all ${
                            tone === v ? "bg-purple-600 text-white font-bold" : "text-gray-400 hover:text-white"
                          }`}
                        >
                          {v}
                        </button>
                      ))}
                    </div>
                  </div>

                  <button
                    type="submit"
                    disabled={loadingStep >= 0 || !prompt.trim()}
                    className={`flex items-center gap-2 px-6 py-2.5 rounded-xl font-bold font-sans text-xs uppercase cursor-pointer transition-all active:scale-95 text-white ${
                      loadingStep >= 0 || !prompt.trim()
                        ? "bg-[#18181b] text-gray-600 border border-white/5C"
                        : "bg-purple-600 hover:bg-purple-500 border border-purple-500/20 shadow-lg shadow-purple-900/30"
                    }`}
                  >
                    {loadingStep >= 0 ? (
                      <>
                        <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                        <span>{isEn ? "Analyzing..." : "রিসার্চ অডিট চলছে..."}</span>
                      </>
                    ) : (
                      <>
                        <Play className="w-3.5 h-3.5 fill-current" />
                        <span>{isEn ? "Run Deeper Research" : "গভীর ওয়েব গবেষণা চালান"}</span>
                      </>
                    )}
                  </button>
                </div>
              </form>

              {/* TIMELINE LOADER SIMULATOR */}
              {loadingStep >= 0 && (
                <div className="bg-[#121212] border border-purple-500/20 rounded-2xl p-6 text-left space-y-4 shadow-xl">
                  <div className="flex items-center justify-between border-b border-white/5 pb-3">
                    <div className="flex items-center gap-2">
                      <RefreshCw className="w-4 h-4 text-purple-400 animate-spin" />
                      <span className="text-xs font-mono font-bold tracking-wider uppercase text-purple-400">
                        {isEn ? "Synchronous Deep Network Scan" : "লাইভ ওয়েব অনুসন্ধান ও কম্পাইলেশন চলছে"}
                      </span>
                    </div>
                    <span className="text-xs font-mono font-bold text-gray-400">
                      {loadingStatusText ? `⏳ ${loadingStatusText}` : "Analyzing..."}
                    </span>
                  </div>

                  <div className="w-full h-1 bg-[#181818] rounded-full overflow-hidden">
                    <div className="h-full bg-purple-500 animate-[pulse_1.5s_infinite]" style={{ width: "80%" }} />
                  </div>
                </div>
              )}

              {/* ACTIVE RESEARCH RESULT DISPLAY WITH WIDGETS */}
              {activeResult && loadingStep < 0 && (
                <div className="space-y-6">
                  
                  {/* Markdown content audit */}
                  <div className="bg-[#121212] border border-white/5 rounded-2xl p-6 sm:p-8 text-left space-y-5 shadow-2xl relative">
                    <div className="flex justify-between items-center border-b border-white/5 pb-3.5">
                      <div className="flex items-center gap-2">
                        <BookOpen className="w-4 h-4 text-purple-400" />
                        <span className="text-xs font-mono font-bold text-gray-300 uppercase">{isEn ? "Interactive Autonomous Report" : "সংশ্লেষিত গভীর গবেষণালব্ধ তথ্য ও পূর্বাভাস"}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <button 
                          onClick={() => setShowPdfMock(!showPdfMock)}
                          className="px-3 py-1 bg-white/5 hover:bg-white/10 text-white rounded-lg text-[10px] font-mono border border-white/10 flex items-center gap-1 cursor-pointer"
                        >
                          <Download className="w-3 h-3 text-purple-400" />
                          <span>{isEn ? "Download PDF Report" : "PDF ডাউনলোড করুন"}</span>
                        </button>
                        <span className="text-[10px] font-mono bg-purple-500/10 border border-purple-100/10 px-2.5 py-1 text-purple-400 rounded-full">
                          {isEn ? "EVALUATED PASS" : "গ্রাউন্ডেড ও ভেরিфাইড"}
                        </span>
                      </div>
                    </div>

                    {showPdfMock && (
                      <div className="p-6 bg-white text-zinc-900 border-4 border-double border-zinc-800 rounded-xl space-y-4 font-serif">
                        <div className="text-center border-b border-zinc-300 pb-3">
                          <h1 className="text-lg font-black tracking-widest uppercase">AUTONOMOUS DEEP RESEARCH REPORT</h1>
                          <p className="text-[10px] font-mono text-zinc-500">BD FREELANCE ECOSYSTEM DATA • GENERATED MAY 2026</p>
                        </div>
                        <p className="text-xs leading-relaxed">
                          This document serves as an official analytical overview compile. Key competitors across local startup segments have been evaluated with a strict contrast scale. Over 85% adoption rate has been forecast in simple stark designs.
                        </p>
                        <div className="flex justify-between border-t border-zinc-200 pt-2 text-[10px] font-mono text-zinc-500">
                          <span>Report Ref: QAUD-BD-26</span>
                          <span>Approved: AI Lead CEO</span>
                        </div>
                      </div>
                    )}

                    <div className="prose prose-invert max-w-none space-y-3.5">
                      {activeResult.analysisText.split("\n").map((line, idx) => {
                        if (line.trim().startsWith("###")) {
                          return <h3 key={idx} className="text-md font-bold text-white mt-4 border-b border-white/5 pb-1 uppercase tracking-wide">{line.replace("###", "").trim()}</h3>;
                        } else if (line.trim().startsWith("####")) {
                          return <h4 key={idx} className="text-xs font-bold text-purple-400 mt-2 tracking-wide uppercase">{line.replace("####", "").trim()}</h4>;
                        }
                        return <p key={idx} className="text-xs leading-relaxed text-gray-400">{line}</p>;
                      })}
                    </div>

                    {/* Grounded Interactive Chart widget */}
                    {activeResult.dynamicWidget?.widgetType === "interactive-chart" && (
                      <div className="p-4 bg-black/40 border border-white/5 rounded-2xl text-left space-y-3">
                        <span className="text-xs font-mono font-bold text-gray-300 block">📊 {activeResult.dynamicWidget.title}</span>
                        <div className="space-y-2">
                          {activeResult.dynamicWidget.config.chartData?.map((item, id) => (
                            <div key={id} className="space-y-1">
                              <div className="flex justify-between items-center text-[11px] font-sans">
                                <span className="text-gray-400 font-medium">{item.label}</span>
                                <span className="font-mono text-emerald-400 font-bold">{item.value}% Rate</span>
                              </div>
                              <div className="w-full h-1.5 bg-zinc-900 rounded-full overflow-hidden">
                                <div className="h-full bg-emerald-500 rounded-full" style={{ width: `${item.value}%` }}></div>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}

                    {activeResult.selfEvaluation && (
                      <div className="p-3.5 bg-purple-950/15 border border-purple-500/20 rounded-xl space-y-1.5 mt-4">
                        <div className="flex items-center gap-1.5 text-[10px] font-mono font-bold text-purple-300 uppercase">
                          <CheckSquare className="w-3.5 h-3.5" />
                          <span>{isEn ? "AI Self-Corrective Audit remark" : "সেলফ-কারেকটিভ মেজারমেন্ট লগ"}</span>
                        </div>
                        <p className="text-xs text-purple-200/90 leading-relaxed italic font-sans">{activeResult.selfEvaluation}</p>
                      </div>
                    )}

                    {/* Citations panel lists */}
                    {activeResult.citations && activeResult.citations.length > 0 && (
                      <div className="pt-4 border-t border-white/5 space-y-2">
                        <div className="text-[10px] text-gray-500 font-mono uppercase tracking-wider">{isEn ? "Citations & Grounding Sources Verified (Real Links):" : "অনুসন্ধানে ব্যবহৃত প্রামাণ্য ওয়েব সোর্স লিংকসমূহ:"}</div>
                        <div className="flex flex-wrap gap-2">
                          {activeResult.citations.map((cit, idx) => (
                            <a 
                              key={idx}
                              href={cit.uri}
                              target="_blank"
                              rel="noreferrer"
                              className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-black/40 border border-white/5 text-[10px] text-purple-400 hover:text-white rounded-lg transition-all"
                            >
                              <span>{cit.title || "External Verified Link"}</span>
                              <ExternalLink className="w-3 h-3 shrink-0" />
                            </a>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              )}
            </div>
          </div>
        )}

        {/* ==========================================
            INNER TAB: COLLABORATIVE AI OS
            ========================================== */}
        {innerTab === "aios" && (
          <div className="space-y-6 text-left" id="ai-operating-system">
            <div className="bg-[#121212] border border-white/5 rounded-2xl p-6 space-y-4">
              <span className="px-3 py-1 bg-blue-500/10 border border-blue-500/20 text-[10px] font-mono text-blue-400 rounded-full uppercase tracking-wider">🧬 Multipurpose AI Operating System</span>
              <h3 className="text-lg font-bold text-white uppercase font-sans mt-2">{isEn ? "Coordinated Multitasking Agent Workspace" : "কো-অর্ডিনেটেড মাল্টিটাস্কিং এআই ওয়ার্কস্পেস"}</h3>
              <p className="text-xs text-gray-400 leading-relaxed font-sans max-w-2xl">
                {isEn 
                  ? "Enter a single digital startup or launch idea below. Six specialized AI agents will negotiate tasks, compile code bases, draft branding color palette layouts, and arrange custom marketing metrics synchronously."
                  : "আপনার ব্যবসায়িক বা ক্রিয়েটিভ আইডিয়া নিচে লিখুন। ৬টি এক্সপার্ট এআই ক্রনিক এজেন্ট নিজেদের মধ্যে কাজ ভাগ করে মার্কেটিং প্ল্যান, ফাইন্যান্সিয়াল চার্ট এবং ফুল কোডবেস রেডি করবে।"}
              </p>

              <div className="flex gap-2">
                <input 
                  type="text"
                  value={aiosGoal}
                  onChange={(e) => setAiosGoal(e.target.value)}
                  placeholder="e.g. AI-powered diagnostic startup or gaming hub"
                  className="flex-1 text-xs bg-black/40 border border-white/5 rounded-xl px-4 py-3 placeholder-gray-600 outline-none text-white focus:border-blue-500/30 font-sans"
                />
                <button 
                  onClick={runAiosOrchestration}
                  disabled={aiosLoading}
                  className="px-6 py-3 bg-blue-600 hover:bg-blue-500 border border-blue-500/20 rounded-xl text-white text-xs font-bold uppercase transition-all tracking-wide disabled:opacity-50 cursor-pointer flex items-center gap-1 shrink-0 shadow-lg shadow-blue-950/40"
                >
                  {aiosLoading ? (
                    <>
                      <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                      <span>{isEn ? "Negotiating..." : "কো-অর্ডিনেট হচ্ছে..."}</span>
                    </>
                  ) : (
                    <>
                      <Play className="w-3.5 h-3.5 fill-current" />
                      <span>{isEn ? "Run System" : "সিস্টেম চালান"}</span>
                    </>
                  )}
                </button>
              </div>
            </div>

            {/* Simulated Live Terminal Node log */}
            {aiosLoading && (
              <div className="p-5 bg-black border border-white/10 rounded-2xl font-mono text-xs text-green-400 space-y-1 shadow-inner h-40 overflow-y-auto">
                <div className="text-gray-500 border-b border-white/5 pb-1 flex justify-between">
                  <span>🛰️ ACTIVE CONTAINER CORE DEPLOY LOGGER</span>
                  <span className="animate-pulse">● LIVE CONNECTION</span>
                </div>
                {aiosLog.map((log, id) => (
                  <div key={id} className="fade-in animate-[fadeIn_0.3s_ease]">{log}</div>
                ))}
              </div>
            )}

            {/* Compiled Interactive Agent Output blocks */}
            {aiosOutput && (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                
                {/* Agent 1: AI CEO */}
                <div className="p-5 bg-[#121212] border border-[#222] rounded-2xl space-y-3 shadow-lg">
                  <div className="flex justify-between items-center border-b border-white/5 pb-2">
                    <span className="text-xs font-mono font-bold text-amber-400 flex items-center gap-1">👑 CEO Agent Plan</span>
                    <span className="text-[10px] text-gray-500 font-mono">FINANCIAL</span>
                  </div>
                  <div className="space-y-2">
                    <div className="p-3 bg-black/40 border border-white/5 rounded-xl text-xs">
                      <span className="block text-[9px] text-gray-500 font-mono uppercase">Setup Capital</span>
                      <span className="text-gray-200 mt-1 font-sans font-semibold block">{aiosOutput.ceoPlan.budget}</span>
                    </div>
                    <div className="p-3 bg-black/40 border border-white/5 rounded-xl text-xs">
                      <span className="block text-[9px] text-gray-500 font-mono uppercase">Timeline roadmap</span>
                      <span className="text-gray-200 mt-1 font-sans block leading-relaxed">{aiosOutput.ceoPlan.timeline}</span>
                    </div>
                  </div>
                </div>

                {/* Agent 2: AI Designer */}
                <div className="p-5 bg-[#121212] border border-[#222] rounded-2xl space-y-3 shadow-lg">
                  <div className="flex justify-between items-center border-b border-white/5 pb-2">
                    <span className="text-xs font-mono font-bold text-purle-400 flex items-center gap-1">🎨 Designer Concept</span>
                    <span className="text-[10px] text-gray-500 font-mono">ASTHETICS</span>
                  </div>
                  <div className="space-y-2.5">
                    <span className="text-[11px] text-gray-400 leading-normal block font-sans">Synthesized Brand Palette and Vibe:</span>
                    <div className="grid grid-cols-5 gap-1 pt-1">
                      {aiosOutput.designerPalette.map((col: string, id: number) => (
                        <div key={id} className="text-center space-y-1">
                          <div className="h-10 rounded-lg border border-white/10" style={{ backgroundColor: col }} />
                          <span className="text-[9px] font-mono font-bold text-gray-500 block">{col}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Agent 3: AI Researcher */}
                <div className="p-5 bg-[#121212] border border-[#222] rounded-2xl space-y-3 shadow-lg">
                  <div className="flex justify-between items-center border-b border-white/5 pb-2">
                    <span className="text-xs font-mono font-bold text-blue-400 flex items-center gap-1">🔍 Intelligence Researcher</span>
                    <span className="text-[10px] text-gray-500 font-mono">COMPETITORS</span>
                  </div>
                  <div className="space-y-2 text-xs">
                    <div>Competitor Listings:</div>
                    <div className="flex gap-2 flex-wrap">
                      {aiosOutput.researchData.competitors.map((comp: string, id: number) => (
                        <span key={id} className="px-2.5 py-1 bg-white/5 rounded-lg border border-white/5 font-mono text-[10px] text-gray-300">{comp}</span>
                      ))}
                    </div>
                    <div className="p-2.5 bg-black/40 border border-white/5 rounded-xl uppercase text-[10px] font-mono text-emerald-400">
                      Trending index YoY: {aiosOutput.researchData.trendIndex}
                    </div>
                  </div>
                </div>

                {/* Agent 4: AI Marketer */}
                <div className="p-5 bg-[#121212] border border-[#222] rounded-2xl space-y-3 shadow-lg">
                  <div className="flex justify-between items-center border-b border-white/5 pb-2">
                    <span className="text-xs font-mono font-bold text-rose-400 flex items-center gap-1">✍ Tactical Marketer</span>
                    <span className="text-[10px] text-gray-500 font-mono">COPYWRITING</span>
                  </div>
                  <div className="space-y-2 text-xs">
                    <div className="p-3 bg-black/40 border border-white/5 rounded-xl">
                      <span className="block text-[9px] text-rose-400 font-mono uppercase font-bold">TikTok/Reels Hook</span>
                      <p className="text-gray-300 font-sans italic mt-1 leading-normal">&quot;{aiosOutput.marketerCopy.tiktokHook}&quot;</p>
                    </div>
                    <div className="p-3 bg-black/40 border border-white/5 rounded-xl">
                      <span className="block text-[9px] text-gray-500 font-mono uppercase font-bold">Secondary Blueprint</span>
                      <p className="text-gray-400 mt-1">{aiosOutput.marketerCopy.headline}</p>
                    </div>
                  </div>
                </div>

                {/* Agent 5: AI Analyst */}
                <div className="p-5 bg-[#121212] border border-[#222] rounded-2xl space-y-3 shadow-lg">
                  <div className="flex justify-between items-center border-b border-white/5 pb-2">
                    <span className="text-xs font-mono font-bold text-emerald-400 flex items-center gap-1">📊 Analyst Projection</span>
                    <span className="text-[10px] text-gray-500 font-mono">KPI FORECAST</span>
                  </div>
                  <div className="space-y-2">
                    {aiosOutput.analystData.map((item: any, id: number) => (
                      <div key={id} className="space-y-1">
                        <div className="flex justify-between items-center text-[11px]">
                          <span className="text-gray-400">{item.label}</span>
                          <span className="font-mono text-emerald-400 font-bold">{item.value}%</span>
                        </div>
                        <div className="w-full h-1 bg-zinc-900 rounded-full overflow-hidden">
                          <div className="h-full bg-emerald-500 rounded-full" style={{ width: `${item.value}%` }} />
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Agent 6: AI Developer (Vite App builder simulator) */}
                <div className="p-5 bg-[#121212] border border-[#222] rounded-2xl space-y-3 shadow-lg md:col-span-2 lg:col-span-1">
                  <div className="flex justify-between items-center border-b border-white/5 pb-2">
                    <span className="text-xs font-mono font-bold text-blue-400 flex items-center gap-1">💻 Expert App Creator</span>
                    <span className="text-[10px] text-gray-500 font-mono">VITE REACT BUILD</span>
                  </div>
                  
                  {/* Visual rendered preview frame */}
                  <div className="space-y-3">
                    <div className="flex justify-around bg-black/30 border border-white/5 p-1 rounded-xl">
                      <button 
                        onClick={() => setActiveCodeTab("html")}
                        className={`flex-1 py-1.5 rounded-lg text-[10px] font-mono cursor-pointer transition-all ${
                          activeCodeTab === "html" ? "bg-blue-600 text-white" : "text-gray-400 hover:text-white"
                        }`}
                      >
                        Preview Build
                      </button>
                      <button 
                        onClick={() => setActiveCodeTab("css")}
                        className={`flex-1 py-1.5 rounded-lg text-[10px] font-mono cursor-pointer transition-all ${
                          activeCodeTab === "css" ? "bg-zinc-800 text-white" : "text-gray-400 hover:text-white"
                        }`}
                      >
                        Source Code
                      </button>
                    </div>

                    {activeCodeTab === "html" ? (
                      <div className="p-2 border border-white/10 rounded-xl bg-black/60 relative">
                        <span className="absolute top-2 right-2 flex h-2 w-2">
                          <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                          <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
                        </span>
                        <div dangerouslySetInnerHTML={{ __html: aiosOutput.developerAppCode }} />
                      </div>
                    ) : (
                      <div className="p-3 bg-black border border-white/5 rounded-xl font-mono text-[9px] text-blue-300 overflow-x-auto h-48 whitespace-pre leading-relaxed select-text">
                        {aiosOutput.developerAppCode}
                      </div>
                    )}
                  </div>
                </div>

              </div>
            )}
          </div>
        )}

        {/* ==========================================
            INNER TAB: MEDIA STUDIO & SANDBOX
            ========================================== */}
        {innerTab === "media" && (
          <div className="space-y-8 text-left" id="creative-sandbox-container">
            
            {/* Double column split: Media studio & Sandbox builder */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-start">
              
              {/* Box 1: AI Media Studio */}
              <div className="bg-[#121212] border border-white/5 rounded-2xl p-6 space-y-4">
                <div className="flex items-center gap-2 border-b border-white/5 pb-2.5">
                  <Video className="w-4 h-4 text-purple-400 animate-pulse" />
                  <h3 className="text-sm font-bold font-mono text-white uppercase">{isEn ? "AI Media Studio Ecosystem" : "এআই মিডিয়া স্টুডিও এক প্ল্যাটফর্মে"}</h3>
                </div>

                <div className="flex bg-black/40 border border-white/5 p-1 rounded-xl">
                  {(["video", "voice", "music", "avatar"] as const).map((type) => (
                    <button
                      key={type}
                      onClick={() => { setMediaType(type); setGeneratedMediaOutput(null); }}
                      className={`flex-1 py-1.5 rounded-lg text-[10px] font-mono font-bold cursor-pointer uppercase transition-all ${
                        mediaType === type ? "bg-purple-600 text-white" : "text-gray-400 hover:text-white"
                      }`}
                    >
                      {type}
                    </button>
                  ))}
                </div>

                <p className="text-xs text-gray-500 font-sans leading-relaxed">
                  {mediaType === "video" && (isEn ? "Synthesize high-CTR professional MP4 video frames with beautiful cinematic panning cameras." : "ভিডিও তৈরি করুন: ইউটিউব বা টিকটক কন্টেন্ট এর জন্য ব্যাকগ্রাউন্ড সিনেমাটিক ভিডিও মেকার।")}
                  {mediaType === "voice" && (isEn ? "Convert standard script into professional English or Bangla voices using deep actor models." : "কণ্ঠ তৈরি করুন: বাংলা বা ইংলিশ ভয়েস ওভার জেনারেটর প্রফেশনাল স্পিকার মডেলে।")}
                  {mediaType === "music" && (isEn ? "Generate unique high-fidelity lo-fi loops and digital assets background tracks." : "মিউজিক মেকার: লোগো বা থাম্বনেইলের ইন্ট্রো ব্যাকগ্রাউন্ড সাউন্ডট্র্যাক জেনারেটর।")}
                  {mediaType === "avatar" && (isEn ? "Generate complete virtual model presentations with lip-sync animations." : "এআই অবতার ও লিপ সিঙ্ক: কথা বলা মানুষের কৃত্রিম চরিত্র তৈরি ও অডিও সিঙ্ক।")}
                </p>

                <div className="space-y-3">
                  <textarea
                    rows={2}
                    value={mediaPrompt}
                    onChange={(e) => setMediaPrompt(e.target.value)}
                    placeholder={isEn ? `Enter ${mediaType} style guidelines or script prompt...` : `মিডিয়ার বিবরণ বা স্ক্রিপ্ট লিখুন...`}
                    className="w-full text-xs bg-black/40 border border-white/5 focus:border-purple-500/30 rounded-xl px-3 py-2 text-white outline-none resize-none font-sans"
                  />
                  <button 
                    onClick={handleRunMediaGen}
                    disabled={isGeneratingMedia || !mediaPrompt.trim()}
                    className="w-full py-2.5 bg-gradient-to-r from-purple-600 to-indigo-600 font-bold uppercase text-xs rounded-xl text-white cursor-pointer active:scale-95 transition-all text-center flex items-center justify-center gap-1.5"
                  >
                    {isGeneratingMedia ? (
                      <>
                        <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                        <span>Rendering Media...</span>
                      </>
                    ) : (
                      <>
                        <Sparkles className="w-3.5 h-3.5" />
                        <span>Compile {mediaType.toUpperCase()} Spec</span>
                      </>
                    )}
                  </button>
                </div>

                {/* Media generation result visual mockups */}
                {generatedMediaOutput && (
                  <div className="p-4 bg-black/60 border border-purple-500/15 rounded-xl space-y-3.5">
                    {mediaType === "video" && (
                      <div className="space-y-2 text-xs">
                        <div className="relative rounded-lg overflow-hidden border border-white/10 aspect-video bg-zinc-900 flex items-center justify-center">
                          <img src={generatedMediaOutput.videoPlaceholderUrl} alt="Generative frame proof" referrerPolicy="no-referrer" className="w-full h-full object-cover opacity-80" />
                          <div className="absolute top-2 left-2 px-2.5 py-1 bg-black/70 border border-white/5 rounded text-[9px] font-mono font-bold uppercase text-purple-400">FPS: {generatedMediaOutput.fps}</div>
                          <span className="w-10 h-10 rounded-full bg-white/20 backdrop-blur border border-white/40 flex items-center justify-center cursor-pointer hover:scale-115 transition-all">
                            <Play className="w-4 h-4 text-white fill-current" />
                          </span>
                        </div>
                        <div className="font-mono text-[10px] text-gray-400 space-y-0.5">
                          <div>Prompt: <span className="text-zinc-200">{generatedMediaOutput.prompt}</span></div>
                          <div>Duration: <span className="text-zinc-200">{generatedMediaOutput.duration}</span></div>
                          <div>Motion: <span className="text-zinc-200">{generatedMediaOutput.motionVector}</span></div>
                        </div>
                      </div>
                    )}

                    {mediaType === "voice" && (
                      <div className="space-y-3 text-xs">
                        <div className="p-3 bg-white/5 border border-white/5 rounded-xl flex items-center justify-between gap-3">
                          <div className="flex items-center gap-2">
                            <button 
                              onClick={() => {
                                setIsPlayingAudio(!isPlayingAudio);
                                if (!isPlayingAudio) {
                                  setTimeout(() => setIsPlayingAudio(false), 3000);
                                }
                              }}
                              className="w-8 h-8 rounded-full bg-emerald-500 flex items-center justify-center text-black cursor-pointer hover:bg-emerald-400 transition-all shrink-0"
                            >
                              {isPlayingAudio ? (
                                <span className="text-xs font-black">■</span>
                              ) : (
                                <Play className="w-4.5 h-4.5 fill-current text-zinc-950 ml-0.5" />
                              )}
                            </button>
                            <div>
                              <div className="font-mono text-[10px] text-gray-400">Voice Actor: <span className="text-white font-bold">{generatedMediaOutput.speaker}</span></div>
                              <div className="text-[9px] text-zinc-500">{generatedMediaOutput.sampleRate}</div>
                            </div>
                          </div>
                          
                          {/* Pulsing Audio waveform mock animation when playing */}
                          <div className="flex items-end gap-0.5 h-6">
                            {[1, 2, 3, 4, 3, 2, 3, 4, 5, 2, 1, 3, 4, 2, 1].map((h, i) => (
                              <div 
                                key={i} 
                                className="w-0.5 bg-emerald-400 transition-all rounded-full" 
                                style={{ height: isPlayingAudio ? `${h * 20}%` : "15%" }}
                              />
                            ))}
                          </div>
                        </div>
                      </div>
                    )}

                    {mediaType === "music" && (
                      <div className="space-y-3 text-xs">
                        <div className="p-3 bg-white/5 border border-white/5 rounded-xl space-y-2">
                          <div className="flex justify-between font-mono text-[10px]">
                            <span className="text-indigo-400">⭐ {generatedMediaOutput.bpm} BPM Lo-Fi</span>
                            <span className="text-gray-500">HI-RES METADATA</span>
                          </div>
                          <p className="text-gray-300 text-xs italic">&ldquo;{generatedMediaOutput.genre}&rdquo;</p>
                          <div className="space-y-1 pt-1.5 border-t border-white/5 text-[10px] font-mono text-gray-500">
                            {generatedMediaOutput.structures.map((val: string, id: number) => (
                              <div key={id} className="flex gap-1.5 items-center">
                                <span className="w-1.5 h-1.5 bg-indigo-500 rounded-full" />
                                <span>{val}</span>
                              </div>
                            ))}
                          </div>
                        </div>
                      </div>
                    )}

                    {mediaType === "avatar" && (
                      <div className="space-y-3 text-xs">
                        <div className="p-3 bg-white/5 border border-white/5 rounded-xl space-y-2 font-mono text-[10px]">
                          <div className="flex justify-between items-center text-[10px] text-zinc-400">
                            <span>Presenter Mesh</span>
                            <span className="text-emerald-400 font-bold font-mono">READY</span>
                          </div>
                          <div>Avatar: <span className="text-white font-bold">{generatedMediaOutput.avatarName}</span></div>
                          <div>Expression Style: <span className="text-gray-300">{generatedMediaOutput.expression}</span></div>
                          <p className="text-[9px] text-zinc-600 mt-1 uppercase italic">LipSync Mesh coordinates aligned in index.</p>
                        </div>
                      </div>
                    )}
                  </div>
                )}
              </div>

              {/* Box 2: Creative Sandbox Builder */}
              <div className="bg-[#121212] border border-white/5 rounded-2xl p-6 space-y-4">
                <div className="flex items-center gap-2 border-b border-white/5 pb-2.5">
                  <Layers className="w-4 h-4 text-emerald-400" />
                  <h3 className="text-sm font-bold font-mono text-white uppercase">{isEn ? "AI Product & Code Sandbox" : "কোড ও প্রোডাক্ট স্যান্ডবক্স"}</h3>
                </div>

                <div className="flex bg-black/40 border border-white/5 p-1 rounded-xl">
                  {(["app", "website", "game"] as const).map((tool) => (
                    <button
                      key={tool}
                      onClick={() => setSandboxTool(tool)}
                      className={`flex-1 py-1.5 rounded-lg text-[10px] font-mono font-bold cursor-pointer uppercase transition-all ${
                        sandboxTool === tool ? "bg-emerald-600 text-white" : "text-gray-400 hover:text-white"
                      }`}
                    >
                      {tool}
                    </button>
                  ))}
                </div>

                <p className="text-xs text-gray-500 font-sans leading-relaxed">
                  {sandboxTool === "app" && (isEn ? "Generate responsive application structures (calorie counters, calculators, trackers) compiled in container state." : "অ্যাপ বিল্ডার: রিয়েল-টাইম ক্যালকুলেটর বা ট্র্যাকার ইন্টারফেস তৈরি ও প্রাকদর্শন।")}
                  {sandboxTool === "website" && (isEn ? "Build luxury product headers, layout structures, and visual landing pages in modern markup." : "ওয়েবসাইট মেকার: ল্যান্ডিং পেজ, গ্লাস মরফিজম পোর্টাল ও সলিড কালার ক্যানভাস।")}
                  {sandboxTool === "game" && (isEn ? "Render working miniature HTML5/CSS canvas shooting or click challenges instantly." : "গেম মেকার: ইন্টারেক্টিভ ক্যানভাস স্পেস শুটার চ্যালেঞ্জ প্লেয়েবল গেম।")}
                </p>

                <div className="space-y-3">
                  <input
                    type="text"
                    value={sandboxPrompt}
                    onChange={(e) => setSandboxPrompt(e.target.value)}
                    placeholder="Enter visual target goal description..."
                    className="w-full text-xs bg-black/40 border border-white/5 focus:border-emerald-500/30 rounded-xl px-3 py-2 text-white outline-none font-sans"
                  />
                  <button 
                    onClick={handleSandboxCompile}
                    disabled={isSandboxCompiling || !sandboxPrompt.trim()}
                    className="w-full py-2.5 bg-gradient-to-r from-emerald-600 to-cyan-600 font-bold uppercase text-xs rounded-xl text-white cursor-pointer active:scale-95 transition-all text-center flex items-center justify-center gap-1.5"
                  >
                    {isSandboxCompiling ? (
                      <>
                        <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                        <span>Compiling Build...</span>
                      </>
                    ) : (
                      <>
                        <Play className="w-3.5 h-3.5 fill-current" />
                        <span>Prompt &rarr; Sandboxed Product</span>
                      </>
                    )}
                  </button>
                </div>

                {/* Compiled Interactive Result Preview container */}
                {compiledSandboxResultList && (
                  <div className="space-y-3 pt-2">
                    <span className="text-[10px] text-gray-500 font-mono uppercase block text-left">Compiled Sandbox Dynamic Render Frame:</span>
                    <div className="p-4 bg-teal-950/10 border border-emerald-500/15 rounded-2xl relative">
                      <div className="absolute top-2 left-2 px-2 py-0.5 bg-emerald-500/10 border border-emerald-500/20 text-[9px] font-mono text-emerald-400 rounded">LIVE SANBOX INTERACTIVE</div>
                      <div className="mt-6">
                        <div dangerouslySetInnerHTML={{ __html: compiledSandboxResultList.iframeMockHtml }} />
                      </div>
                    </div>
                  </div>
                )}
              </div>

            </div>
          </div>
        )}

        {/* ==========================================
            INNER TAB: TREND RADAR & ANALYZER
            ========================================== */}
        {innerTab === "radar" && (
          <div className="space-y-8 text-left" id="trend-radar-analyzer">
            
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
              
              {/* Left Column: Trend Radar sweeping indicators */}
              <div className="lg:col-span-5 bg-[#121212] border border-white/5 rounded-2xl p-5 space-y-5">
                <div className="flex justify-between items-center border-b border-white/5 pb-2.5">
                  <span className="text-xs font-mono font-bold text-indigo-400 flex items-center gap-1.5">
                    <TrendingUp className="w-4 h-4 text-indigo-400" />
                    <span>Real-Time Social Trend Radar</span>
                  </span>
                  <span className="w-2.5 h-2.5 rounded-full bg-indigo-500 animate-ping"></span>
                </div>

                <p className="text-xs text-gray-500 leading-relaxed font-sans">
                  {isEn 
                    ? "Continuous active monitoring sweeps matching click-through hashtags, adopting curves, and CTR indices across social channels."
                    : "ইউটিউব, টিকটক এবং ইন্সটাগ্রাম ট্রেন্ড ট্র্যাকার। বাজার চাহিদা ও ট্রেন্ডিং হ্যাশট্যাগ সমূহের লাইভ পরিবর্তন ট্র্যাক করুন।"}
                </p>

                {/* Simulated sweeps animation indicator */}
                <div className="relative h-20 bg-black border border-white/5 rounded-2xl overflow-hidden flex items-center justify-center">
                  <div className="absolute inset-0 bg-gradient-to-r from-indigo-500/5 via-cyan-500/5 to-transparent animate-[pulse_2s_infinite]"></div>
                  <div className="absolute top-0 bottom-0 left-1/2 w-0.5 bg-indigo-500/40 animate-[spin_4s_linear_infinite] origin-center"></div>
                  <span className="font-mono text-[10px] text-zinc-500 tracking-widest uppercase">SCANNING TREND METRICS INDICES</span>
                </div>

                <div className="space-y-3">
                  {trends.map((item, idx) => (
                    <div key={idx} className="p-3 bg-black/40 border border-white/5 rounded-xl flex justify-between items-center text-xs">
                      <div className="space-y-0.5">
                        <span className="font-mono font-bold text-gray-200">{item.tag}</span>
                        <span className="block text-[9px] text-zinc-500">{item.channel}</span>
                      </div>
                      <div className="text-right">
                        <span className="block font-mono text-indigo-400 font-bold">{item.ctr}% CTR Impact</span>
                        <span className="text-[9px] text-emerald-400 italic">⭐ High Adoption ({item.rate}%)</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Center Column: Visual screenshot UI layout analyzer with drop indicators */}
              <div className="lg:col-span-7 space-y-6">
                
                <div className="bg-[#121212] border border-white/5 rounded-2xl p-6 space-y-4">
                  <div className="flex items-center gap-2 border-b border-white/5 pb-2.5">
                    <Eye className="w-4 h-4 text-purple-400 animate-pulse" />
                    <h3 className="text-sm font-bold font-mono text-white uppercase">{isEn ? "Visual Intelligence Screen Analyzer" : "ভিজ্যুয়াল ইন্টেলিজেন্স স্ক্রিন এনালাইজার"}</h3>
                  </div>

                  <p className="text-xs text-gray-500 leading-relaxed font-sans">
                    {isEn 
                      ? "Select/upload a layout below. The computer sensory engine immediately overlays feedback pins highlighting alignment errors and conversion flaws."
                      : "যেকোনো স্ক্রিনশট বা লোগো সিলেক্ট বা ড্র্যাগ করুন। এআই স্বয়ংক্রিয়ভাবে ডিজাইন লেআউট এর ভুলত্রুটি পিন পয়েন্টের মাধ্যমে এনালাইজ করে দেবে।"}
                  </p>

                  <div className="flex bg-black/40 border border-white/5 p-1 rounded-xl">
                    {(["thumbnail", "landing", "logo"] as const).map((type) => (
                      <button
                        key={type}
                        onClick={() => { setSelectedScreenshotType(type); setAnalyzedStructure(null); }}
                        className={`flex-1 py-1.5 rounded-lg text-[10px] font-mono font-bold cursor-pointer uppercase transition-all ${
                          selectedScreenshotType === type ? "bg-purple-600 text-white" : "text-gray-400 hover:text-white"
                        }`}
                      >
                        {type} Screenshot
                      </button>
                    ))}
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 items-center">
                    
                    {/* Mock screenshot visually with coordinate points overlay */}
                    <div className="relative rounded-xl overflow-hidden border border-white/10 bg-zinc-900 group aspect-video">
                      <img src={mockScreenshots[selectedScreenshotType]} alt="Asset to be analyzed" referrerPolicy="no-referrer" className="w-full h-full object-cover opacity-70" />
                      
                      {/* Interactive Pin Overlays */}
                      {analyzedStructure && analyzedStructure.hotspots?.map((hs: any, id: number) => (
                        <div 
                          key={id}
                          className="absolute w-5 h-5 rounded-full bg-rose-500 border border-white flex items-center justify-center text-[10px] font-bold text-white cursor-pointer select-none shadow-lg outline-none"
                          style={{ left: hs.x, top: hs.y }}
                          title={hs.label}
                          onClick={() => alert(`Indicator Point ${id + 1}:\n${hs.label}`)}
                        >
                          {id + 1}
                        </div>
                      ))}

                      {isAnalyzingScreenshot && (
                        <div className="absolute inset-0 bg-black/70 flex flex-col justify-center items-center gap-2">
                          <RefreshCw className="w-6 h-6 text-purple-400 animate-spin" />
                          <span className="text-[10px] font-mono text-zinc-400">Scanning UI layout coordinates...</span>
                        </div>
                      )}
                    </div>

                    <div className="space-y-3">
                      <button 
                        onClick={handleAnalyzeScreenshot}
                        disabled={isAnalyzingScreenshot}
                        className="w-full py-2.5 bg-gradient-to-r from-purple-600 to-indigo-600 font-bold uppercase text-xs rounded-xl text-white cursor-pointer active:scale-95 transition-all text-center flex items-center justify-center gap-1.5"
                      >
                        <Zap className="w-3.5 h-3.5" />
                        <span>Run Visual Audit Scan</span>
                      </button>

                      {analyzedStructure && (
                        <div className="p-4 bg-zinc-950/70 border border-zinc-900 rounded-xl text-xs space-y-2 text-left">
                          <div className="flex justify-between font-mono text-[10px]">
                            <span className="text-zinc-500">RESOLVING KPI</span>
                            <span className="text-[#10b981] font-bold font-mono">{analyzedStructure.flawScore}</span>
                          </div>
                          <div>Dimensions: <span className="text-white font-mono">{analyzedStructure.dimensions}</span></div>
                          
                          <div className="space-y-1.5 border-t border-white/5 pt-2">
                            <span className="block text-[9px] text-rose-400 font-mono uppercase font-bold">Action Guides:</span>
                            {analyzedStructure.improvementGuides.map((guide: string, id: number) => (
                              <div key={id} className="text-zinc-300 text-[11px] leading-relaxed flex gap-1 items-start">
                                <span className="text-rose-400 block mt-0.5 shrink-0">&bull;</span>
                                <span className="font-sans">{guide}</span>
                              </div>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                </div>

                {/* Future simulation & Success Predictor */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-6">
                  
                  {/* Futuristic Simulator */}
                  <div className="bg-[#121212] border border-white/5 rounded-2xl p-5 space-y-4">
                    <span className="text-xs font-mono font-bold text-amber-400 flex items-center gap-1.5 border-b border-white/5 pb-2">
                      <Sliders className="w-3.5 h-3.5 text-amber-500" />
                      <span>Future Design Trend Simulator</span>
                    </span>
                    <p className="text-[11px] text-gray-500 leading-normal font-sans">
                      Predict how your brand assets fit into year 2027 or 2030 design requirements.
                    </p>
                    <div className="space-y-3">
                      <input 
                        type="text"
                        value={futuristicInput}
                        onChange={(e) => setFuturisticInput(e.target.value)}
                        className="w-full text-xs bg-zinc-950 border border-white/5 rounded-xl px-2.5 py-2 text-white outline-none select-text"
                        placeholder="Mascot or asset name"
                      />
                      <div className="flex gap-2 text-xs">
                        {[2027, 2028, 2030].map((yr) => (
                          <button
                            key={yr}
                            onClick={() => setFuturisticYear(yr)}
                            className={`flex-1 py-1 rounded-lg font-mono cursor-pointer transition-all ${yr === futuristicYear ? "bg-amber-600 text-white" : "bg-zinc-900 text-zinc-400"}`}
                          >
                            {yr}
                          </button>
                        ))}
                      </div>
                      <button 
                        onClick={handleSimulateFuture}
                        className="w-full py-1.5 bg-zinc-800 hover:bg-zinc-700 text-white rounded-lg text-xs font-mono font-bold transition-all uppercase cursor-pointer"
                      >
                        {isSimulatingFuture ? "Simulating..." : "Generate Simulation Diff"}
                      </button>

                      {futureSimulationResult && (
                        <div className="p-3.5 bg-black/40 border border-white/10 rounded-xl space-y-2 text-xs">
                          <div className="font-mono text-[9px] text-[#D4AF37] font-bold">YEAR {futureSimulationResult.year} PREDICTED CRITERIA:</div>
                          <p className="text-zinc-300 leading-relaxed font-sans">{futureSimulationResult.predictedStyleVibe}</p>
                          <div className="font-mono text-[9px] text-zinc-500 uppercase italic">{futureSimulationResult.futureCtrForecast}</div>
                        </div>
                      )}
                    </div>
                  </div>

                  {/* AI Success Predictor */}
                  <div className="bg-[#121212] border border-white/5 rounded-2xl p-5 space-y-4">
                    <span className="text-xs font-mono font-bold text-emerald-400 flex items-center gap-1.5 border-b border-white/5 pb-2">
                      <ShieldCheck className="w-3.5 h-3.5 text-emerald-500" />
                      <span>AI Success Predictor Score</span>
                    </span>
                    <p className="text-[11px] text-gray-500 leading-normal font-sans">
                      Let AI forecast crucial satisfaction rates, virality, and conversion values.
                    </p>
                    <div className="space-y-3 font-sans text-xs">
                      <input 
                        type="text"
                        value={projectTitleToPredict}
                        onChange={(e) => setProjectTitleToPredict(e.target.value)}
                        className="w-full text-xs bg-zinc-950 border border-white/5 rounded-xl px-2.5 py-2 text-white outline-none select-text"
                        placeholder="Branding system criteria spec..."
                      />
                      <button 
                        onClick={handlePredictSuccess}
                        className="w-full py-1.5 bg-[#10b981]/15 hover:bg-[#10b981]/25 border border-[#10b981]/20 text-emerald-400 rounded-lg text-xs font-mono font-bold transition-all uppercase cursor-pointer"
                      >
                        {isPredictingSuccess ? "Calculating CTR..." : "Predict Success Metrics"}
                      </button>

                      {successPrediction && (
                        <div className="p-3.5 bg-black/40 border border-white/5 rounded-xl space-y-2 text-xs">
                          <div className="grid grid-cols-2 gap-2 text-center text-[10px] font-mono">
                            <div className="p-1.5 bg-zinc-900 border border-zinc-800 rounded">
                              <span className="block text-zinc-500 font-mono uppercase">Satisfaction</span>
                              <span className="font-semibold text-emerald-400 text-xs">{successPrediction.satisfaction}%</span>
                            </div>
                            <div className="p-1.5 bg-zinc-900 border border-zinc-800 rounded">
                              <span className="block text-zinc-500 font-mono uppercase">Viral Chance</span>
                              <span className="font-semibold text-purple-400 text-xs">{successPrediction.viralChance}%</span>
                            </div>
                            <div className="p-1.5 bg-zinc-900 border border-zinc-800 rounded">
                              <span className="block text-zinc-500 font-mono uppercase">Engagement</span>
                              <span className="font-semibold text-[#D4AF37] text-xs">{successPrediction.engagement}/100</span>
                            </div>
                            <div className="p-1.5 bg-zinc-900 border border-zinc-800 rounded">
                              <span className="block text-zinc-500 font-mono uppercase">Conversion</span>
                              <span className="font-semibold text-indigo-400 text-xs">{successPrediction.conversion}%</span>
                            </div>
                          </div>
                          <p className="text-[10px] text-zinc-400 leading-normal italic font-sans">&ldquo;{successPrediction.remark}&rdquo;</p>
                        </div>
                      )}
                    </div>
                  </div>

                </div>

              </div>

            </div>
          </div>
        )}

        {/* ==========================================
            INNER TAB: PERSONAL AI TWIN & ACADEMY
            ========================================== */}
        {innerTab === "galaxy" && (
          <div className="space-y-8 text-left" id="ai-personal-twin-space">
            
            {/* Creative DNA Engine (Persistent Designer DNA Profile) */}
            <CreativeDnaEngine 
              lang={lang} 
              credits={credits} 
              deductCredits={deductCredits} 
              onDnaSynced={() => {
                // Instantly sync telemetry actions inside Digital Twin
                setCloneActions(prev => [
                  `🤖 [Digital Twin]: DNA Genome parsed. Synchronized design aesthetic guidelines standard!`,
                  ...prev.slice(0, 10)
                ]);
              }}
            />

            {/* Split row matching Digital Twin and Design Genome Profiles */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-start">
              
              {/* Box 1: Digital Twin Creator */}
              <div className="bg-[#121212] border border-white/5 rounded-2xl p-6 space-y-4">
                <div className="flex justify-between items-center border-b border-white/5 pb-2.5">
                  <span className="text-xs font-mono font-bold text-amber-400 flex items-center gap-1.5">
                    <Database className="w-4 h-4 text-amber-500 animate-pulse" />
                    <span>Personal Digital Twin (AI Clone)</span>
                  </span>
                  
                  {/* Offline Active switches Toggle */}
                  <label className="relative inline-flex items-center cursor-pointer font-sans select-none">
                    <input 
                      type="checkbox" 
                      className="sr-only peer"
                      checked={cloneAutonomousMode}
                      onChange={() => setCloneAutonomousMode(!cloneAutonomousMode)}
                    />
                    <div className="w-9 h-5 bg-zinc-800 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-350 after:border after:rounded-full after:h-4 after:width-4 after:transition-all peer-checked:bg-amber-600"></div>
                    <span className="ml-1.5 text-[10px] uppercase font-mono text-zinc-500 font-bold">{cloneAutonomousMode ? "Autonomous" : "Inactive"}</span>
                  </label>
                </div>

                <p className="text-xs text-gray-400 leading-relaxed font-sans mt-1">
                  {isEn 
                    ? "Your personal AI Clone learns prompt structures, palette design habits, and visual models automatically. Switch on autonomous worker mode to let your twin close freelance contracts continuously."
                    : "আপনার এআই ক্লোন ক্রিয়েটিভ গাইডলাইনসমূহ নিজে নিজে শেখে। আপনি অফলাইনে থাকলেও এটি ব্যাকগ্রাউন্ডে ফ্রিল্যান্স অর্ডার অটোনমাসলি কমপ্লিট করবে।"}
                </p>

                {/* Simulated background log of digital twin operations */}
                <div className="p-4 bg-zinc-950/70 border border-zinc-900 rounded-xl space-y-2.5">
                  <div className="flex justify-between items-center text-[10px] font-mono text-zinc-500 border-b border-white/5 pb-1.5">
                    <span>DIGITAL CLONE TELEMETRY LOG</span>
                    <span className="text-amber-400 font-bold">{cloneAutonomousMode ? "ACTIVE AUTOPILOT WORKING" : "CLONE SLEEP"}</span>
                  </div>
                  
                  <div className="space-y-1 max-h-36 overflow-y-auto pr-1">
                    {cloneActions.map((act, id) => (
                      <div key={id} className="text-[10px] font-mono text-zinc-400 leading-normal">{act}</div>
                    ))}
                  </div>
                </div>

                {cloneAutonomousMode && (
                  <div className="p-4 bg-amber-600/10 border border-amber-500/20 rounded-xl space-y-2">
                    <span className="text-[10px] text-amber-400 font-mono uppercase block font-bold">Autonomous Earnings by AI Twin:</span>
                    <div className="space-y-1.5">
                      {autonomousEarningLog.map((logItem, index) => (
                        <div key={index} className="flex justify-between items-center text-[11px] font-mono text-gray-300">
                          <span>{logItem.action}</span>
                          <span className="text-emerald-400 font-bold">+{logItem.earned} Credits</span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>

              {/* Box 2: Designer Genome Extra Insights */}
              <div className="bg-[#121212] border border-white/5 rounded-2xl p-6 space-y-4">
                <div className="flex items-center gap-2 border-b border-white/5 pb-2.5">
                  <Sliders className="w-4 h-4 text-purple-400" />
                  <h3 className="text-sm font-bold font-mono text-white uppercase">{isEn ? "Design Affinity Weights" : "ডিজাইন এফিনিটি ইনডেক্স"}</h3>
                </div>

                <p className="text-xs text-gray-450 leading-relaxed font-sans mt-1">
                  {isEn
                    ? "Active stylistic metrics computed against top trending layout formulas in 2026. Higher accuracy matches boost prompt execution limits."
                    : "বর্তমান ট্রেন্ডিং লেআউট ফর্মুলার সাথে সুনির্দিষ্ট ফিটিং স্কোর। মান যত বেশি থাকবে, প্রম্পট জেনারেটর তত নিখুঁত আউটপুট দেবে।"}
                </p>

                <div className="space-y-3 pt-1">
                  {[
                    { label: "Display Accent Style (Midnight Gold VVIP)", val: 92, stat: "Prestige Minimal Lux" },
                    { label: "Typography Weight Favor (Bold Serif display)", val: 85, stat: "Space Grotesk display paired with Inter" },
                    { label: "Aspect Ratios Scale (Dynamic 16:9 thumbnails)", val: 78, stat: "High contrast YouTube focus layouts" },
                  ].map((dnaItem, id) => (
                    <div key={id} className="p-3 bg-black/40 border border-white/5 rounded-xl space-y-1.5">
                      <div className="flex justify-between text-xs font-sans">
                        <span className="text-gray-300 font-semibold">{dnaItem.label}</span>
                        <span className="font-mono text-purple-400 font-bold">{dnaItem.val}% Match</span>
                      </div>
                      <div className="w-full h-1 bg-zinc-900 rounded-full overflow-hidden">
                        <div className="h-full bg-purple-500 rounded-full" style={{ width: `${dnaItem.val}%` }} />
                      </div>
                      <span className="block text-[9px] text-zinc-500 font-mono uppercase mt-0.5">Calculated Affinity: {dnaItem.stat}</span>
                    </div>
                  ))}
                </div>
              </div>

            </div>

            {/* Project Version Control (Project Time Machine) */}
            <div className="bg-[#121212] border border-white/5 rounded-3xl p-6 sm:p-8 space-y-5 text-left">
              <span className="px-3 py-1 bg-blue-500/10 border border-blue-500/20 text-[10px] font-mono text-blue-400 rounded-full uppercase tracking-wider">⏳ Project Time Machine (Version Restore)</span>
              <h3 className="text-md sm:text-lg font-bold text-white uppercase mt-1">{isEn ? "Historic Project Versioning & Evolution Diff" : "প্রজেক্ট টাইম মেশিন ও ভার্সন কন্ট্রোল"}</h3>
              <p className="text-xs text-gray-400 font-sans leading-relaxed">
                Compare past layout versions, analyze contrasting shifts, and restore optimal configurations safely in one click.
              </p>

              <div className="flex flex-col sm:flex-row gap-4 items-center">
                <div className="flex items-center gap-2 text-xs">
                  <span className="text-gray-500 font-mono">Ver A:</span>
                  <select 
                    value={selectedVerA} 
                    onChange={(e) => setSelectedVerA(e.target.value)}
                    className="p-1 px-2.5 bg-black border border-white/10 rounded-lg text-gray-300 font-mono text-xs"
                  >
                    {timeMachineVersions.map(v => (
                      <option key={v.ver} value={v.ver}>{v.ver} ({v.date})</option>
                    ))}
                  </select>
                </div>

                <div className="flex items-center gap-2 text-xs">
                  <span className="text-gray-500 font-mono">Ver B:</span>
                  <select 
                    value={selectedVerB} 
                    onChange={(e) => setSelectedVerB(e.target.value)}
                    className="p-1 px-2.5 bg-black border border-white/10 rounded-lg text-gray-300 font-mono text-xs"
                  >
                    {timeMachineVersions.map(v => (
                      <option key={v.ver} value={v.ver}>{v.ver} ({v.date})</option>
                    ))}
                  </select>
                </div>

                <button 
                  onClick={handleCompareVersions}
                  className="px-4 py-1.5 bg-blue-600 hover:bg-blue-500 border border-blue-500/20 text-white rounded-lg text-xs font-mono font-bold transition-all cursor-pointer"
                >
                  Analyze Evolution Diff
                </button>
              </div>

              {timeMachineCompareResult && (
                <div className="p-4 bg-black/40 border border-blue-500/15 rounded-xl text-xs text-left text-zinc-300 whitespace-pre-line leading-relaxed font-mono">
                  {timeMachineCompareResult}
                </div>
              )}
            </div>

            {/* AI Academy and Design University Section */}
            <div className="bg-gradient-to-r from-[#110f22] to-[#120f2e] border border-purple-500/15 rounded-3xl p-6 sm:p-8 space-y-6">
              <div className="border-b border-white/5 pb-3">
                <span className="px-3 py-1 bg-purple-500/10 border border-purple-500/20 text-[10px] text-purple-400 font-mono tracking-widest uppercase rounded-full">🏛️ AI Design University & Academy</span>
                <h3 className="text-lg font-bold font-mono text-white uppercase mt-2">{isEn ? "Personalized Path to Creative Mastery" : "এআই ডিজাইন ইউনিভার্সিটি ও লার্নিং পাথ"}</h3>
                <p className="text-xs text-gray-400 font-sans mt-0.5 leading-relaxed max-w-xl">
                  Identify active skill gaps, claim professional certification badges, and complete Daily Creative Challenges continuously.
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-left">
                
                {/* Audit Item 1: Skills progression */}
                <div className="p-4 bg-black/40 border border-white/5 rounded-2xl space-y-3">
                  <span className="text-xs font-mono font-bold text-amber-400 block border-b border-white/5 pb-1.5">1. Active Skill Gap Audit</span>
                  <div className="space-y-2">
                    <div>
                      <div className="flex justify-between text-[11px] text-gray-400 font-sans">
                        <span>High-Contrast Typography</span>
                        <span className="text-emerald-400 font-bold">85% Cleared</span>
                      </div>
                      <div className="w-full h-1 bg-zinc-900 rounded-full mt-1"><div className="h-full bg-emerald-500 rounded-full" style={{ width: "85%" }} /></div>
                    </div>
                    <div>
                      <div className="flex justify-between text-[11px] text-gray-400 font-sans">
                        <span>Vite SPA Sandboxing</span>
                        <span className="text-purple-400 font-bold">42% (Need Work)</span>
                      </div>
                      <div className="w-full h-1 bg-zinc-900 rounded-full mt-1"><div className="h-full bg-purple-500 rounded-full" style={{ width: "42%" }} /></div>
                    </div>
                  </div>
                </div>

                {/* Audit Item 2: Certifications badges */}
                <div className="p-4 bg-black/40 border border-white/5 rounded-2xl space-y-3">
                  <span className="text-xs font-mono font-bold text-indigo-400 block border-b border-white/5 pb-1.5">2. Certification System</span>
                  <div className="flex gap-2.5 items-center">
                    <div className="p-2.5 bg-indigo-500/10 border border-indigo-500/20 rounded-xl">
                      <Award className="w-6 h-6 text-indigo-400" />
                    </div>
                    <div>
                      <div className="text-xs font-bold text-gray-200">Prestige Brand Strategist Badge</div>
                      <div className="text-[10px] text-zinc-500 font-mono uppercase italic">UNIVERISTY GRANTED MAY 2026</div>
                    </div>
                  </div>
                </div>

                {/* Audit Item 3: Daily Challenge board */}
                <div className="p-4 bg-black/40 border border-white/5 rounded-2xl space-y-3">
                  <span className="text-xs font-mono font-bold text-rose-400 block border-b border-white/5 pb-1.5">3. Daily Creative Challenge</span>
                  <p className="text-[11px] text-zinc-400 leading-normal italic font-sans">{dailyChallengeText}</p>
                  <button 
                    onClick={() => {
                      setDailyChallengeCompleted(true);
                      alert("Stellar work! Completed challenge saved to portfolio with double score impact.");
                    }}
                    disabled={dailyChallengeCompleted}
                    className="w-full py-1.5 bg-[#f43f5e]/15 hover:bg-[#f43f5e]/25 border border-[#f43f5e]/20 text-rose-450 rounded-lg text-xs font-mono tracking-wide uppercase cursor-pointer"
                  >
                    {dailyChallengeCompleted ? "✓ Challenge Completed (+50 XP)" : "Submit Completed Draft"}
                  </button>
                </div>

              </div>

            </div>

          </div>
        )}
      </div>

    </div>
  );
}
