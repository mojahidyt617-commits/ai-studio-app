/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from "react";
import { TRANSLATIONS, LanguageCode } from "./lib/translations";
import { 
  AICharacter, ThumbnailSpec, PromptSpec, GenerationHistoryItem, UserProfile,
  InspirationSpec, BrandSpec, ColorPaletteSpec 
} from "./types";
import LoginModule from "./components/LoginModule";
import CharacterModule from "./components/CharacterModule";
import ThumbnailModule from "./components/ThumbnailModule";
import PromptModule from "./components/PromptModule";
import CreditLogModule from "./components/CreditLogModule";
import InspirationHubModule from "./components/InspirationHubModule";
import BrandGeneratorModule from "./components/BrandGeneratorModule";
import ColorGeneratorModule from "./components/ColorGeneratorModule";
import StudioSuiteModule from "./components/StudioSuiteModule";
import CriticCoachModule from "./components/CriticCoachModule";
import FreelanceToolkitModule from "./components/FreelanceToolkitModule";
import CommunityAssetsModule from "./components/CommunityAssetsModule";
import QuantumAgentModule from "./components/QuantumAgentModule";
import { 
  Sparkles, Globe, LogOut, Coins, Laptop, User, Layout, 
  Terminal, BarChart3, HelpCircle, Activity, Play, PlusCircle,
  Compass, Award, Palette, Gauge, DollarSign, Users, PenTool, Brain
} from "lucide-react";

export default function App() {
  // 1. Core User Auth state
  const [profile, setProfile] = useState<UserProfile>(() => {
    try {
      const saved = localStorage.getItem("ai_creator_profile");
      if (saved) return JSON.parse(saved);
    } catch {}
    return {
      username: "",
      credits: 100,
      isLoggedIn: false,
      avatarSeed: "avatar_" + Math.floor(Math.random() * 100),
      joinedAt: new Date().toISOString()
    };
  });

  // 2. Language localization state
  const [lang, setLang] = useState<LanguageCode>(() => {
    try {
      const saved = localStorage.getItem("ai_creator_lang");
      if (saved === "bn" || saved === "en") return saved;
    } catch {}
    return "en";
  });

  // 3. Tab navigation state
  const [activeTab, setActiveTab] = useState<"quantum" | "character" | "thumbnail" | "prompt" | "inspiration" | "brand" | "color" | "studiosuite" | "criticoach" | "freelance" | "communityhub" | "credits">("quantum");

  // 4. Historical generated objects lists
  const [recentCharacters, setRecentCharacters] = useState<AICharacter[]>(() => {
    try {
      const saved = localStorage.getItem("ai_creator_chars");
      if (saved) return JSON.parse(saved);
    } catch {}
    return [
      {
        id: "char_1",
        name: "Ayon Chandra",
        gender: "male",
        classType: "Cyber Ranger",
        tagline: "Coding with lightning speed across Dhaka's neon paths",
        backstory: "A cyber-savvy graphics wizard who grew up designing in local agencies, now mastering neural prompts and vector layers.",
        stats: { strength: 65, agility: 88, intellect: 95, charisma: 75, luck: 60 },
        abilities: [
          { name: "Neon Glaze", description: "Blinds trackers with sharp vector highlights", powerCost: 15, abilityType: "Buff" }
        ],
        visualPrompt: "Futuristic tech freelancer with neon specs, posing with cyberpunk glowing mechanical stylus pen",
        themeColor: "#D4AF37",
        createdAt: "2026-05-20T10:00:00Z"
      },
      {
        id: "char_2",
        name: "Nabila Shadowbane",
        gender: "female",
        classType: "Vector Rogue",
        tagline: "Precision slicing through standard layout structures with beautiful contrast",
        backstory: "An elite visual archivist who handles high-profile dark canvas operations in stealth mode.",
        stats: { strength: 55, agility: 92, intellect: 90, charisma: 82, luck: 70 },
        abilities: [
          { name: "Contrast Bleed", description: "Injects stark high contrast into background cells", powerCost: 20, abilityType: "Debuff" }
        ],
        visualPrompt: "Sleek dark clothes girl holding a glowing light pen, hoodie techwear aesthetic",
        themeColor: "#10B981",
        createdAt: "2026-05-21T14:30:00Z"
      }
    ];
  });

  const [recentThumbnails, setRecentThumbnails] = useState<ThumbnailSpec[]>(() => {
    try {
      const saved = localStorage.getItem("ai_creator_thumbs");
      if (saved) return JSON.parse(saved);
    } catch {}
    return [
      {
        id: "thumb_1",
        title: "AI Revolutions in BD",
        subtitle: "Earn $5,000+ with 4K Designs",
        style: "Epic / Dramatic Dark",
        layoutType: "Splitscreen Dynamic",
        focusSubject: "Bangladeshi Freelancer studying AI Neural Models",
        primaryColor: "#0A0A0C",
        secondaryColor: "#D4AF37",
        overlayElements: ["Glow badge", "CTR boost stars", "Custom Bangla font"],
        contrastRatio: "7.1:1",
        generatedPrompt: "Dramatic cinematic portrait of Bengali tech youth looking of glowing futuristic screen, 3d text overlay 'এআই বিপ্লব', golden cybernetic rays, bold margins, 8k resolution, extreme details",
        createdAt: "2026-05-22T08:15:00Z"
      },
      {
        id: "thumb_2",
        title: "Vite JS Masterclass",
        subtitle: "Fastest Full-Stack Guide",
        style: "Minimalist Stark",
        layoutType: "Modern Grid Layout with stark borders",
        focusSubject: "3D illuminated glass cube on dark pedestal",
        primaryColor: "#1E1E2F",
        secondaryColor: "#10B981",
        overlayElements: ["Code blocks", "Vite logo", "Contrast lines"],
        contrastRatio: "5.4:1",
        generatedPrompt: "Beautiful minimalist abstract 3d glowing translucent glass cube, dark background with subtle violet grid, pristine 4k vector lighting render, extremely high contrast",
        createdAt: "2026-05-23T01:20:00Z"
      }
    ];
  });

  const [recentPrompts, setRecentPrompts] = useState<PromptSpec[]>(() => {
    try {
      const saved = localStorage.getItem("ai_creator_prompts");
      if (saved) return JSON.parse(saved);
    } catch {}
    return [
      {
        id: "prompt_1",
        subject: "Cinematic portrait of digital tech wizard in Dhaka",
        medium: "Hasselblad Raw studio photograph",
        lighting: "Dramatic rim-light, soft golden Hour face glow",
        cameraSettings: "85mm lens, f/1.4",
        colorGrade: "Warm cinematic movie tone, dark gray background contrast",
        artStyle: "Hyperrealistic",
        additionalModifiers: ["extreme skin details", "volumetric microparticles", "octane render depth"],
        negativePrompt: "deformed, blurry, low resolution, amateur, basic lighting",
        fullMidjourneyPrompt: "Cinematic portrait of digital tech wizard in Dhaka, Hasselblad Raw studio photograph, dramatic rim-light, soft golden Hour face glow, 85mm lens, f/1.4, warm cinematic movie tone, dark gray background contrast, extreme skin details, volumetric microparticles --ar 16:9 --v 6.0",
        fullStableDiffusionPrompt: "Cinematic portrait of digital tech wizard in Dhaka, Hasselblad Raw studio photograph, dramatic rim-light, soft golden Hour face glow, 85mm lens, f/1.4, warm cinematic movie tone, dark gray background contrast, extreme skin details, volumetric microparticles, highly detailed",
        createdAt: "2026-05-22T19:45:00Z"
      }
    ];
  });

  const [recentInspirations, setRecentInspirations] = useState<InspirationSpec[]>(() => {
    try {
      const saved = localStorage.getItem("ai_creator_inspirations");
      if (saved) return JSON.parse(saved);
    } catch {}
    return [
      {
        id: "insp_1",
        niche: "SaaS Analytics Dashboard",
        recommendedConcept: "Dark brutalist analytics window with flat neon charts and 2px borders",
        wireframeBlueprint: "Header [Logo | Nav] -> Left Sidebar [Metrics] -> Central Hero [Performance Spider Chart] -> Footer [System Status]",
        typographySystem: {
          displayFont: "Space Grotesk",
          bodyFont: "Inter",
          monoFont: "JetBrains Mono"
        },
        aestheticTokens: {
          background: "#08080C",
          primaryAccent: "#D4AF37",
          secondaryAccent: "#10B981",
          surface: "#121216",
          border: "rgba(255, 255, 255, 0.08)"
        },
        uxHotspots: ["Dynamic Floating Action widget", "Hover telemetry logs list", "Custom SVG radar node"],
        visualPrompts: {
          uiArtwork: "High-contrast dark UI dashboard displaying glowing statistical radar charts"
        },
        createdAt: "2026-05-21T09:00:00Z"
      }
    ];
  });

  const [recentBrands, setRecentBrands] = useState<BrandSpec[]>(() => {
    try {
      const saved = localStorage.getItem("ai_creator_brands");
      if (saved) return JSON.parse(saved);
    } catch {}
    return [
      {
        id: "brand_1",
        brandName: "Alpha Synapse",
        industry: "Artificial Intelligence Solutions",
        personality: "Prestige, Cutting-Edge, Stark Minimalist",
        tagline: "Architecting the Year 2027 Workspace Genome",
        brandStory: "Born from localized developers determined to provide elite structural interfaces without lag.",
        logoCreativeConcept: "Two interlocking raw geometric slabs forming an elegant monogram monogram frame, illuminated by standard computer golden screen rays.",
        idealColorPalette: ["#0A0A0C", "#D4AF37", "#1E1E2F", "#FFFFFF", "#10B981"],
        marketingPitch: "Deploy compliant luxury web pipelines with 94% design stability ratings.",
        brandToneGuidelines: ["Direct, never apologetic", "Informed by telemetry", "Crisp spacing"],
        createdAt: "2026-05-22T15:20:00Z"
      }
    ];
  });

  const [recentPalettes, setRecentPalettes] = useState<ColorPaletteSpec[]>(() => {
    try {
      const saved = localStorage.getItem("ai_creator_palettes");
      if (saved) return JSON.parse(saved);
    } catch {}
    return [
      {
        id: "pal_1",
        paletteName: "Champagne Luxury Monochromatic",
        moodDescription: "An elite golden shade cluster optimized to build premium startup landing pages.",
        colors: [
          { hex: "#08080A", name: "Deep Charcoal Black", usage: "Main Backdrop Canvas" },
          { hex: "#D4AF37", name: "Premium Metallic Gold", usage: "Interactive Borders and Headings" },
          { hex: "#1A1A24", name: "Slate Shadow Accent", usage: "Surface Modular Cards" },
          { hex: "#FFFFFF", name: "Pristine Snow White", usage: "Core High-contrast Text Nodes" },
          { hex: "#10B981", name: "Active Emerald Green", usage: "Success State Telemetries" }
        ],
        contrastAudit: "Meets WCAG 2.1 AAA Contrast standards with 8.5:1 ratio",
        landingPageDemo: {
          heroText: "The Next Breed of Creative Freedom",
          ctaText: "Acquire Brand Identity",
          themeType: "Luxury Dark"
        },
        createdAt: "2026-05-23T04:40:00Z"
      }
    ];
  });

  const [historyList, setHistoryList] = useState<GenerationHistoryItem[]>(() => {
    try {
      const saved = localStorage.getItem("ai_creator_ledger");
      if (saved) return JSON.parse(saved);
    } catch {}
    return [
      { id: "h_1", type: "character", title: "Ayon Chandra", summary: "Synthesized Cyber Ranger mascot", timestamp: "2026-05-20T10:00:00Z", creditsUsed: 15 },
      { id: "h_2", type: "thumbnail", title: "AI Revolutions in BD", summary: "Rendered Splitscreen CTR Asset", timestamp: "2026-05-22T08:15:00Z", creditsUsed: 12 },
      { id: "h_3", type: "brand", title: "Alpha Synapse", summary: "Designed AI solutions brand matrix", timestamp: "2026-05-22T15:20:00Z", creditsUsed: 10 }
    ];
  });

  // Sync state with LocalStorage on updates
  useEffect(() => {
    localStorage.setItem("ai_creator_profile", JSON.stringify(profile));
  }, [profile]);

  useEffect(() => {
    localStorage.setItem("ai_creator_lang", lang);
  }, [lang]);

  useEffect(() => {
    localStorage.setItem("ai_creator_chars", JSON.stringify(recentCharacters));
  }, [recentCharacters]);

  useEffect(() => {
    localStorage.setItem("ai_creator_thumbs", JSON.stringify(recentThumbnails));
  }, [recentThumbnails]);

  useEffect(() => {
    localStorage.setItem("ai_creator_prompts", JSON.stringify(recentPrompts));
  }, [recentPrompts]);

  useEffect(() => {
    localStorage.setItem("ai_creator_inspirations", JSON.stringify(recentInspirations));
  }, [recentInspirations]);

  useEffect(() => {
    localStorage.setItem("ai_creator_brands", JSON.stringify(recentBrands));
  }, [recentBrands]);

  useEffect(() => {
    localStorage.setItem("ai_creator_palettes", JSON.stringify(recentPalettes));
  }, [recentPalettes]);

  useEffect(() => {
    localStorage.setItem("ai_creator_ledger", JSON.stringify(historyList));
  }, [historyList]);

  const toggleLanguage = () => {
    setLang((prev) => (prev === "en" ? "bn" : "en"));
  };

  const handleLoginSuccess = (user: string) => {
    setProfile(prev => ({
      ...prev,
      username: user,
      isLoggedIn: true,
      credits: prev.credits > 0 ? prev.credits : 100
    }));
  };

  const handleLogout = () => {
    setProfile(prev => ({
      ...prev,
      isLoggedIn: false
    }));
  };

  // Safe credit deduction state driver
  const deductCredits = (qty: number, actionTitle: string): boolean => {
    if (profile.credits < qty) {
      return false;
    }

    setProfile(prev => ({
      ...prev,
      credits: Math.max(0, prev.credits - qty)
    }));

    return true;
  };

  // simulated free token recharger topup
  const rechargeCredits = () => {
    setProfile(prev => ({
      ...prev,
      credits: prev.credits + 50
    }));
    
    // Toast callback
    alert(TRANSLATIONS[lang].creditsRefreshed);
  };

  // Callback hooks to preserve children productions
  const onCharacterGenerated = (char: AICharacter) => {
    // Upsert character to history array
    setRecentCharacters(prev => {
      const filtered = prev.filter(c => c.id !== char.id);
      return [char, ...filtered];
    });

    // Write to ledger
    const ledgerItem: GenerationHistoryItem = {
      id: `led_${Date.now()}`,
      type: 'character',
      title: `Forged Character: ${char.name}`,
      summary: `${char.classType} (${char.gender})`,
      timestamp: new Date().toISOString(),
      creditsUsed: 15
    };
    setHistoryList(prev => [ledgerItem, ...prev]);
  };

  const onThumbnailGenerated = (thumb: ThumbnailSpec) => {
    setRecentThumbnails(prev => {
      const filtered = prev.filter(t => t.id !== thumb.id);
      return [thumb, ...filtered];
    });

    const ledgerItem: GenerationHistoryItem = {
      id: `led_${Date.now()}`,
      type: 'thumbnail',
      title: `Designed Layout: ${thumb.title}`,
      summary: `${thumb.style} Art Style Layout Blueprint`,
      timestamp: new Date().toISOString(),
      creditsUsed: 10
    };
    setHistoryList(prev => [ledgerItem, ...prev]);
  };

  const onPromptGenerated = (prompt: PromptSpec) => {
    setRecentPrompts(prev => {
      const filtered = prev.filter(p => p.id !== prompt.id);
      return [prompt, ...filtered];
    });

    const ledgerItem: GenerationHistoryItem = {
      id: `led_${Date.now()}`,
      type: 'prompt',
      title: `Prompt Architected: ${prompt.subject.substring(0, 30)}...`,
      summary: `Compiled under ${prompt.medium}`,
      timestamp: new Date().toISOString(),
      creditsUsed: 5
    };
    setHistoryList(prev => [ledgerItem, ...prev]);
  };

  const onInspirationGenerated = (insp: InspirationSpec) => {
    setRecentInspirations(prev => {
      const filtered = prev.filter(i => i.id !== insp.id);
      return [insp, ...filtered];
    });

    const ledgerItem: GenerationHistoryItem = {
      id: `led_${Date.now()}`,
      type: 'inspiration',
      title: `Designed Layout Blueprint: ${insp.niche}`,
      summary: `Concept: ${insp.recommendedConcept}`,
      timestamp: new Date().toISOString(),
      creditsUsed: 10
    };
    setHistoryList(prev => [ledgerItem, ...prev]);
  };

  const onBrandGenerated = (brand: BrandSpec) => {
    setRecentBrands(prev => {
      const filtered = prev.filter(b => b.id !== brand.id);
      return [brand, ...filtered];
    });

    const ledgerItem: GenerationHistoryItem = {
      id: `led_${Date.now()}`,
      type: 'brand',
      title: `Formulated Brand Platform: ${brand.brandName}`,
      summary: `Tagline: ${brand.tagline}`,
      timestamp: new Date().toISOString(),
      creditsUsed: 15
    };
    setHistoryList(prev => [ledgerItem, ...prev]);
  };

  const onColorGenerated = (col: ColorPaletteSpec) => {
    setRecentPalettes(prev => {
      const filtered = prev.filter(p => p.id !== col.id);
      return [col, ...filtered];
    });

    const ledgerItem: GenerationHistoryItem = {
      id: `led_${Date.now()}`,
      type: 'color',
      title: `Synthesized Colors: ${col.paletteName}`,
      summary: `Colors: ${col.colors.map(c => c.hex).join(', ')}`,
      timestamp: new Date().toISOString(),
      creditsUsed: 5
    };
    setHistoryList(prev => [ledgerItem, ...prev]);
  };

  const t = TRANSLATIONS[lang];

  // If not logged in, render gorgeous greeting panel
  if (!profile.isLoggedIn) {
    return (
      <LoginModule 
        lang={lang} 
        onLoginSuccess={handleLoginSuccess} 
        toggleLang={toggleLanguage} 
      />
    );
  }

  return (
    <div className="min-h-screen bg-[#0A0A0A] flex flex-col justify-between font-sans select-none antialiased text-white">
      
      {/* Dynamic Ambient Blur */}
      <div className="absolute top-0 right-10 w-96 h-96 bg-blue-600/5 blur-[120px] rounded-full pointer-events-none" />

      {/* Main Core Fullscreen Desktop Layout Grid */}
      <div className="w-full">
        {/* Navigation & branding Header holds responsive options */}
        <header className="bg-[#121212] border-b border-white/5 sticky top-0 z-40 backdrop-blur-md px-4 sm:px-8 py-3.5 flex flex-col md:flex-row justify-between items-center gap-4">
          <div className="flex items-center gap-3">
            {/* Visual Workspace Logo */}
            <div className="p-2 bg-blue-600/10 border border-blue-500/20 rounded-xl">
              <Sparkles className="w-5 h-5 text-blue-400 rotate-12" />
            </div>
            <div className="text-left">
              <h1 className="text-md sm:text-lg font-display font-medium tracking-tight text-white uppercase flex items-center gap-1">
                <span>AI</span>
                <span className="text-blue-500 font-medium italic">Studio.bn</span>
              </h1>
              <p className="text-[10px] text-gray-500 font-mono tracking-wide uppercase">
                {lang === "en" ? "Fullstack AI Suite V2.5" : "ফুলস্ট্যাক এআই ওয়ার্কস্পেস"}
              </p>
            </div>
          </div>

          {/* Core horizontal Tab controller layout */}
          <nav className="flex flex-wrap items-center gap-1.5 p-1 bg-white/5 border border-white/5 rounded-2xl">
            <button
              onClick={() => setActiveTab("quantum")}
              id="nav-tab-quantum"
              className={`flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-semibold cursor-pointer transition-all ${
                activeTab === "quantum"
                  ? "bg-purple-600 text-white shadow-md shadow-purple-900/40"
                  : "text-gray-400 hover:text-white hover:bg-white/5"
              }`}
            >
              <Brain className="w-3.5 h-3.5 text-purple-400 shrink-0" />
              <span>{lang === "en" ? "Quantum Agent" : "কোয়ান্টাম এজেন্ট"}</span>
            </button>
            <button
              onClick={() => setActiveTab("character")}
              id="nav-tab-character"
              className={`flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-semibold cursor-pointer transition-all ${
                activeTab === "character"
                  ? "bg-blue-600 text-white shadow-md shadow-blue-900/40"
                  : "text-gray-400 hover:text-white hover:bg-white/5"
              }`}
            >
              <User className="w-3.5 h-3.5" />
              <span>{t.charTab}</span>
            </button>
            <button
              onClick={() => setActiveTab("thumbnail")}
              id="nav-tab-thumbnail"
              className={`flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-semibold cursor-pointer transition-all ${
                activeTab === "thumbnail"
                  ? "bg-blue-600 text-white shadow-md shadow-blue-900/40"
                  : "text-gray-400 hover:text-white hover:bg-white/5"
              }`}
            >
              <Layout className="w-3.5 h-3.5" />
              <span>{t.thumbTab}</span>
            </button>
            <button
              onClick={() => setActiveTab("prompt")}
              id="nav-tab-prompt"
              className={`flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-semibold cursor-pointer transition-all ${
                activeTab === "prompt"
                  ? "bg-blue-600 text-white shadow-md shadow-blue-900/40"
                  : "text-gray-400 hover:text-white hover:bg-white/5"
              }`}
            >
              <Terminal className="w-3.5 h-3.5" />
              <span>{t.promptTab}</span>
            </button>
            <button
              onClick={() => setActiveTab("inspiration")}
              id="nav-tab-inspiration"
              className={`flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-semibold cursor-pointer transition-all ${
                activeTab === "inspiration"
                  ? "bg-indigo-600 text-white shadow-md shadow-indigo-900/40"
                  : "text-gray-400 hover:text-white hover:bg-white/5"
              }`}
            >
              <Compass className="w-3.5 h-3.5 text-indigo-400" />
              <span>{lang === "en" ? "Inspiration Hub" : "ডিজাইন ইন্সপিরেশন"}</span>
            </button>
            <button
              onClick={() => setActiveTab("brand")}
              id="nav-tab-brand"
              className={`flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-semibold cursor-pointer transition-all ${
                activeTab === "brand"
                  ? "bg-emerald-600 text-white shadow-md shadow-emerald-900/40"
                  : "text-gray-400 hover:text-white hover:bg-white/5"
              }`}
            >
              <Award className="w-3.5 h-3.5 text-emerald-400" />
              <span>{lang === "en" ? "Brand Maker" : "ব্র্যান্ড স্ট্র্যাটেজি"}</span>
            </button>
            <button
              onClick={() => setActiveTab("color")}
              id="nav-tab-color"
              className={`flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-semibold cursor-pointer transition-all ${
                activeTab === "color"
                  ? "bg-indigo-600 text-white shadow-md shadow-indigo-900/40"
                  : "text-gray-400 hover:text-white hover:bg-white/5"
              }`}
            >
              <Palette className="w-3.5 h-3.5 text-indigo-400" />
              <span>{lang === "en" ? "Color Palette" : "কালার প্যালেট"}</span>
            </button>
            <button
              onClick={() => setActiveTab("studiosuite")}
              id="nav-tab-studiosuite"
              className={`flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-semibold cursor-pointer transition-all ${
                activeTab === "studiosuite"
                  ? "bg-purple-600 text-white shadow-md shadow-purple-900/40"
                  : "text-gray-400 hover:text-white hover:bg-white/5"
              }`}
            >
              <Sparkles className="w-3.5 h-3.5 text-purple-400" />
              <span>{lang === "en" ? "Studio Suite" : "স্টুডিও স্যুট"}</span>
            </button>
            <button
              onClick={() => setActiveTab("criticoach")}
              id="nav-tab-criticoach"
              className={`flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-semibold cursor-pointer transition-all ${
                activeTab === "criticoach"
                  ? "bg-rose-600 text-white shadow-md shadow-rose-900/40"
                  : "text-gray-400 hover:text-white hover:bg-white/5"
              }`}
            >
              <PenTool className="w-3.5 h-3.5 text-rose-400" />
              <span>{lang === "en" ? "Critic & Coach" : "ডিজাইন সমালোচক"}</span>
            </button>
            <button
              onClick={() => setActiveTab("freelance")}
              id="nav-tab-freelance"
              className={`flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-semibold cursor-pointer transition-all ${
                activeTab === "freelance"
                  ? "bg-amber-600 text-white shadow-md shadow-amber-900/40"
                  : "text-gray-400 hover:text-white hover:bg-white/5"
              }`}
            >
              <DollarSign className="w-3.5 h-3.5 text-amber-400" />
              <span>{lang === "en" ? "Freelance" : "ফ্রিল্যান্সিং"}</span>
            </button>
            <button
              onClick={() => setActiveTab("communityhub")}
              id="nav-tab-communityhub"
              className={`flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-semibold cursor-pointer transition-all ${
                activeTab === "communityhub"
                  ? "bg-indigo-600 text-white shadow-md shadow-indigo-900/40"
                  : "text-gray-400 hover:text-white hover:bg-white/5"
              }`}
            >
              <Users className="w-3.5 h-3.5 text-indigo-400" />
              <span>{lang === "en" ? "Community" : "কমিউনিটি"}</span>
            </button>
            <button
              onClick={() => setActiveTab("credits")}
              id="nav-tab-credits"
              className={`flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-semibold cursor-pointer transition-all ${
                activeTab === "credits"
                  ? "bg-blue-600 text-white shadow-md shadow-blue-900/40"
                  : "text-gray-400 hover:text-white hover:bg-white/5"
              }`}
            >
              <BarChart3 className="w-3.5 h-3.5" />
              <span>{t.historyTab}</span>
            </button>
          </nav>

          {/* Right widgets holds state properties */}
          <div className="flex items-center gap-3">
            {/* Credits Counter badge */}
            <div 
              onClick={() => setActiveTab("credits")}
              className="flex items-center gap-2 px-3 py-1.5 bg-gradient-to-r from-blue-950/40 to-purple-950/40 hover:from-blue-900/50 hover:to-purple-900/50 border border-blue-500/20 rounded-xl text-xs font-bold text-blue-400 font-mono tracking-wider cursor-pointer active:scale-95 transition-all"
            >
              <Coins className="w-3.5 h-3.5 text-blue-400 shrink-0" />
              <span>{profile.credits} CREDITS</span>
              <PlusCircle className="w-3 h-3 text-blue-400 select-none cursor-pointer hover:text-blue-200" onClick={(e) => { e.stopPropagation(); rechargeCredits(); }} />
            </div>

            {/* Language toggle trigger */}
            <button
              onClick={toggleLanguage}
              id="btn-app-lang-toggle"
              className="p-2 bg-white/5 hover:bg-white/10 border border-white/5 rounded-xl text-blue-400 hover:text-blue-300 transition-all cursor-pointer active:scale-95"
              title="Change Language / ভাষা পরিবর্তন"
            >
              <Globe className="w-4 h-4" />
            </button>

            {/* User identification badge */}
            <div className="flex items-center gap-1.5 px-3 py-1.5 bg-[#151515] border border-white/5 rounded-2xl text-xs text-gray-300 font-mono select-none">
              <span className="w-2 h-2 rounded-full bg-blue-500 animate-pulse"></span>
              <span className="truncate max-w-[100px]">{profile.username}</span>
            </div>

            {/* Log Out button */}
            <button
              onClick={handleLogout}
              id="btn-app-logout"
              className="p-2 bg-white/5 hover:bg-rose-950/40 hover:text-rose-400 border border-white/5 hover:border-rose-900/50 rounded-xl text-gray-400 transition-all cursor-pointer active:scale-95"
              title={t.logout}
            >
              <LogOut className="w-4 h-4" />
            </button>
          </div>
        </header>

        {/* Unified Tools Dashboard Wrapper */}
        <main className="max-w-7xl mx-auto px-4 sm:px-8 py-8">
          {/* Active module switches */}
          <div className="space-y-4">
            {activeTab === "quantum" && (
              <QuantumAgentModule
                lang={lang}
                credits={profile.credits}
                deductCredits={deductCredits}
              />
            )}

            {activeTab === "character" && (
              <CharacterModule
                lang={lang}
                credits={profile.credits}
                deductCredits={deductCredits}
                onCharacterGenerated={onCharacterGenerated}
                recentCharacters={recentCharacters}
              />
            )}

            {activeTab === "thumbnail" && (
              <ThumbnailModule
                lang={lang}
                credits={profile.credits}
                deductCredits={deductCredits}
                onThumbnailGenerated={onThumbnailGenerated}
                recentThumbnails={recentThumbnails}
              />
            )}

            {activeTab === "prompt" && (
              <PromptModule
                lang={lang}
                credits={profile.credits}
                deductCredits={deductCredits}
                onPromptGenerated={onPromptGenerated}
                recentPrompts={recentPrompts}
              />
            )}

            {activeTab === "inspiration" && (
              <InspirationHubModule
                lang={lang}
                credits={profile.credits}
                deductCredits={deductCredits}
                onInspirationGenerated={onInspirationGenerated}
                recentInspirations={recentInspirations}
              />
            )}

            {activeTab === "brand" && (
              <BrandGeneratorModule
                lang={lang}
                credits={profile.credits}
                deductCredits={deductCredits}
                onBrandGenerated={onBrandGenerated}
                recentBrands={recentBrands}
              />
            )}

            {activeTab === "color" && (
              <ColorGeneratorModule
                lang={lang}
                credits={profile.credits}
                deductCredits={deductCredits}
                onColorGenerated={onColorGenerated}
                recentPalettes={recentPalettes}
              />
            )}

            {activeTab === "studiosuite" && (
              <StudioSuiteModule
                lang={lang}
                credits={profile.credits}
                deductCredits={deductCredits}
              />
            )}

            {activeTab === "criticoach" && (
              <CriticCoachModule
                lang={lang}
                credits={profile.credits}
                deductCredits={deductCredits}
              />
            )}

            {activeTab === "freelance" && (
              <FreelanceToolkitModule
                lang={lang}
                credits={profile.credits}
                deductCredits={deductCredits}
              />
            )}

            {activeTab === "communityhub" && (
              <CommunityAssetsModule
                lang={lang}
                credits={profile.credits}
                deductCredits={deductCredits}
              />
            )}

            {activeTab === "credits" && (
              <CreditLogModule
                lang={lang}
                username={profile.username}
                credits={profile.credits}
                historyList={historyList}
                rechargeCredits={rechargeCredits}
              />
            )}
          </div>
        </main>
      </div>

      {/* Styled Footer copyright block */}
      <footer className="bg-black/40 border-t border-white/5 py-6 text-center select-none">
        <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row justify-between items-center gap-2 text-xs text-gray-500 font-mono">
          <span>{lang === "en" ? "SECURE CLIENT WORKSPACE ENVIRONMENT" : "সুরক্ষিত ক্লায়েন্ট ওয়ার্কস্পেস এনভায়রনমেন্ট"}</span>
          <span>© 2026 AI CONTENT SUITE • POWERED BY GEMINI-3.5-FLASH</span>
        </div>
      </footer>
    </div>
  );
}
