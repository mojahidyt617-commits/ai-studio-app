/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface UserProfile {
  username: string;
  credits: number;
  isLoggedIn: boolean;
  avatarSeed: string;
  joinedAt: string;
}

export interface CharacterStats {
  strength: number;
  agility: number;
  intellect: number;
  charisma: number;
  luck: number;
}

export interface CharacterAbility {
  name: string;
  description: string;
  powerCost: number;
  abilityType: string;
}

export interface AICharacter {
  id: string;
  name: string;
  gender: string;
  classType: string;
  tagline: string;
  backstory: string;
  stats: CharacterStats;
  abilities: CharacterAbility[];
  visualPrompt: string;
  avatarBase64?: string; // Loaded if successfully generated
  avatarSvgFallback?: string; // Creative SVG generated online
  themeColor: string;
  createdAt: string;
}

export interface ThumbnailSpec {
  id: string;
  title: string;
  subtitle: string;
  style: string;
  layoutType: string;
  focusSubject: string;
  primaryColor: string;
  secondaryColor: string;
  overlayElements: string[];
  contrastRatio: string;
  generatedPrompt: string;
  thumbnailBase64?: string; // Generated picture
  createdAt: string;
  isHiFiExport?: boolean;
  exportResolution?: "4k" | "8k";
  isDnaConsistent?: boolean;
  aspectRatio?: string;
}

export interface PromptSpec {
  id: string;
  subject: string;
  medium: string;
  lighting: string;
  cameraSettings: string;
  colorGrade: string;
  artStyle: string;
  additionalModifiers: string[];
  negativePrompt: string;
  fullMidjourneyPrompt: string;
  fullStableDiffusionPrompt: string;
  createdAt: string;
}

export interface GenerationHistoryItem {
  id: string;
  type: 'character' | 'thumbnail' | 'prompt' | 'inspiration' | 'brand' | 'color';
  title: string;
  summary: string;
  timestamp: string;
  creditsUsed: number;
}

export interface InspirationSpec {
  id: string;
  niche: string;
  recommendedConcept: string;
  wireframeBlueprint: string;
  typographySystem: {
    displayFont: string;
    bodyFont: string;
    monoFont: string;
  };
  aestheticTokens: {
    background: string;
    primaryAccent: string;
    secondaryAccent: string;
    surface: string;
    border: string;
  };
  uxHotspots: string[];
  visualPrompts: {
    uiArtwork: string;
  };
  createdAt: string;
  aiGenerated?: boolean;
}

export interface BrandSpec {
  id: string;
  brandName: string;
  industry: string;
  personality: string;
  tagline: string;
  brandStory: string;
  logoCreativeConcept: string;
  idealColorPalette: string[];
  marketingPitch: string;
  brandToneGuidelines: string[];
  createdAt: string;
  aiGenerated?: boolean;
}

export interface ColorPaletteSpec {
  id: string;
  paletteName: string;
  moodDescription: string;
  colors: Array<{
    hex: string;
    name: string;
    usage: string;
  }>;
  contrastAudit: string;
  landingPageDemo: {
    heroText: string;
    ctaText: string;
    themeType: string;
  };
  createdAt: string;
  aiGenerated?: boolean;
}
